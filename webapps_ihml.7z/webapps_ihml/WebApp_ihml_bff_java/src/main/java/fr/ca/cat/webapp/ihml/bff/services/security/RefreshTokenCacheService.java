package fr.ca.cat.webapp.ihml.bff.services.security;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;

import fr.ca.cat.webapp.ihml.bff.utils.Constants;

/**
 * Service pour l'utilisation du cache TOKEN pour le refresh token dans REDIS
 * @author ET02720
 *
 */
public class RefreshTokenCacheService {
	
	/**
	 * Injection de l'objet CacheManager pour g�rer l'acc�s aux caches Redis
	 */
	@Autowired
	protected CacheManager cacheManager;
	
	/**
	 * Sauvegarde d'un refresh token dans le cache TOKEN
	 * @param key La cl� de sauvegarde
	 * @param value Le refresh token � sauvegarder
	 */
	public void storeRefreshToken(String key, String refreshToken) {
		this.cacheManager.getCache(Constants.TOKEN_CACHE).put(key, refreshToken);
	}
	
	/**
	 * Indique si la cl� du refresh token existe
	 * @param key La cl� � rechercher
	 * @return 
	 * <ul>
	 * <li>True si la cl� existe</li>
	 * <li>False si la cl� n'existe pas o� a expir�e.
	 * </li>
	 */
	public boolean isRefreshTokenKeyExist(String key) {
		return !Objects.isNull(this.cacheManager.getCache(Constants.TOKEN_CACHE).get(key));
	}
	
	/**
	 * Retourne la valeur du refresh token
	 * @param key La cl� souhait�e
	 * @param valueType Le type de la valeur retourn�e
	 * @return La valeur dans le cache REDIS
	 */
	public String getRefreshToken(String key) {
		return this.cacheManager.getCache(Constants.TOKEN_CACHE).get(key, String.class);
	}
	
	/**
	 * Suppression de la cl� dans le cache TOKEN REDIS
	 * @param key La cl� � supprimer
	 */
	public void deleteRefreshToken(String key) {
		this.cacheManager.getCache(Constants.TOKEN_CACHE).evict(key);
	}
	
	
}
