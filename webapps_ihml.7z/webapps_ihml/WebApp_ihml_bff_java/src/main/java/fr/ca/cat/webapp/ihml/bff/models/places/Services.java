package fr.ca.cat.webapp.ihml.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet d�finissant les services propos�s par une agence
 * @author ET02720
 *
 */
public class Services {

	/**
	 * Poss�de un guichet automatioque bancaire
	 * @see Services#isAtm()
	 * @see Services#setAtm(boolean)
	 */
	private boolean atm;
	
	/**
	 * Poss�de un distributeur automatique de billets
	 * @see Services#isAutomaticCashMachine()
	 * @see Services#setAutomaticCashMachine(boolean)
	 */
	private boolean automaticCashMachine;
	
	/**
	 * Poss�de une rampe d'acc�s pour les personnes handicap�s
	 * @see Services#isWheelChairAccess()
	 * @see Services#setWheelChairAccess(boolean)
	 */
	private boolean wheelChairAccess;
	
	/**
	 * Poss�de un parking
	 * @see Services#isCarPark()
	 * @see Services#setCarPark(boolean)
	 */
	private boolean carPark;
	
	/**
	 * Poss�de un service de conversion de monnaie
	 * @see Services#isExchangeCurrency()
	 * @see Services#setExchangeCurrency(boolean)
	 */
	private boolean exchangeCurrency;
	
	/**
	 * Poss�de un service suppl�mentaire
	 * @see Services#getExtraService1()
	 * @see Services#setExtraService1(String)
	 */
	private String extraService1;
	
	/**
	 * Poss�de un second service suppl�mentaire
	 * @see Services#getExtraService2()
	 * @see Services#setExtraService2(String)
	 */
	private String extraService2;
	
	/**
	 * Poss�de une troisi�me service suppl�mentaire
	 * @see Services#getExtraService3()
	 * @see Services#setExtraService3(String)
	 */
	private String extraService3;
	
	/**
	 * Indique si l'agence poss�de un guichet automatioque bancaire
	 * @return True si l'agence poss�de un guichet automatioque bancaire
	 */
	@JsonProperty(value = "atm")
	public boolean isAtm() {
		return atm;
	}
	
	/**
	 * Sp�cifie si l'agence poss�de un guichet automatioque bancaire
	 * @param atm True si l'agence poss�de un guichet automatioque bancaire
	 */
	@JsonProperty(value = "atm")
	public void setAtm(boolean atm) {
		this.atm = atm;
	}
	
	/**
	 * Indique si l'agence poss�de un distributeur de billets automatique
	 * @return True si l'agence poss�de un distributeur de billets automatique
	 */
	@JsonProperty(value = "automatic_cash_machine")
	public boolean isAutomaticCashMachine() {
		return automaticCashMachine;
	}
	
	/**
	 * Sp�cifie si l'agence poss�de un distributeur de billets automatique
	 * @param atm True si l'agence poss�de un distributeur de billets automatique
	 */
	@JsonProperty(value = "automatic_cash_machine")
	public void setAutomaticCashMachine(boolean automaticCashMachine) {
		this.automaticCashMachine = automaticCashMachine;
	}
	
	/**
	 * Indique si l'agence poss�de une rampe d'acc�s pour les personnes handicap�s
	 * @return True si l'agence poss�de une rampe d'acc�s pour les personnes handicap�s
	 */
	@JsonProperty(value = "wheel_chair_access")
	public boolean isWheelChairAccess() {
		return wheelChairAccess;
	}
	
	/**
	 * Sp�cifie si l'agence poss�de une rampe d'acc�s pour les personnes handicap�s
	 * @param atm True si l'agence poss�de une rampe d'acc�s pour les personnes handicap�s
	 */
	@JsonProperty(value = "wheel_chair_access")
	public void setWheelChairAccess(boolean wheelChairAccess) {
		this.wheelChairAccess = wheelChairAccess;
	}
	
	/**
	 * Indique si l'agence poss�de un parking
	 * @return True si l'agence poss�de un parking
	 */
	@JsonProperty(value = "car_park")
	public boolean isCarPark() {
		return carPark;
	}
	
	/**
	 * Sp�cifie si l'agence poss�de un parking
	 * @param atm True si l'agence poss�de un parking
	 */
	@JsonProperty(value = "car_park")
	public void setCarPark(boolean carPark) {
		this.carPark = carPark;
	}
	
	/**
	 * Indique si l'agence poss�de un service de conversion de monnaie
	 * @return True si l'agence poss�de un service de conversion de monnaie
	 */
	@JsonProperty(value = "exchange_currency")
	public boolean isExchangeCurrency() {
		return exchangeCurrency;
	}
	
	/**
	 * Sp�cifie si l'agence poss�de un service de conversion de monnaie
	 * @param atm True si l'agence poss�de un service de conversion de monnaie
	 */
	@JsonProperty(value = "exchange_currency")
	public void setExchangeCurrency(boolean exchangeCurrency) {
		this.exchangeCurrency = exchangeCurrency;
	}
	
	
	/**
	 * Retourne un service suppl�mentaire de l'agence
	 * @return Un service suppl�mentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_1")
	public String getExtraService1() {
		return extraService1;
	}
	
	/**
	 * Met � jour un service suppl�mentaire de l'agence
	 * @param extraService1 Le nouveau service suppl�mentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_1")
	public void setExtraService1(String extraService1) {
		this.extraService1 = extraService1;
	}
	
	/**
	 * Retourne un second service suppl�mentaire de l'agence
	 * @return Un second service suppl�mentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_2")
	public String getExtraService2() {
		return extraService2;
	}
	
	/**
	 * Met � jour un second service suppl�mentaire de l'agence
	 * @param extraService2 Le nouveau second service suppl�mentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_2")
	public void setExtraService2(String extraService2) {
		this.extraService2 = extraService2;
	}
	
	/**
	 * Retourne un troisi�me service suppl�mentaire de l'agence
	 * @return Un troisi�me service suppl�mentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_3")
	public String getExtraService3() {
		return extraService3;
	}
	
	/**
	 * Met � jour un troisi�me service suppl�mentaire de l'agence
	 * @param extraService3 Le nouveau troisi�me service suppl�mentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_3")
	public void setExtraService3(String extraService3) {
		this.extraService3 = extraService3;
	}
	
}
