package fr.ca.cat.webapp.ihml.bff.services.manifest;

import java.io.IOException;
import java.io.InputStream;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import fr.ca.cat.webapp.ihml.bff.models.manifest.ApplicationManifest;

public class ManifestService {
	
	@Autowired
	ServletContext context;
	
	/**
	 * Injection de la propri�t� qui r�f�rence au framework
	 */
	@Value("${app.framework}")
	protected String framework;
	
	/**
	 * R�cup�ration du manifest de l'application
	 * @return Le manifest de l'application
	 * @throws IOException 
	 * @see {@link ApplicationManifest}
	 */
	public ApplicationManifest getManifest() throws IOException {
		InputStream inputStream = context.getResourceAsStream("/META-INF/MANIFEST.MF");
		Manifest manifest = new Manifest(inputStream);    
		Attributes attr = manifest.getMainAttributes();
		
		ApplicationManifest appManifest = new ApplicationManifest();
		appManifest.setVersion(attr.getValue("Implementation-Version"));
		appManifest.setFramework(framework);
		
		return appManifest;
	}
}
