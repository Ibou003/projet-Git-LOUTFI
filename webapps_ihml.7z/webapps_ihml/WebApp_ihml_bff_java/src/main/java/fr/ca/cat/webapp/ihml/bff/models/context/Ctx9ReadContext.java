package fr.ca.cat.webapp.ihml.bff.models.context;

import java.io.IOException;

import com.fasterxml.jackson.annotation.JsonProperty;

import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;

/**
 * Classe pour d�finir le contexte renvoy� par l'API CTX9
 * @author ET02720
 *
 */
public class Ctx9ReadContext {
	
	/**
	 * Contexte renvoy� par l'API CTX9
	 * @see {@link Ctx9ReadContext#getContext()}
	 * @see {@link Ctx9ReadContext#setContext()}
	 */
	private String context;
	

	/**
	 * Retourne le contexte CTX9
	 * @return Un contexte au format string
	 */
	@JsonProperty(value = "context")
	public String getContext() {
		return context;
	}

	/**
	 * Sp�cifie le contexte CTX9
	 * @param context Un contexte au format string
	 */
	@JsonProperty(value = "context")
	public void setContext(String context) {
		this.context = context;
	}
	
	public ApplicationContext toApplicationContext() throws IOException {
		return AppUtils.jsonStringToObject(this.context, ApplicationContext.class);
	}
	
	
}
