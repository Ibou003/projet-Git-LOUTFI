package fr.ca.cat.webapp.ihml.bff.utils;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Objects;

import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Classe contenant des methodes static utilitaire
 * @author ET02720
 *
 */
public class AppUtils {

	/**
	 * Permet la conversion d'un objet en chaine JSON
	 * @param obj L'objet � convertir
	 * @return La chaine JSON
	 * @throws JsonProcessingException
	 */
	public static String convertObjectToJsonString(Object obj) throws JsonProcessingException {
        if (Objects.isNull(obj)) {
            return null;
        }
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        return mapper.writeValueAsString(obj);
	}
	
	public static <T> T jsonStringToObject(String jsonString, Class<T> valueType) throws IOException {
        if (Objects.isNull(jsonString)) {
            return null;
        }		
        
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(jsonString, valueType);
	}
	
	/**
	 * Permet de mettre en forme une chaine JSON
	 * @param jsonString La chaine � mettre en forme
	 * @return La chaine JSON mise � en forme
	 * @throws IOException
	 */
	public static String prettifyJsonString(String jsonString) throws IOException {
        if (Objects.isNull(jsonString)) {
            return null;
        }
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        Object json = mapper.readValue(jsonString, Object.class);
        
        return convertObjectToJsonString(json);
	}
	
	/**
	 * Permet de mapper le contenue d'une r�ponse � un objet
	 * @param response La r�ponse de la requ�te
	 * @param valueType Type de l'objet auquel mapper la r�ponse
	 * @return L'objet mapp�
	 * @throws IOException
	 */
	public static <T> T mapResponse(HttpResponse response, Class<T> valueType) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(EntityUtils.toString(response.getEntity()), valueType);
	}
	
	/**
	 * Permet de retourner le timestamp en millisecondes depuis maintenant plus un temps de d�lai
	 * @param delay Le d�lai � rajouter � maintenant
	 * @return Le timestamp en millisecondes
	 */
	public static long delayFromNowToMilliseconds(int delay) {
		return LocalDateTime.now()
				.plusSeconds(delay)
				.atZone(ZoneId.systemDefault())
				.toInstant().toEpochMilli();
	}
	
	/**
	 * Permet de retourner une LocalDateTime � partir d'un timestamp en millisecondes
	 * @param dateMilliseconds Le timestam en millisecondes
	 * @return Un objet LocalDateTime
	 * @see {@link LocalDateTime}
	 */
	public static LocalDateTime dateFromMilliseconds(long dateMilliseconds) {
		return LocalDateTime.ofInstant(Instant.ofEpochMilli(dateMilliseconds), ZoneId.systemDefault());
	}
	
	/**
	 * Construction de la chaine pour sp�cifier un cookie
	 * 
	 * @param cookieName Nom du cookie
	 * @param cookieValue Valeur du cookie
	 * @param domain Domaine du cookie
	 * @param path Chemin du cookie
	 * @param isSecure Protocol HTTPS
	 * @param sameSite Pr�cision sameSite
	 * @param expired Expiration du cookie
	 * @return Une chaine pour sp�cifier le cookie
	 */
	public static String buildCookie(String cookieName, String cookieValue, String domain, String path,
			boolean isSecure, String sameSite, boolean expired) {
		StringBuilder sb = new StringBuilder();

		// Ajout nom et valeur du cookie
		sb.append(String.format("%s=%s", cookieName, cookieValue));

		// Ajout du domain
		if (Objects.nonNull(domain) && !domain.isEmpty()) {
			sb.append(String.format("; domain=%s", domain));
		}

		// Ajout du path
		if (Objects.nonNull(path) && !path.isEmpty()) {
			sb.append(String.format("; path=%s", path));
		}

		// Ajout HttpOnly
		sb.append("; HttpOnly");

		// Ajout du isSecure
		if (isSecure) {
			sb.append("; Secure");
		}

		// Ajout Same Site
		if (Objects.nonNull(sameSite) && !sameSite.isEmpty()) {
			sb.append(String.format("; SameSite=%s", sameSite));
		} else {
			sb.append("; SameSite=Lax");
		}

		// Ajout MaxAge
		if (expired) {
			sb.append("Max-Age=0; Expires=Thu, 1 Jan 1970 00:00:00 GMT;");
		} else {

		}

		return sb.toString();
	}
}
