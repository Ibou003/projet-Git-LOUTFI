package fr.ca.cat.webapp.ihml.bff.session;

import java.time.Duration;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.session.data.redis.config.ConfigureRedisAction;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

import fr.ca.cat.fwk.fwkcatcache.redis.SilentConnectionFailureRedisTemplate;
import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.utils.Constants;

/**
 * Classe pour configurer l'utilisation de spring session avec REDIS. Elle
 * d�clare aussi le cache REDIS pour le stockage des refresh token
 * 
 * @author ET02720
 *
 */
@Configuration
@EnableCaching
@EnableRedisHttpSession(cleanupCron = "0 0 0 29 02 ?", redisNamespace = Constants.NAMESPACE_KEY)
@PropertySource("classpath:application.properties")
public class SessionConfig extends AbstractHttpSessionApplicationInitializer {

	private MostLogger mostLogger = MostLogger.getLogger(SessionConfig.class);
	
	/**
	 * Injection du Host Redis pour sauvegarder le cache et les informations de
	 * session
	 */
	@Value("${redis.host}")
	private String redisHost;

	/**
	 * Injection de ports du REDIS pour sauvegarder le cache et les informations
	 * de session
	 */
	@Value("#{'${redis.ports}'.split(',')}")
	private List<Integer> redisPorts;

	/**
	 * Injection de la propri�t� pour sp�cifi� le domain pour le cookie de
	 * session Spring
	 */
	@Value("${security.session.cookie.domain}")
	private String domain;
	
	/**
	 * Injection de la propri�t� pour sp�cifi� le path pour le cookie de
	 * session Spring
	 */
	@Value("${security.session.cookie.path}")
	private String path;
	
	/**
	 * Injection du Type de cookie s�curis� ou pas
	 * Ne mettre false que pour un dev sur le poste local
	 * 
	 */
	@Value("${security.session.cookie.secure}")
	private boolean cookieSecure;

	/**
	 * Cr�ation du bean pour la connexion au REDIS
	 * 
	 * @return Une instance pour la gesion des connexions au REDIS
	 * @see {@link RedisConnectionFactory}
	 */
	@Bean
	RedisConnectionFactory jedisConnectionFactory() {
		boolean localRedis = redisPorts.size() == 1 && redisPorts.contains(6379) && redisHost.equals("127.0.0.1");
		
		if (localRedis){
			mostLogger.erreurWarn("Aucun port ou host redis sp�cifi�. Utilisation d'un REDIS local. D�veloppement local seulement");
			// Cas aucun port sp�cifi� ou aucun host. D�veloppement en local
			return new JedisConnectionFactory();
		} else if (redisPorts.size() > 1 && !redisHost.isEmpty()) {
			mostLogger.debugInfo("Utilisation d'un cluster REDIS");
			// Cas plusieurs port sp�cifi�s. Utilisation cluster REDIS
			Collection<String> clusterNodes = redisPorts.stream().map(port -> String.format("%s:%d", redisHost, port))
					.collect(Collectors.toList());
			return new JedisConnectionFactory(new RedisClusterConfiguration(clusterNodes));
		} else {
			throw new IllegalStateException("Le cache REDIS est mal configur�. V�rifi� votre configuration");
		}
	}

	/**
	 * Cr�ation du bean pour l'utilisation du cache REDIS
	 * 
	 * @param factory
	 *            Une factory de connexion au REDIS
	 * @return Un Redis template permettant la manipulation des objets dans le
	 *         cache REDIS
	 * @see {@link RedisTemplate}
	 */
	@Bean
	RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {
		SilentConnectionFailureRedisTemplate<String, Object> redisTemplate = new SilentConnectionFailureRedisTemplate<String, Object>();
		redisTemplate.setConnectionFactory(jedisConnectionFactory());
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashValueSerializer(new GenericToStringSerializer<Object>(Object.class));
		redisTemplate.setValueSerializer(new GenericToStringSerializer<Object>(Object.class));
		return redisTemplate;
	}

	/**
	 * Cr�ation du bean permettant la personnalisation du cookie de session
	 * Spring
	 * 
	 * @return
	 */
	@Bean
	public CookieSerializer cookieSerializer() {
		DefaultCookieSerializer serializer = new DefaultCookieSerializer();
		serializer.setCookieName(Constants.SESSION_ID_COOKIE);
		
		if (Objects.nonNull(path)) {
			serializer.setCookiePath(path);			
		}		
		
		if (Objects.nonNull(domain) && !domain.isEmpty()) {
			serializer.setDomainName(domain);			
		}

		serializer.setUseHttpOnlyCookie(true);
		serializer.setUseSecureCookie(cookieSecure);
		if (!cookieSecure) {
			serializer.setSameSite("Lax");
		}
		return serializer;
	}

	/**
	 * Cr�ation du bean permettant de sp�cifier que spring n'effectue aucune
	 * action de modification de configuration du REDIS
	 * 
	 * @return Un objet de configuration du REDIS
	 * @see {@link ConfigureRedisAction}
	 */
	@Bean
	public static ConfigureRedisAction configureRedisAction() {
		return ConfigureRedisAction.NO_OP;
	}

	/**
	 * Cr�ation du bean permettant la cr�ation du cache manager Redis
	 * 
	 * @param redisConnectionFactory
	 *            Une factory de connexion au REDIS
	 * @return Un cache manager
	 * @see {@link CacheManager}
	 */
	@Bean
	public CacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
		// Creation liste des caches
		Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<String, RedisCacheConfiguration>();
		
		// Cr�ation configuration par d�faut des caches
		RedisCacheConfiguration defaultCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig();
		
		// Ajout du cache pour la gestion des Refresh Token
		cacheConfigurations.put(Constants.TOKEN_CACHE, defaultCacheConfiguration.entryTtl(Duration.ofHours(12)).prefixKeysWith(Constants.TOKEN_KEY));
		
		return RedisCacheManager.builder(redisConnectionFactory)
				.cacheDefaults(defaultCacheConfiguration).withInitialCacheConfigurations(cacheConfigurations).build();
	}

}
