package fr.ca.cat.webapp.ihml.bff.filters;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.http.ErrorResponse;
import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;

/**
 * Filtre pour la gestion des erreurs
 * @author ET02720
 *
 */
public class ErrorHandlerFilter extends OncePerRequestFilter {

	public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		try {
			// S'il n'y a pas d'erreur dans l'appel de la requ�te on laisse passer
			chain.doFilter(request, response);
        } catch (Exception e) {

        	// S'il y a une erreur lors de l'appel de la requ�te on intercepte l'erreur pour la caster dans une reponse standard
            ErrorResponse errorResponse = new ErrorResponse();
            
            // Par d�faut on met un code erreur 500
            errorResponse.setStatus(500);
            
            // R�cup�ration du message de l'exception
            String message = e.getMessage();
            
            // Traitement particulier si c'est une ApiException
            if (e.getCause() instanceof ApiException) {
            	ApiException ex = (ApiException) e.getCause(); 
            	message = ex.getMessage();
            	errorResponse.setStatus(ex.getStatusCode());
            }
            
            errorResponse.setMessage(message);

            // Ecriture de la r�ponse
            response.setStatus(errorResponse.getStatus());
            response.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            response.getWriter().write(AppUtils.convertObjectToJsonString(errorResponse));
        }		
	}
}
