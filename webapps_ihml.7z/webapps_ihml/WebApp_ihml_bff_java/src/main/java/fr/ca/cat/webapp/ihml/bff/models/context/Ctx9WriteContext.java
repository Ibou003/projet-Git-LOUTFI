package fr.ca.cat.webapp.ihml.bff.models.context;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe pour d�finir le contexte renvoy� par l'API CTX9
 * @author ET02720
 *
 */
public class Ctx9WriteContext {
	
	/**
	 * Contexte de l'API CTX9 - UUID
	 * @see {@link Ctx9WriteContext#getContext()}
	 * @see {@link Ctx9WriteContext#setContext()}
	 */
	private String context;
	

	/**
	 * Retourne le contexte CTX9
	 * @return Un UUID
	 */
	@JsonProperty(value = "context_id")
	public String getContext() {
		return context;
	}

	/**
	 * Sp�cifie le contexte CTX9
	 * @param context Un contexte au format string
	 */
	@JsonProperty(value = "context_id")
	public void setContext(String context) {
		this.context = context;
	}
}
