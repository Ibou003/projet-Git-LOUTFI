package fr.ca.cat.webapp.ihml.bff.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.webapp.ihml.bff.models.manifest.ApplicationManifest;
import fr.ca.cat.webapp.ihml.bff.services.manifest.ManifestService;

/**
 * Controller pour la ressource g�rant la version de l'application
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/manifest")
public class ManifestController {

	@Autowired
	private ManifestService manifestService;
	
	/**
	 * R�cup�rer le manifest de l'application
	 * @return La version de l'application
	 * @throws IOException 
	 */
	@GetMapping("")
	public ResponseEntity<ApplicationManifest> getManifest() throws IOException {		
		return ResponseEntity.ok().body(manifestService.getManifest());
	}
	
}
