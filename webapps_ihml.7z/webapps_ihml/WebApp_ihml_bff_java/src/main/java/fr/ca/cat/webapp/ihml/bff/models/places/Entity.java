package fr.ca.cat.webapp.ihml.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Object d�finissant une ville d'une CR
 * @author ET02720
 *
 */
public class Entity {
	
	/**
	 * Nom de la ville
	 * @see Entity#getCityName()
	 * @see Entity#setCityName(String)
	 */
    private String cityName;
    
    /**
     * Code postal de la ville
     * @see Entity#getZipCode()
     * @see Entity#setZipCode(String)
     */
    private String zipCode;
    
    /**
     * Retourne le nom de la ville
     * @return Le nom de la ville
     */
    @JsonProperty(value = "city_name")
	public String getCityName() {
		return cityName;
	}
	
    /**
     * Met � jour le nom de la ville 
     * @param cityName Le nouveau nom de la ville
     */
    @JsonProperty(value = "city_name")
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
    /**
     * Retourne le code postal de la ville
     * @return Le code postal de la ville
     */
    @JsonProperty(value = "zip_code")
	public String getZipCode() {
		return zipCode;
	}
	
    /**
     * Met � jour le code postal de la ville
     * @param zipCode Le nouveau code postal de la ville
     */
    @JsonProperty(value = "zip_code")
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
    
}
