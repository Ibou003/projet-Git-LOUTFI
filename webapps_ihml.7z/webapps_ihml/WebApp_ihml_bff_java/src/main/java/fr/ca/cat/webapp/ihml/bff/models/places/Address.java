package fr.ca.cat.webapp.ihml.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet d�finissant une adresse d'une agence
 * @author ET02720
 *
 */
public class Address {

	/**
	 * Adresse de l'agence
	 * @see Address#getAddress()
	 * @see Address#setAddress(String)
	 */
	private String address;
	
	/**
	 * Nom de la ville de l'agence
	 * @see Address#getCityName()
	 * @see Address#setCityName(String)
	 */
	private String cityName;
	
	/**
	 * Code postal de l'agence
	 * @see Address#getZipCode();
	 * @see Address#setZipCode(String)
	 */
	private String zipCode;
	
	/**
	 * Code postal profressionel de l'agence
	 * @see Address#getBusinessZipCode()
	 * @see Address#setBusinessZipCode(String)
	 */
	private String businessZipCode;
	
	/**
	 * Retourne l'adresse
	 * @return Une adresse
	 */
	@JsonProperty(value = "address")
	public String getAddress() {
		return address;
	}
	
	/**
	 * Met � jour l'adress
	 * @param address Nouvelle adresse
	 */
	@JsonProperty(value = "address")
	public void setAddress(String address) {
		this.address = address;
	}
	
	/**
	 * Retourne le nom de la ville
	 * @return Le nom de a ville
	 */
	@JsonProperty(value = "city_name")
	public String getCityName() {
		return cityName;
	}
	
	/**
	 * Met � jour la nom de la ville
	 * @param cityName Le nouveau nom de la ville
	 */
	@JsonProperty(value = "city_name")
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
	/**
	 * Retourne le code postal
	 * @return Le code postal
	 */
	@JsonProperty(value = "zip_code")
	public String getZipCode() {
		return zipCode;
	}
	
	/**
	 * Met � jour le code postal
	 * @param zipCode Le nouveau code postal
	 */
	@JsonProperty(value = "zip_code")
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	/**
	 * Retourne le code postal professionel
	 * @return Le code postal professionel
	 */
	@JsonProperty(value = "business_zip_code")
	public String getBusinessZipCode() {
		return businessZipCode;
	}
	
	/**
	 * Met � jour le code postal professionnel
	 * @param businessZipCode Le nouveau code postal profressionnel
	 */
	@JsonProperty(value = "business_zip_code")
	public void setBusinessZipCode(String businessZipCode) {
		this.businessZipCode = businessZipCode;
	}	
}
