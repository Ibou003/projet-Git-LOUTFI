package fr.ca.cat.webapp.ihml.bff.models.places;

/**
 * Objet d�finissant un utilisateur
 * @author ET02720
 *
 */
public class User {
	/**
	 * Id de l'utilisateur
	 * @see User#getId()
	 * @see User#setId(String)
	 */
	private String id;

	/**
	 * label du poste fonctionnel
	 * @see User#getFpLabel()
	 * @see User#setFpLabel(String)
	 */
		private String fpLabel;
	
	/**
	 * Retourne l'Id de l'utilisateur
	 * @return L'Id de l'utilisateur
	 */
	public String getId() {
		return id;
	}

	/**
	 * Met � jour l'Id de l'utilisateur
	 * @param id Le nouveal Id de l'utilisateur
	 */
	public void setId(String id) {
		this.id = id;
	}

	public String getFpLabel() {
		return fpLabel;
	}

	public void setFpLabel(String fpLabel) {
		this.fpLabel = fpLabel;
	}
		
}
