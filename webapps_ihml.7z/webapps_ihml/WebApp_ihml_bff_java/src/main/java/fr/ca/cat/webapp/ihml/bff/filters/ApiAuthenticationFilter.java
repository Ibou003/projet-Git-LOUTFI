package fr.ca.cat.webapp.ihml.bff.filters;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;

import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.services.security.SecurityService;
import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;
import fr.ca.cat.webapp.ihml.bff.utils.Constants;

/**
 * Filtre pour la gestion de la s�curit� des ressources de l'application List
 * des API g�r�es par le filtre
 * <ul>
 * <li>/places/*</li>
 * </ul>
 * 
 * @author ET02720
 *
 */
public class ApiAuthenticationFilter extends AbstractFilter {

	@Autowired
	private SecurityService securityService;

	private MostLogger mostLogger = MostLogger.getLogger(ApiAuthenticationFilter.class);

	@Override
	public List<String> getFilterUrls() {
		return Arrays.asList("\\/\\bplaces\\b.*", "\\/\\bcontext\\b.*");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;	

		// Par d�faut on laisse passer la requ�te
		boolean refreshTokenNeeded = false;

		// Application du filtre seulement si la requ�te n'est pas de type
		// OPTIONS.
		if (matchPatternUrls(httpServletRequest)
				&& !httpServletRequest.getMethod().equals(HttpMethod.OPTIONS.toString())) {
			mostLogger.debugInfo(
					String.format("L'acc�s � l'URL %s est g�r�e par le filtre: API", httpServletRequest.getPathInfo()));

			// R�cup�ration de la cl� d'expiration du token de la session
			Object expiresKey = httpServletRequest.getSession().getAttribute(Constants.EXPIRES_AT_KEY);
			long sessionExpirationDateInMilli = Objects.nonNull(expiresKey) ? (long) expiresKey : 0;

			if (sessionExpirationDateInMilli > 0) {
				// Cl� valide. On calcul la date d'expiration
				LocalDateTime sessionExpirationDate = AppUtils.dateFromMilliseconds(sessionExpirationDateInMilli);

				// on se laisse 30 secondes de marge pour que l' access token ne
				// devienne pas invalide au milieu d'une s�quence d'appels
				LocalDateTime threshold = LocalDateTime.now().plusSeconds(30);

				if (threshold.isAfter(sessionExpirationDate)) {
					// Si la session va expir� dans 30 seconds on demande le
					// refresh du token
					refreshTokenNeeded = true;
					mostLogger.debugInfo(String.format(
							"L'access token de la session %s va expir� dans 30 secondes. On demande le refresh du token",
							httpServletRequest.getSession().getId()));
				}
				mostLogger.debugInfo(String.format("L'access token de la session %s est autoris� � acc�der � l'URL %s",
						httpServletRequest.getSession().getId(), httpServletRequest.getPathInfo()));
			} else {
				// Si la session a expir�. Pas d'action depuis le TTL, on
				// demande le refresh du token car l'access_token n'est plus
				// disponible
				refreshTokenNeeded = true;
				mostLogger.debugInfo(
						String.format("L'access token de la session %s a expir�. On demande le refresh du token",
								httpServletRequest.getSession().getId()));
			}
		}

		if (refreshTokenNeeded) {
			try {
				// R�cup�ration du cookie STATE pour avoir le refreshToken
				Map<String, Cookie> requestCookies = this.getRequestCookies(httpServletRequest);
				String state = requestCookies.get(Constants.STATE_COOKIE).getValue();

				// Demande de refresh token
				this.securityService.refreshToken(httpServletRequest.getSession(), state);
			} catch (Exception e) {
				// Une erreur est intervenue dans la demande du refresh_token.
				// On rejete la requ�te
				mostLogger.erreurWarn(e.getMessage());
				writeResponse(HttpStatus.SC_UNAUTHORIZED, Constants.ACCESS_UNAUTHORIZED_RESPONSES, (HttpServletResponse) response);
				
				// On return pour casser la chaine de filtrage et renvoyer la r�ponse directement
				return;
			}
		}
		
		chain.doFilter(request, response);
	}

	/**
	 * Mapping des cookies de la requ�te
	 * 
	 * @param request
	 *            Requ�te entrante
	 * @param response
	 *            R�ponse sortante
	 * @return Une map des cookies avec comme cl� le nom du cookie
	 * @throws IOException
	 */
	private Map<String, Cookie> getRequestCookies(HttpServletRequest request) {

		Map<String, Cookie> cookies;
		if (Objects.isNull(request.getCookies())) {
			throw new IllegalArgumentException(
					String.format("Aucun cookie pr�sent dans pour la requ�te %s pour la session: %s",
							request.getPathInfo(), request.getSession().getId()));
		} else {
			cookies = Arrays.asList(request.getCookies()).stream()
					.collect(Collectors.toMap(cookie -> cookie.getName(), cookie -> cookie));

			// Test si le cookie SESSION_ID est pr�sent dans la requ�te
			if (!cookies.containsKey(Constants.SESSION_ID_COOKIE)) {
				throw new IllegalArgumentException(
						String.format("Cookie %s non pr�sent dans pour la requ�te %s pour la session: %s",
								Constants.SESSION_ID_COOKIE, request.getPathInfo(), request.getSession().getId()));

			}

			// Test si le cookie SESSION_ID est pr�sent dans la requ�te
			if (!cookies.containsKey(Constants.STATE_COOKIE)) {
				throw new IllegalArgumentException(
						String.format("Cookie %s non pr�sent dans pour la requ�te %s pour la session: %s",
								Constants.STATE_COOKIE, request.getPathInfo(), request.getSession().getId()));
			}
		}

		return cookies;

	}
}
