package fr.ca.cat.webapp.ihml.bff.filters;

import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import fr.ca.cat.webapp.ihml.bff.models.http.ErrorResponse;
import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;

/**
 * Classe abstraite pour g�n�rer un Filtre de requ�te
 * 
 * @see Filter
 * @author ET02720
 *
 */
public abstract class AbstractFilter implements Filter {
	
	protected List<String> filterUrls;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// Initialisation des urls g�r�es par le filtre
		this.filterUrls = this.getFilterUrls();
		
		// N�cessaire pour l'injection des objets spring
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
	}

	@Override
	public void destroy() {}
	
	/**
	 * Retourne une liste de pattern des URL g�r�es par le filtre
	 * @return List<String> Liste de pattern d'URL
	 */
	abstract List<String> getFilterUrls(); 
	
	/**
	 * Test si l'url de la requ�te est g�r�e par le filtre 
	 * @param request La req�ete entrante
	 * @return True si le path de la requ�te match @see {@link AbstractFilter#getFilterUrls()}
	 */
	protected boolean matchPatternUrls(HttpServletRequest request) {
		return filterUrls.stream().filter(pattern -> Pattern.matches(pattern, request.getPathInfo())).count() > 0;
	}
	
	/**
	 * Permet de construire une r�ponse HTTP
	 * 
	 * @param statusCode code HTTP de la r�ponse
	 * @param message Message de la r�ponse
	 * @param response La r�ponse
	 * @throws IOException
	 */
	protected void writeResponse(int statusCode, String message, HttpServletResponse response) throws IOException {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setStatus(statusCode);
        errorResponse.setMessage(message);
        response.setStatus(errorResponse.getStatus());
        response.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(AppUtils.convertObjectToJsonString(errorResponse));
	}

}
