package fr.ca.cat.webapp.ihml.bff.services;

import java.io.IOException;
import java.util.Objects;

import javax.annotation.PreDestroy;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;

/**
 * Service exposant un Apache HTTP client
 * 
 * @author ET02720
 *
 */
public class HttpService {

	private MostLogger mostLogger = MostLogger.getLogger(HttpService.class);

	/**
	 * Le client Apache HTTP
	 * 
	 * @see {@link HttpClient}
	 */
	private CloseableHttpClient httpClient;

	public HttpService() {
		// Cr�ation du client avec les options du nombre de connexions
		this.httpClient = HttpClients.custom().setMaxConnTotal(100).setMaxConnPerRoute(20).build();
	}

	public HttpClient getHttpClient() {
		return httpClient;
	}

	@PreDestroy
	public void teardown() throws IOException {
		// On supprime le client � l'arr�t de l'application
		this.httpClient.close();
	}

	/**
	 * Permet l'execution d'une requ�te HTTP et de g�rer les exceptions si la
	 * requ�te est en erreur puis retourne le corps de r�ponse mapper sur un
	 * type d'objet souhait�
	 * 
	 * @param request
	 *            La requ�te HTTP a ex�cuter
	 * @param reponseValueType
	 *            Le type de l'objet � retourner
	 * @return Une reponse HTTP
	 * @throws IOException
	 *             S'il y a une erreur lors de la conversion du body de le
	 *             r�ponse en JSON
	 * @throws ApiException
	 *             Si le code retour de la requ�te n'est pas 200
	 * @see {@link HttpRequestBase}
	 * @see {@link HttpResponse}
	 */
	public <T> T execute(HttpRequestBase request, Class<T> reponseValueType) throws IOException, ApiException {
		T responseObj = null;
		CloseableHttpResponse response = this.httpClient.execute(request);
		try {
			if (response.getStatusLine().getStatusCode() >= 400) {
				mostLogger.erreurWarn(String.format("Erreur lors de l'ex�cution de la requ�te %s. Code retour %d",
						request.getURI().getPath(), response.getStatusLine().getStatusCode()));
				// On cr�� une ApiException si le code retour de la requ�te est
				// un
				// code d'erreur
				throw new ApiException(response.getStatusLine().getStatusCode(),
						AppUtils.prettifyJsonString(EntityUtils.toString(response.getEntity())));
			} else if (Objects.nonNull(reponseValueType)) {
				// Si l'on souhaite mapper le corps de la r�ponse
				responseObj = AppUtils.mapResponse(response, reponseValueType);
			} else {
				// Si l'on ne souhaite pas mapper le cors de la r�ponse on lit
				// qd meme le contenu pour ne pas bloquer le client
				EntityUtils.consumeQuietly(response.getEntity());
			}
		} finally {
			response.close();
		}

		return responseObj;
	}

}
