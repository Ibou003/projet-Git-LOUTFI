package fr.ca.cat.webapp.ihml.bff.react.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet d�finissant un contact
 * @author ET02720
 *
 */
public class Contact {

	/**
	 * Adresse email du contact
	 * @see Contact#getEmailAddress()
	 * @see Contact#setEmailAddress(String)
	 */
	private String emailAddress;
	
	/**
	 * Num�ro de t�l�hone du contact
	 * @see Contact#getPhoneNumber()
	 * @see Contact#setPhoneFee(String)
	 */
	private String phoneNumber;
	
	/**
	 * Cout appel t�l�phone
	 * @see Contact#getPhoneFee()
	 * @see Contact#setPhoneFee(String)
	 */
	private String phoneFee;
	
	/**
	 * Num�ro de fax
	 * @see Contact#getFax()
	 * @see Contact#setFax(String)
	 */
	private String fax;
	
	/**
	 * Retourne l'email du contact
	 * @return L'email du contact
	 */
	@JsonProperty(value = "email_address")
	public String getEmailAddress() {
		return emailAddress;
	}
	
	/**
	 * Met � jour l'email du contact
	 * @param emailAddress Le nouvel email du contact
	 */
	@JsonProperty(value = "email_address")
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	/**
	 * Retourne le numero de t�l�phone du contact
	 * @return Le num�ro de t�l�phone du contact
	 */
	@JsonProperty(value = "phone_number")
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	/**
	 * Met � jour le num�ro de t�l�phone du contact
	 * @param phoneNumber Le nouveau numero de t�l�phone
	 */
	@JsonProperty(value = "phone_number")
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	/**
	 * Retourne la taxe d'appel
	 * @return La taxe d'appel
	 */
	@JsonProperty(value = "phone_fee")
	public String getPhoneFee() {
		return phoneFee;
	}
	
	/**
	 * Met � jour la taxe d'appel
	 * @param phoneFee La nouvelle taxe d'appel
	 */
	@JsonProperty(value = "phone_fee")
	public void setPhoneFee(String phoneFee) {
		this.phoneFee = phoneFee;
	}
	
	/**
	 * Retourne la num�ro de fax du contact
	 * @return Le num�ro de fax
	 */
	@JsonProperty(value = "fax")
	public String getFax() {
		return fax;
	}
	
	
	/**
	 * Met � jour le num�ro de fax du contact
	 * @param fax Le nouveau num�ro de fax
	 */
	@JsonProperty(value = "fax")
	public void setFax(String fax) {
		this.fax = fax;
	}
}
