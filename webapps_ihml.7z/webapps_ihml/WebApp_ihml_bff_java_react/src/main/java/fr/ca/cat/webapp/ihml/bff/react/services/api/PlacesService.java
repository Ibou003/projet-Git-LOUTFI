package fr.ca.cat.webapp.ihml.bff.react.services.api;

import java.io.IOException;

import org.apache.http.client.methods.HttpGet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.react.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.react.models.places.CR;
import fr.ca.cat.webapp.ihml.bff.react.models.places.DistributionEntity;
import fr.ca.cat.webapp.ihml.bff.react.models.places.Entity;
import fr.ca.cat.webapp.ihml.bff.react.utils.Constants;

/**
 * Service pour appeler les ressources de l'API Places
 * @author ET02720
 *
 */
public class PlacesService extends ApiService {
	
	private MostLogger mostLogger = MostLogger.getLogger(PlacesService.class); 

	/**
	 * Injection de la propri�t� qui r�f�rence l'url de l'API Places
	 */
	@Value("${service.places}")
	private String placesUrl;

	
	/**
	 * Retourne la liste des CR
	 * @return La liste des CR
	 * @throws IOException
	 * @throws ApiException
	 * @see {@link CR}
	 */
	public CR[] getCRList() throws IOException, ApiException {
		mostLogger.debugInfo("R�cup�ration de la list des CR");
		
		// Construction de la requ�te
		HttpGet getCRRequest = new HttpGet(String.format(Constants.REGINONAL_BANKS_URL, placesUrl));
		
		// Set security Headers
		this.addSecurityRequestHeader(getCRRequest);
		
		// Set other headers
		getCRRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
		
	    // Execution de la requete
		CR[] crs = this.httpService.execute(getCRRequest, CR[].class);
	    
	    // Mapping de la r�ponse de la requ�te
		mostLogger.debugInfo("R�cup�ration de la list des CR --> OK");
		return crs;
	}
	
	/**
	 * Retourne la liste des villes d'une CR
	 * @param crId Id de la CR
	 * @return La liste des villes d'une CR
	 * @throws IOException
	 * @throws ApiException
	 * @see {@link Entity}
	 */
	public Entity[] getCREntities(String crdId) throws IOException, ApiException {
		mostLogger.debugInfo(String.format("R�cup�ration des villes de la CR: %s", crdId));
		
		// Construction de la requ�te
		HttpGet getCREntitiesRequest = new HttpGet(String.format(Constants.CITIES_WIHT_DISTRIBUTION_ENTITIES, placesUrl, crdId));
		
		// Set security Headers
		this.addSecurityRequestHeader(getCREntitiesRequest);
		
		// Set other headers
		getCREntitiesRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
		
	    // Execute request
		Entity[] entities = this.httpService.execute(getCREntitiesRequest, Entity[].class);
	    
	    // Mapping de la r�ponse
		mostLogger.debugInfo(String.format("R�cup�ration des villes de la CR: %s --> OK", crdId));
		return entities;
	}
	
	/**
	 * Retourne la liste des agences pour une ville d'une CR
	 * @param crId L'Id de la CR
	 * @param zipCode Le code postal de la ville
	 * @return La liste des agences d'une ville d'une CR
	 * @throws IOException
	 * @throws ApiException
	 * @see {@link DistributionEntity}
	 */
	public DistributionEntity[] getCRAgencesList(String crId, String zipCode) throws IOException, ApiException {
		mostLogger.debugInfo(String.format("R�cup�ration des agences de la CR: %s pour la ville %s", crId, zipCode));
		
		// Construction de la requ�te
		HttpGet getDistributionEntitiesRequest = new HttpGet(String.format(Constants.DISTRIBUTION_ENTITIES_SEARCH_BY_CITY, placesUrl, crId, zipCode));
		
		// Set security Headers
		this.addSecurityRequestHeader(getDistributionEntitiesRequest);
		
		// Set other headers
		getDistributionEntitiesRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
		
	    // Execute request
		DistributionEntity[] distributionEntities = this.httpService.execute(getDistributionEntitiesRequest, DistributionEntity[].class);
	    
	    // Mapping de la r�ponse
		mostLogger.debugInfo(String.format("R�cup�ration des agences de la CR: %s pour la ville %s --> OK", crId, zipCode));
		return distributionEntities;
	}
}
