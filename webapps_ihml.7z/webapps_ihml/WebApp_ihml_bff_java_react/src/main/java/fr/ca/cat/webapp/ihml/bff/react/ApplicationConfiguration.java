package fr.ca.cat.webapp.ihml.bff.react;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import fr.ca.cat.webapp.ihml.bff.react.models.manifest.ApplicationManifest;
import fr.ca.cat.webapp.ihml.bff.react.services.HttpService;
import fr.ca.cat.webapp.ihml.bff.react.services.api.ContextService;
import fr.ca.cat.webapp.ihml.bff.react.services.api.PlacesService;
import fr.ca.cat.webapp.ihml.bff.react.services.manifest.ManifestService;
import fr.ca.cat.webapp.ihml.bff.react.services.security.RefreshTokenCacheService;
import fr.ca.cat.webapp.ihml.bff.react.services.security.SecurityService;

/**
 * Classe principale de configuration de l'application
 * Utilis�e pour d�clarer les Bean spring
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "fr.ca.cat.webapp.ihml.bff")
@PropertySource("classpath:application.properties")
public class ApplicationConfiguration {
	
	/**
	 * Bean pour le service g�rant la s�curit�
	 * @return {@link SecurityService}
	 */
	@Bean
	public SecurityService securityService() {
		return new SecurityService();
	}
	
	/**
	 * Bean pour le service g�rant l'appel � l'API Places
	 * @return {@link PlacesService}
	 */
	@Bean
	public PlacesService placesService() {
		return new PlacesService();
	}
	
	/**
	 * Bean pour le service g�rant l'appel � l'API Places
	 * @return {@link PlacesService}
	 */
	@Bean
	public ContextService contextService() {
		return new ContextService();
	}
	
	/**
	 * Bean pour le service g�rant l'acc�s au cache Redis
	 * @return {@link RefreshTokenCacheService}
	 */
	@Bean
	public RefreshTokenCacheService redisService() {
		return new RefreshTokenCacheService();
	}
	
	/**
	 * Bean pour le service Http
	 * @return {@link HttpService}
	 */
	@Bean
	public HttpService httpService() {
		return new HttpService();
	}
	
	/**
	 * Bean pour le service Manifest
	 * @return {@link ApplicationManifest}
	 */
	@Bean
	public ManifestService manifestService() {
		return new ManifestService();
	}
}