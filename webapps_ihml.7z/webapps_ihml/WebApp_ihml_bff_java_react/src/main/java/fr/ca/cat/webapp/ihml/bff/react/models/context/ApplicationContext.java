package fr.ca.cat.webapp.ihml.bff.react.models.context;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;

import fr.ca.cat.webapp.ihml.bff.react.utils.AppUtils;

public class ApplicationContext {
	
	/**
	 * le client Id de l'application cibl�e
	 * @see ApplicationContext#getClientId()
	 * @see ApplicationContext#setClientId(string)
	 */
	private String clientId;
	
	/**
	 * Id de la CR
	 * @see ApplicationContext#getRegionalBankId()
	 * @see ApplicationContext#setRegionalBankId(String)
	 */
	private String regionalBankId;
	
    /**
     * Code postal de la ville
     * @see ApplicationContext#getZipCode()
     * @see ApplicationContext#setZipCode(String)
     */
    private String zipCode;
    
	/**
	 * Retourne le client Id de l'application cibl�e
	 * @return L'idClient de l'application cibl�e
	 */
	@JsonProperty(value = "client_id", required = false)
	public String getClientId() {
		return clientId;
	}
	
	/**
	 * Met � jour le client Id  de l'application cibl�e
	 * @param clientId Le nouvel client Id  de l'application cibl�e
	 */
	@JsonProperty(value = "client_id", required = false)
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	/**
	 * Retourne l'Id de la CR
	 * @return L'Id de la CR
	 */
	@JsonProperty(value = "regional_bank_id", required = false)
	public String getRegionalBankId() {
		return regionalBankId;
	}
	
	/**
	 * Met � jour l'Id de la CR
	 * @param regionalBankId Le nouvel Id de la CR
	 */
	@JsonProperty(value = "regional_bank_id", required = false)
	public void setRegionalBankId(String regionalBankId) {
		this.regionalBankId = regionalBankId;
	}
	
    /**
     * Retourne le code postal de la ville
     * @return Le code postal de la ville
     */
    @JsonProperty(value = "zip_code", required = false)
	public String getZipCode() {
		return zipCode;
	}
	
    /**
     * Met � jour le code postal de la ville
     * @param zipCode Le nouveau code postal de la ville
     */
    @JsonProperty(value = "zip_code", required = false)
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
    
    public String toJsonString() throws JsonProcessingException {
    	return AppUtils.convertObjectToJsonString(this);
    }
}
