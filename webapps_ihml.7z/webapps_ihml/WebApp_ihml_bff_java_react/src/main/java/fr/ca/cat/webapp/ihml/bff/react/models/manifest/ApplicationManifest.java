package fr.ca.cat.webapp.ihml.bff.react.models.manifest;

/**
 * Classe pour d�finir le manifest de l'application
 * @author ET02720
 *
 */
public class ApplicationManifest {
	
	/**
	 * La version de l'application
	 * @see ApplicationManifest#getVersion()
	 * @see ApplicationManifest#setVersion(String)
	 */
	private String version;
	
	/**
	 * Le type de framework de l'application
	 * @see ApplicationManifest#getFramework()
	 * @see ApplicationManifest#setFramework(String)
	 */
	private String framework;

	/**
	 * R�cup�ration de la version
	 * @return La version de l'application
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Sp�cifier la version de l'application
	 * @param version
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * R�cup�rer le framework de l'application
	 * @return Le framework de l'application
	 */
	public String getFramework() {
		return framework;
	}

	/**
	 * Sp�cifier le framework de l'application
	 * @param framework
	 */
	public void setFramework(String framework) {
		this.framework = framework;
	}
	
}
