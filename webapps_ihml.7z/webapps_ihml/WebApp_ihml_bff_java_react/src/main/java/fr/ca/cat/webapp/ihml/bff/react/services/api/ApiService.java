package fr.ca.cat.webapp.ihml.bff.react.services.api;

import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.apache.http.client.methods.HttpRequestBase;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;

import fr.ca.cat.webapp.ihml.bff.react.services.HttpService;
import fr.ca.cat.webapp.ihml.bff.react.utils.Constants;

/**
 * Classe parente pour d�clar� les Services n�cessitant l'acc�s aux API
 * @author ET02720
 *
 */
public class ApiService {
	
	/**
	 * Inject du HttpService
	 * @see {@link HttpService}
	 */
	@Autowired
	protected HttpService httpService;

	/**
	 * Injection de la session Http Spring
	 */
	@Autowired
	private HttpSession httpSession;
	
	/**
	 * Injection de la propri�t� qui r�f�rence la CATS Consommateur
	 */
	@Value("${security.catsConsommateur}")
	private String catsConsommateur;
	
	/**
	 * Injection de la propri�t� qui r�f�rence la CATS Consommateur Origine
	 */
	@Value("${security.catsConsommateurorigine}")
	private String catsConsommateurorigine;
	
	/**
	 * Injection de la propri�t� qui r�f�rence la CATS Canal
	 */
	@Value("${security.catsCanal}")
	private String catsCanal;
	
	/**
	 * Permet l'ajout des Header n�cessaires � l'appel aux API
	 * @param request La requ�te a ex�cuter
	 * @param catsConsommateur Le Header CATS consommateur
	 */
	protected void addSecurityRequestHeader(HttpRequestBase request) {
		
		request.addHeader(HttpHeaders.AUTHORIZATION, String.format("Bearer %s", httpSession.getAttribute(Constants.ACCESS_TOKEN_KEY)));
		request.addHeader(Constants.CORRELATION_ID_HEADER, UUID.randomUUID().toString());
		request.addHeader(Constants.CATS_CONSOMMATEUR_HEADER, catsConsommateur);
		request.addHeader(Constants.CATS_CONSOMMATEUR_ORIGINE_HEADER, catsConsommateurorigine);
		request.addHeader(Constants.CATS_CANAL_HEADER, catsCanal);
	}
}
