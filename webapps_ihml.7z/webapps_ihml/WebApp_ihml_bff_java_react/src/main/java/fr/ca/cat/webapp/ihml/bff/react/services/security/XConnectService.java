package fr.ca.cat.webapp.ihml.bff.react.services.security;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import fr.ca.cat.webapp.ihml.bff.react.services.HttpService;

public class XConnectService {
	
	/**
	 * Injection de la propri�t� clientId de l'application
	 */
	@Value("${security.cliendID}")
	protected String clientId;

	/**
	 * Injection de la propri�t� secretId de l'application
	 */
	@Value("${security.secretID}")
	protected String secretId;

	/**
	 * Inject de la propri�t� CATS consommateur
	 */
	@Value("${security.catsConsommateur}")
	protected String catsConsommateur;

	/**
	 * Inject de la propri�t� CATS consommateur origine
	 */
	@Value("${security.catsConsommateurorigine}")
	protected String catsConsommateurorigine;

	/**
	 * Inject de la propri�t� CATS canal
	 */
	@Value("${security.catsCanal}")
	protected String catsCanal;

	/**
	 * Injection de la propri�t� qui r�f�rence l'url de l'API AUC9
	 */
	@Value("${service.auc9}")
	protected String auc9Url;
	
	/**
	 * Injection du HttpService
	 * @see {@link HttpService}
	 */
	@Autowired
	protected HttpService httpService;
	
	/**
	 * G�n�re la cl� pour le Header Authorization � partir du clientId et du secretId de l'application
	 * @return La cl� Base64 pour le Header Authorization pour les requ�tes � l'API
	 */
	protected String getAuthorizationToken() {
		return Base64.getEncoder()
				.encodeToString((String.format("%s:%s", clientId, secretId).getBytes()));
	}
	
	

}
