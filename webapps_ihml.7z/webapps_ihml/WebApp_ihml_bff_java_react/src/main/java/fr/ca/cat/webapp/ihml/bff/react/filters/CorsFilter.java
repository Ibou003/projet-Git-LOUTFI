package fr.ca.cat.webapp.ihml.bff.react.filters;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.web.filter.OncePerRequestFilter;

import fr.ca.cat.webapp.ihml.bff.react.utils.Constants;

/**
 * Filtre pour la gestion des CORS
 * 
 * @author ET02720
 *
 */
public class CorsFilter extends OncePerRequestFilter {

	@Override
	public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		// Liste des Headers autoris�s
		List<String> allowHeaders = new ArrayList<>();
		allowHeaders.add(HttpHeaders.AUTHORIZATION);
		allowHeaders.add(HttpHeaders.CONTENT_TYPE);
		allowHeaders.add(Constants.STATE_HEADER);
		allowHeaders.add(Constants.REDIRECT_URL_HEADER);

		// Ajout des Headers CORS
		response.setHeader("Access-Control-Allow-Origin", request.getHeader(HttpHeaders.ORIGIN));
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
		response.setHeader("Access-Control-Max-Age", "2147483647");
		response.setHeader("Access-Control-Allow-Headers", String.join(",", allowHeaders));
		response.setHeader("Access-Control-Allow-Credentials", "true");
		chain.doFilter(request, response);
	}

}
