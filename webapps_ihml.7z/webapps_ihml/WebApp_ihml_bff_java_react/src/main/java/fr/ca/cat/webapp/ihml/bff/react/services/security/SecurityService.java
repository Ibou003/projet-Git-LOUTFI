package fr.ca.cat.webapp.ihml.bff.react.services.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.react.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.react.models.places.User;
import fr.ca.cat.webapp.ihml.bff.react.models.security.OAuthToken;
import fr.ca.cat.webapp.ihml.bff.react.utils.AppUtils;
import fr.ca.cat.webapp.ihml.bff.react.utils.Constants;

/**
 * Service pour g�rer la s�curit� de l'application
 * @author ET02720
 *
 */
public class SecurityService extends XConnectService {

	private MostLogger mostLogger = MostLogger.getLogger(SecurityService.class);


	/**
	 * Injection du RefreshTokenCacheService
	 */
	@Autowired
	protected RefreshTokenCacheService refreshTokenCacheService;

	/**
	 * Retourne le refresh token li� � un state
	 * @param state Cl� pour retrouver le refresh token dansle cache REDIS  (valeur obtenue � partie du cookie STATE)
	 * @return La valeur du refresh token
	 */
	public String getRefreshToken(String state) {
		return this.refreshTokenCacheService.isRefreshTokenKeyExist(state) ? this.refreshTokenCacheService.getRefreshToken(state) : null;
	}

	/**
	 * Permet de r�cup�rer un access token aupr�s de l'API AUC9
	 * @param code Autorization Code renvoy�e par la mire X Connect
	 * @param redirectUrl Url de redirection de l'application founie � X Connect
	 * @param state Id de "session" fourni lors de la connexion � la mire X Connec
	 * @param httpSession Spring Session
	 * @throws ApiException
	 * @throws IOException
	 */
	public void login(String code, String redirectUrl, String state, HttpSession httpSession)
			throws ApiException, IOException {
		mostLogger.debugInfo(String.format("Demande de jeton OAuth pour la session %s", httpSession.getId()));

		// Construction de la requ�te
		HttpPost postTokenRequest = new HttpPost(String.format(Constants.OPENID_TOKEN_URL, auc9Url));

		// Set Headers
		postTokenRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
		postTokenRequest.addHeader(HttpHeaders.AUTHORIZATION, String.format("Basic %s", this.getAuthorizationToken()));
		postTokenRequest.addHeader(Constants.CORRELATION_ID_HEADER, UUID.randomUUID().toString());
		postTokenRequest.addHeader(Constants.CATS_CONSOMMATEUR_HEADER, catsConsommateur);
		postTokenRequest.addHeader(Constants.CATS_CONSOMMATEUR_ORIGINE_HEADER, catsConsommateurorigine);
		postTokenRequest.addHeader(Constants.CATS_CANAL_HEADER, catsCanal);

		// Set Body
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair(Constants.GRANT_TYPE_PARAM, Constants.AUTORIZATION_CODE_VALUE));
		params.add(new BasicNameValuePair(Constants.SCOPE_PARAM, Constants.SCOPE_VALUE));
		params.add(new BasicNameValuePair(Constants.CODE_PARAM, code));
		params.add(new BasicNameValuePair(Constants.REDIRECT_URI_PARAM, redirectUrl));
		postTokenRequest.setEntity(new UrlEncodedFormEntity(params));

		// Execute request
		OAuthToken oAuthToken = this.httpService.execute(postTokenRequest, OAuthToken.class);
		oAuthToken.setUser(this.getUserFromTokenId(oAuthToken.getIdToken()));		

		// Sauvegarde de l'access token, du user et de la date d'expiration dans la session (et donc REDIS)
		httpSession.setAttribute(Constants.ACCESS_TOKEN_KEY, oAuthToken.getAccessToken());
		httpSession.setAttribute(Constants.USER_ID_KEY, oAuthToken.getUser().getId());
		httpSession.setAttribute(Constants.USER_FPLABEL_KEY, oAuthToken.getUser().getFpLabel());
		httpSession.setAttribute(Constants.EXPIRES_AT_KEY, AppUtils.delayFromNowToMilliseconds(oAuthToken.getExpiresIn()));

		// Sauvegarde de refresh token dans le cache REDIS
		this.refreshTokenCacheService.storeRefreshToken(state, oAuthToken.getRefreshToken());

		mostLogger.debugInfo(String.format("Demande de jeton OAuth pour la session %s --> OK", httpSession.getId()));
	}

	/**
	 * Gestion de la d�connexion
	 * @param httpSession Spring Session
	 * @param state Id de "session" fourni lors de la connexion � la mire X Connec
	 * @throws IOException
	 * @throws ApiException
	 */
	public void logout(HttpSession httpSession, String state) throws IOException, ApiException {
		mostLogger.debugInfo(String.format("Demande de d�connexion pour la session %s" ,httpSession.getId()));
		
		// R�vocation du refresh token li� � la session		
		this.revokeSession(httpSession, state);
		
		mostLogger.debugInfo(String.format("Demande de d�connexion pour la session %s --> OK" ,httpSession.getId()));
	}
	
	/**
	 * Permet la revocation du refresh token li� � la session en cours
	 * @param httpSession Spring session
	 * @param state Cl� pour retrouver le refresh token dans le cache REDIS
	 * @throws IOException
	 * @throws ApiException
	 */
	public void revokeSession(HttpSession httpSession, String state) throws IOException, ApiException {
		mostLogger.debugInfo(String.format("Revocation du refresh token pour la session %s et la cl� %s", httpSession.getId(), state));

		// R�cup�ration du refresh token
		String refreshToken = this.getRefreshToken(state);
		
		if (Objects.nonNull(refreshToken)) {
			// Construction de la requ�te
			HttpPost postTokenRequest = new HttpPost(String.format(Constants.OPENID_REVOKE_URL, auc9Url));

			// Set Headers
			postTokenRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
			postTokenRequest.addHeader(HttpHeaders.AUTHORIZATION,  String.format("Basic %s", this.getAuthorizationToken()));
			postTokenRequest.addHeader(Constants.CORRELATION_ID_HEADER, UUID.randomUUID().toString());
			postTokenRequest.addHeader(Constants.CATS_CONSOMMATEUR_HEADER, catsConsommateur);
			postTokenRequest.addHeader(Constants.CATS_CONSOMMATEUR_ORIGINE_HEADER, catsConsommateurorigine);
			postTokenRequest.addHeader(Constants.CATS_CANAL_HEADER, catsCanal);

			// Set Body
			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair(Constants.TOKEN_PARAM, this.refreshTokenCacheService.getRefreshToken(state)));
			postTokenRequest.setEntity(new UrlEncodedFormEntity(params));

			// Execute request
			this.httpService.execute(postTokenRequest, null);
			
			// Suppression de la cl� dans le cache REDIS
			this.refreshTokenCacheService.deleteRefreshToken(state);
			mostLogger.debugInfo(String.format("Revocation du refresh token pour la session %s et la cl� %s --> OK", httpSession.getId(), state));			
		} else {
			mostLogger.erreurWarn(String.format("Aucune refresh token trouv� pour la session %s et la cl� %s", httpSession.getId(), state));
		}

		// Invalidation de la session spring
		httpSession.invalidate();
	}
	

	/**
	 * Permet le renouvellement de l'access token � partir du refresh token
	 * @param httpSession Spring session
	 * @param refreshToken Le refresh toke
	 * @throws ApiException
	 * @throws IOException
	 */
	public void refreshToken(HttpSession httpSession, String state) throws ApiException, IOException {
		mostLogger.debugInfo(String.format("Renouvellement de l'access token pour la session %s et la cl� %s", httpSession.getId(), state));

		mostLogger.debugInfo(String.format("R�cup�ration du refresh token pour la session %s et la cl� %s", httpSession.getId(), state));
		String refreshToken = this.getRefreshToken(state);
		if (Objects.nonNull(refreshToken)) {
			
			// Construction de la requ�te
			HttpPost postTokenRequest = new HttpPost(String.format(Constants.OPENID_TOKEN_URL, auc9Url));

			// Set Headers
			postTokenRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
			postTokenRequest.addHeader(HttpHeaders.AUTHORIZATION,  String.format("Basic %s", this.getAuthorizationToken()));
			postTokenRequest.addHeader(Constants.CORRELATION_ID_HEADER, UUID.randomUUID().toString());
			postTokenRequest.addHeader(Constants.CATS_CONSOMMATEUR_HEADER, catsConsommateur);
			postTokenRequest.addHeader(Constants.CATS_CONSOMMATEUR_ORIGINE_HEADER, catsConsommateurorigine);
			postTokenRequest.addHeader(Constants.CATS_CANAL_HEADER, catsCanal);

			// Set Body
			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair(Constants.GRANT_TYPE_PARAM, Constants.REFRESH_TOKEN_VALUE));
			params.add(new BasicNameValuePair(Constants.SCOPE_PARAM, Constants.SCOPE_VALUE));
			params.add(new BasicNameValuePair(Constants.REFRESH_TOKEN_PARAM, refreshToken));
			postTokenRequest.setEntity(new UrlEncodedFormEntity(params));

			// Execute request
			OAuthToken oAuthToken = this.httpService.execute(postTokenRequest, OAuthToken.class);
			oAuthToken.setUser(this.getUserFromTokenId(oAuthToken.getIdToken()));
			
			// Sauvegarde du nouvel access token, du user et de la date d'expiration dans la session (et donc REDIS)
			httpSession.setAttribute(Constants.ACCESS_TOKEN_KEY, oAuthToken.getAccessToken());
			httpSession.setAttribute(Constants.USER_ID_KEY, oAuthToken.getUser().getId());
			httpSession.setAttribute(Constants.USER_FPLABEL_KEY, oAuthToken.getUser().getFpLabel());
			httpSession.setAttribute(Constants.EXPIRES_AT_KEY, AppUtils.delayFromNowToMilliseconds(oAuthToken.getExpiresIn()));

			mostLogger.debugInfo(String.format("Renouvellement de l'access token pour la session %s et la cl� %s --> OK", httpSession.getId(), state));	
		} else {
			throw new IllegalArgumentException(String.format("Le refresh token pour la session %s et le state %s n'existe pas", httpSession.getId(), state));
		}
		
	}

	/**
	 * Retourne le user connect� avec la session
	 * @param httpSession Spring Session
	 * @return Le user connect�
	 * @throws ApiException
	 * @see {@link User}
	 */
	public User getUserConnected(HttpSession httpSession) throws ApiException {
		mostLogger.debugInfo(String.format("R�cup�ration des informations sur l'utilisateur connect� � la session %s", httpSession.getId()));

		if (Objects.nonNull(httpSession.getAttribute(Constants.USER_ID_KEY))) {
			User user = new User();
			user.setId((String) httpSession.getAttribute(Constants.USER_ID_KEY));
			user.setFpLabel((String) httpSession.getAttribute(Constants.USER_FPLABEL_KEY));
			mostLogger.debugInfo(String.format("R�cup�ration des informations sur l'utilisateur connect� � la session %s --> OK", httpSession.getId()));
			return user;
		} else {
			throw new ApiException(HttpStatus.SC_NOT_FOUND, String.format("L'utilisateur pour le session %s n'existe pas.", httpSession.getId()));
		}
	}

	/**
	 * Permet d'extraire les informations de l'utilisateur � partir de Id token du jeton
	 * @param tokenId Le token Id du jeton OAuth
	 * @return Les informations sur l'utilisateur
	 * @see {@link User}
	 */
	private User getUserFromTokenId(String tokenId) {
		mostLogger.debugInfo("R�cup�ration des informations sur l'utilisateur depuis le token id du jeton");
		User user = new User();

		if (Objects.nonNull(tokenId)) {
			String tokenIdSplit = tokenId.split("\\.")[1];
			String tokenIdDecoded = new String(Base64.getDecoder().decode(tokenIdSplit.getBytes()));

			JsonElement json = JsonParser.parseString(tokenIdDecoded);
			String sub = json.getAsJsonObject().get(Constants.SUB_KEY).getAsString();

			user.setId(sub);
			mostLogger.debugInfo("R�cup�ration des informations sur l'utilisateur depuis le token id du jeton --> OK");
			
			//recherche du poste fonctionnel, si absent retourne "UNKNOWN"
			JsonElement functionalPost  = json.getAsJsonObject().get(Constants.FP_KEY);
			
			if (Objects.nonNull(functionalPost)) { 
				String labelFp = functionalPost.getAsJsonObject().get(Constants.LABEL_FP_KEY).getAsString();
				user.setFpLabel(labelFp);
				mostLogger.debugInfo("R�cup�ration du poste fonctionnel de l'utilisateur depuis le token id du jeton --> OK");
			}else{
				String labelFp = "UNKNOWN";
				user.setFpLabel(labelFp);
				mostLogger.debugInfo("R�cup�ration du poste fonctionnel de l'utilisateur depuis le token id du jeton --> KO");	
			}

		} else {
			mostLogger.debugInfo("R�cup�ration des informations sur l'utilisateur depuis le token id du jeton impossible. Token Id null");
		}
		
		return user;
	}
}
