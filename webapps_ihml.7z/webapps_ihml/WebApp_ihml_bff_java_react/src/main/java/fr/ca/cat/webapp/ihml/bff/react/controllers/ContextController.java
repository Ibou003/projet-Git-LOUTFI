package fr.ca.cat.webapp.ihml.bff.react.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.webapp.ihml.bff.react.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.react.models.context.ApplicationContext;
import fr.ca.cat.webapp.ihml.bff.react.models.context.Ctx9WriteContext;
import fr.ca.cat.webapp.ihml.bff.react.services.api.ContextService;

/**
 * Controller pour la ressource g�rant les appels � l'API Places
 * 
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/context")
public class ContextController {

	@Autowired
	private ContextService contextService;

	/**
	 * Ressource pour r�cup�rer le context de l'application
	 * 
	 * @param ctxId
	 *            Id du contexte � r�cup�rer
	 * 
	 * @return {@link ApplicationContext}
	 * @throws IOException
	 * @throws ApiException
	 */
	@GetMapping("/{ctxId}")
	public ResponseEntity<ApplicationContext> getContext(@PathVariable("ctxId") String ctxId) throws IOException, ApiException {
		ApplicationContext applicationContext = this.contextService.getContext(ctxId);
		return ResponseEntity.ok().body(applicationContext);
	}

	/**
	 * Ressource pour r�cup�rer le context de l'application
	 * 
	 * @param ctxId
	 *            Id du contexte � r�cup�rer
	 * 
	 * @return {@link ApplicationContext}
	 * @throws IOException
	 * @throws ApiException
	 */
	@PostMapping()
	public ResponseEntity<Ctx9WriteContext> setContext(@RequestBody ApplicationContext applicationContext) throws IOException, ApiException {
		Ctx9WriteContext ctx9WriteContext = this.contextService.setContext(applicationContext);
		return ResponseEntity.ok().body(ctx9WriteContext);
	}
}
