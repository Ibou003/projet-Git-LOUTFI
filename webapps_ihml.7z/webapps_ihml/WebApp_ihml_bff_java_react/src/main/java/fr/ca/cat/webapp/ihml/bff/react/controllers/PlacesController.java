package fr.ca.cat.webapp.ihml.bff.react.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.webapp.ihml.bff.react.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.react.models.places.CR;
import fr.ca.cat.webapp.ihml.bff.react.models.places.DistributionEntity;
import fr.ca.cat.webapp.ihml.bff.react.models.places.Entity;
import fr.ca.cat.webapp.ihml.bff.react.services.api.PlacesService;

/**
 * Controller pour la ressource g�rant les appels � l'API Places
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/places")
public class PlacesController {

	@Autowired
	private PlacesService placesService;
	
	/**
	 * Ressource pour r�cup�rer la liste des agences
	 * @return Liste de {@link CR}
	 * @throws IOException
	 * @throws ApiException
	 */
	 @GetMapping("/regional_banks")
	 public ResponseEntity<CR[]> getPlaces() throws IOException, ApiException {
		 CR[] crs = this.placesService.getCRList();
		 return ResponseEntity.ok().body(crs);
	 }
	 
	 /**
	  * Ressource pour r�cup�rer la liste des villes d'une CR
	  * @param crId Id de la CR
	  * @return Liste d' {@link Entity}
	  * @throws IOException
	  * @throws ApiException
	  */
	 @GetMapping("/regional_banks/{crId}/cities_with_distribution_entities")
	 public ResponseEntity<Entity[]> getCREntities(@PathVariable("crId") String crId) throws IOException, ApiException {
		 Entity[] entities = this.placesService.getCREntities(crId);
		 return ResponseEntity.ok().body(entities);
	 }
	 
	 /**
	  * Ressource pour r�cup�rer les agences d'une ville d'une CR
	  * @param crId Id de la CR
	  * @param zipCode Zipcode de l'Entity (ville)
	  * @return Liste d' {@link DistributionEntity}
	  * @throws IOException
	  * @throws ApiException
	  */
	 @GetMapping("/distribution_entities/search_by_city/{crId}/{zipCode}")
	 public ResponseEntity<DistributionEntity[]> getCRAgencesList(@PathVariable("crId") String crId, @PathVariable ("zipCode") String zipCode) throws IOException, ApiException {
		 DistributionEntity[] distributionEntities = this.placesService.getCRAgencesList(crId, zipCode);
		 return ResponseEntity.ok().body(distributionEntities);
	 }
}
