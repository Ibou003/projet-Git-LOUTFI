package fr.ca.cat.webapp.ihml.bff.react.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Object d�finissant le type de march� d'une agence
 * @author ET02720
 *
 */
public class Market {
	
	/**
	 * Type de march� g�n�ral public
	 * @see Market#isGeneralPublic()
	 * @see Market#setGeneralPublic(boolean)
	 */
	private boolean generalPublic;
	
	/**
	 * Type de march� banque priv�e
	 * @see Market#isPrivateBanking()
	 * @see Market#setPrivateBanking(boolean)
	 */
	private boolean privateBanking;
	
	/**
	 * Type de march� pro
	 * @see Market#isPro()
	 * @see Market#setPro(boolean)
	 */
	private boolean pro;
	
	/**
	 * Type de march� agriculteur
	 * @see Market#isFarmer()
	 * @see Market#setFarmer(boolean)
	 */
	private boolean farmer;
	
	/**
	 * Type de march� association
	 * @see Market#isAssociation()
	 * @see Market#setAssociation(boolean)
	 */
	private boolean association;
	
	/**
	 * Type de march� entreprise
	 * @see Market#isEnterprise()
	 * @see Market#setEnterprise(boolean)
	 */
	private boolean enterprise;
	
	/**
	 * Type de march� collectivit� publique
	 * @see Market#isPublicCollectivity()
	 * @see Market#setPublicCollectivity(boolean)
	 */
	private boolean publicCollectivity;
	
	/**
	 * Indique si l'agence g�re les clients publiques
	 * @return True si l'agence g�re les clients publiques
	 */
	@JsonProperty(value = "general_public")
	public boolean isGeneralPublic() {
		return generalPublic;
	}
	
	/**
	 * Sp�cifie si l'agence g�re les clients publiques
	 * @param generalPublic True si l'agence g�re les clients publiques
	 */
	@JsonProperty(value = "general_public")
	public void setGeneralPublic(boolean generalPublic) {
		this.generalPublic = generalPublic;
	}
	
	/**
	 * Indique si l'agence est une banque priv�e
	 * @return True si l'agence est une banque priv�e
	 */
	@JsonProperty(value = "private_banking")
	public boolean isPrivateBanking() {
		return privateBanking;
	}
	
	/**
	 * Sp�cifie si l'agence est une banque priv�e
	 * @param generalPublic True si l'agence est une banque priv�e
	 */
	@JsonProperty(value = "private_banking")
	public void setPrivateBanking(boolean privateBanking) {
		this.privateBanking = privateBanking;
	}
	
	/**
	 * Indique si l'agence g�re les pros
	 * @return True si l'agence g�re les pros
	 */
	@JsonProperty(value = "pro")
	public boolean isPro() {
		return pro;
	}
	
	/**
	 * Sp�cifie si l'agence g�re les pros
	 * @param generalPublic True si l'agence g�re les pros
	 */
	@JsonProperty(value = "pro")
	public void setPro(boolean pro) {
		this.pro = pro;
	}
	
	/**
	 * Indique si l'agence g�re les agriculteurs
	 * @return True si l'agence g�re les agriculteurs
	 */
	@JsonProperty(value = "farmer")
	public boolean isFarmer() {
		return farmer;
	}
	
	/**
	 * Sp�cifie si l'agence g�re les agriculteurs
	 * @param generalPublic True si l'agence g�re les agriculteurs
	 */
	@JsonProperty(value = "farmer")
	public void setFarmer(boolean farmer) {
		this.farmer = farmer;
	}
	
	/**
	 * Indique si l'agence g�re les associations
	 * @return True si l'agence g�re les associations
	 */
	@JsonProperty(value = "association")
	public boolean isAssociation() {
		return association;
	}
	
	/**
	 * Sp�cifie si l'agence g�re les associations
	 * @param generalPublic True si l'agence g�re les associations
	 */
	@JsonProperty(value = "association")
	public void setAssociation(boolean association) {
		this.association = association;
	}
	
	/**
	 * Indique si l'agence g�re les entreprises
	 * @return True si l'agence g�re les entreprises
	 */
	@JsonProperty(value = "enterprise")
	public boolean isEnterprise() {
		return enterprise;
	}
	
	/**
	 * Sp�cifie si l'agence g�re les entreprises
	 * @param generalPublic True si l'agence g�re les entreprises
	 */
	@JsonProperty(value = "enterprise")
	public void setEnterprise(boolean enterprise) {
		this.enterprise = enterprise;
	}
	
	/**
	 * Indique si l'agence g�re les collectivit�s publiques
	 * @return True si l'agence g�re les collectivit�s publiques
	 */
	@JsonProperty(value = "public_collectivity")
	public boolean isPublicCollectivity() {
		return publicCollectivity;
	}
	
	/**
	 * Sp�cifie si l'agence g�re les collectivit�s publiques
	 * @param generalPublic True si l'agence g�re les collectivit�s publiques
	 */
	@JsonProperty(value = "public_collectivity")
	public void setPublicCollectivity(boolean publicCollectivity) {
		this.publicCollectivity = publicCollectivity;
	}
}
