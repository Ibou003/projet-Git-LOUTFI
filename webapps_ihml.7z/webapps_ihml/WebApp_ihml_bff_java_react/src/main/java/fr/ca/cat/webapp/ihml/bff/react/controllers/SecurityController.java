package fr.ca.cat.webapp.ihml.bff.react.controllers;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.webapp.ihml.bff.react.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.react.models.places.User;
import fr.ca.cat.webapp.ihml.bff.react.services.security.SecurityService;
import fr.ca.cat.webapp.ihml.bff.react.utils.AppUtils;
import fr.ca.cat.webapp.ihml.bff.react.utils.Constants;

/**
 * Controller pour la ressource g�rant la s�curit� de l'application
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/security")
public class SecurityController {

	@Value("${security.session.cookie.domain}")
	private String domain;
	
	@Value("${security.session.cookie.path}")
	private String path;
	
	@Value("${security.session.cookie.secure}")
	private boolean cookieSecure;
	
	@Autowired
	private SecurityService securityService;
	
	/**
	 * Ressource d'identification � l'application
	 * 
	 * @param code Authorization code fourni par la mire X Connect
	 * @param redirectUrl Url de redirection de l'application founie � X Connect
	 * @param state Id de "session" fourni lors de la connexion � la mire X Connect
	 * @param httpSession Spring Session
	 * @return 
	 * @throws ApiException
	 * @throws IOException
	 */
	@GetMapping("/login")
	public ResponseEntity<Void> login(@RequestHeader (value = HttpHeaders.AUTHORIZATION) String code,
			@RequestHeader (value = Constants.REDIRECT_URL_HEADER) String redirectUrl,
			@RequestHeader (value = Constants.STATE_HEADER) String state, HttpSession httpSession) throws ApiException, IOException {
		
		this.securityService.login(code, redirectUrl, state, httpSession);
		
		// Cr�ation du cookie STATE permettant de r�cup�rer le refreh token dans le cache REDIS
		HttpHeaders responseHeaders = new HttpHeaders();
		String cookieString = AppUtils.buildCookie(Constants.STATE_COOKIE, state, domain, path, cookieSecure, null, false);
		responseHeaders.set("Set-Cookie", cookieString);
	    return ResponseEntity.ok().headers(responseHeaders).build();
	}
	
	/**
	 * Ressource de d�connexion
	 * @param state d de "session" fourni lors de la connexion � la mire X Connect
	 * @param httpSession Spring Session
	 * @return
	 * @throws ApiException
	 * @throws IOException
	 */
	@GetMapping("/logout")
	public ResponseEntity<Void> logout(@CookieValue(Constants.STATE_COOKIE) String state, HttpSession httpSession) throws ApiException, IOException {
		this.securityService.logout(httpSession, state);
		
		// R�vocation du cookie STATE
		HttpHeaders responseHeaders = new HttpHeaders();
		String cookieString = AppUtils.buildCookie(Constants.STATE_COOKIE, "deleted", domain, path, cookieSecure, null, true);
		responseHeaders.set("Set-Cookie", cookieString);

	    return ResponseEntity.ok().headers(responseHeaders).build();
	}
	
	/**
	 * Ressource pour r�cup�rer les informations sur le user de la session
	 * 
	 * @param httpSession Spring Session
	 * @return {@link User}
	 * @throws ApiException
	 */
	@GetMapping("/user")
	public ResponseEntity<User> getUserConnected(HttpSession httpSession) throws ApiException {
		User user = this.securityService.getUserConnected(httpSession);
		return ResponseEntity.ok().body(user);
	}
	
	
}
