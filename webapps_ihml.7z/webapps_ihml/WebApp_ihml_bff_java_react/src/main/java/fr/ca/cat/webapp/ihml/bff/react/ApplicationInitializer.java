package fr.ca.cat.webapp.ihml.bff.react;

import javax.servlet.Filter;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import fr.ca.cat.webapp.ihml.bff.react.filters.ApiAuthenticationFilter;
import fr.ca.cat.webapp.ihml.bff.react.filters.CorsFilter;
import fr.ca.cat.webapp.ihml.bff.react.filters.ErrorHandlerFilter;
import fr.ca.cat.webapp.ihml.bff.react.session.SessionConfig;

/**
 * Classe d'initialisation de l'application
 * @author ET02720
 *
 */
public class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {
 
    @Override
    protected Class<?>[] getRootConfigClasses() {
        return new Class[] { ApplicationConfiguration.class, SessionConfig.class };
    }
  
    @Override
    protected Class<?>[] getServletConfigClasses() {
        return new Class[]{};
    }
  
    @Override
    protected String[] getServletMappings() {
    	
    	// Chemin du contexte des ressources. {serveletContext}/api/**
        return new String[] { "/api/*" };
    }
    
	@Override
	protected Filter[] getServletFilters() {
		// Ajout des diff�rents filtre � la chaine de filtrage. L'ordre est important
		return new Filter[]{new CorsFilter(), new ApiAuthenticationFilter(), new ErrorHandlerFilter()};
	}
 
}