package fr.ca.cat.webapp.ihml.bff.react.models.security;

import com.fasterxml.jackson.annotation.JsonProperty;

import fr.ca.cat.webapp.ihml.bff.react.models.places.User;

/**
 * Objet d�finissant un jeton OAuthToken renvoy� par l'API AUC9
 * @author ET02720
 *
 */
public class OAuthToken {
	
	/**
	 * Temps de validit� du jeton en secondes
	 * @see OAuthToken#getExpiresIn()
	 * @see OAuthToken#setExpiresIn(int)
	 */
	private int expiresIn;
	
	/**
	 * Access Token pour s'authenfier lors des appels d'API
	 * @see OAuthToken#getAccessToken()
	 * @see OAuthToken#setAccessToken(String)
	 */
	private String accessToken;
	
	/**
	 * Type de jeton
	 * @see OAuthToken#getType()
	 * @see OAuthToken#setType(String)
	 */
	private String type;
	
	/**
	 * Token Id encod� en Base64 et contenant des informations sur l'utilisateur du jeton
	 * @see OAuthToken#getIdToken()
	 * @see OAuthToken#setIdToken(String)
	 */
	private String idToken;
	
	/**
	 * Refresh token permettant de renouveller le jeton apr�s son expiration
	 * @see OAuthToken#getRefreshToken()
	 * @see OAuthToken#setRefreshToken(String)
	 */
	private String refreshToken;
	
	/**
	 * Information sur l'utilisateur du jeton (extraite du token id)
	 * @see OAuthToken#getUser()
	 * @see OAuthToken#setUser(User)
	 * @see {@link User}
	 */
	private User user;
	
	/**
	 * Retourne le temps de validit� du jeton (en secondes)
	 * @return Le temps de validit� du jeton
	 */
	@JsonProperty("expires_in")
	public int getExpiresIn() {
		return expiresIn;
	}
	
	/**
	 * Met � jour le temps de validit� de token
	 * @param expirationIn Le nouveau temps de validit� du token (en secondes)
	 */
	@JsonProperty("expires_in")
	public void setExpiresIn(int expirationIn) {
		this.expiresIn = expirationIn;
	}
	
	/**
	 * Retourne l'access token du jeton
	 * @return L'access token du jeton
	 */
	@JsonProperty("access_token")
	public String getAccessToken() {
		return accessToken;
	}
	
	/**
	 * Met � jour l'access token du jeton
	 * @param accessToken Le nouvel access token du jeton
	 */
	@JsonProperty("access_token")
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	/**
	 * Retourne le type du jeton
	 * @return Le type du jeton
	 */
	@JsonProperty("type")
	public String getType() {
		return type;
	}
	
	/**
	 * Met � jour le type du jeton
	 * @param type Le nouveau type du jeton
	 */
	@JsonProperty("token_type")
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Retourne l'Id token du jeton
	 * <br>
	 * Contient des informations sur l'utilisateur du jeton
	 * @return L'Id token du jeton
	 */
	@JsonProperty("id_token")
	public String getIdToken() {
		return idToken;
	}
	
	/**
	 * Met � jour l'Id token du jeton
	 * @param idToken Le nouvel Id token du jeton
	 */
	@JsonProperty("id_token")
	public void setIdToken(String idToken) {
		this.idToken = idToken;
	}
	
	/**
	 * Retourne le refresh token du jeton
	 * <br>
	 * Permet le renouvellement du jeton apr�s son expiration
	 * @return Le refresh token du jeton
	 */
	@JsonProperty("refresh_token")
	public String getRefreshToken() {
		return refreshToken;
	}
	
	/**
	 * Met � jour le refresk token du jeton
	 * @param refreshToken Le nouvel refresh token
	 */
	@JsonProperty("refresh_token")
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	
	/**
	 * Retourne des informations sur l'utilisateur du jeton
	 * @return Les informations sur l'utilisateur du jeton
	 * @see {@link User}
	 */
	public User getUser() {
		return user;
	}
	
	/**
	 * Met � jour les informations sur l'utilisateur du jeton
	 * @param user Le nouvel utilisateur du jeton
	 * @see {@link User}
	 */
	public void setUser(User user) {
		this.user = user;
	}
	
}
