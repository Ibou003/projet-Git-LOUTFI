package fr.ca.cat.webapp.ihml.bff.react.utils;

/**
 * Classe permettant de centraliser les constantes du projet
 * 
 * @author ET02720
 *
 */
public class Constants {

	// AUC9 URL
	public static final String OPENID_TOKEN_URL = "%s/openid/token";
	public static final String OPENID_REVOKE_URL = "%s/openid/revoke";

	// Places URL
	public static final String REGINONAL_BANKS_URL = "%s/regional_banks";
	public static final String CITIES_WIHT_DISTRIBUTION_ENTITIES = "%s/regional_banks/%s/cities_with_distribution_entities?type=1";
	public static final String DISTRIBUTION_ENTITIES_SEARCH_BY_CITY = "%s/distribution_entities/search_by_city?regional_bank_id=%s&zip_code=%s";

	// Context Url
	public static final String GET_CONTEXT_URL = "%s/contexts?context_id=%s";
	public static final String POST_CONTEXT_URL = "%s/contexts";

	// Redis Cache
	public static final String TOKEN_CACHE = "TOKEN";

	// Redis Keys
	public static final String ACCESS_TOKEN_KEY = "access_token";
	public static final String USER_ID_KEY = "user_id";
	public static final String USER_FPLABEL_KEY = "fp_label";
	public static final String CORRELATION_ID_KEY = "correlation_id";
	public static final String EXPIRES_AT_KEY = "expires_at";
	public static final String NAMESPACE_KEY = "ihml:demo:react";
	public static final String TOKEN_KEY = NAMESPACE_KEY + ":token:";

	// Request Headers
	public static final String STATE_HEADER = "state";
	public static final String CORRELATION_ID_HEADER = "correlationid";
	public static final String CATS_CONSOMMATEUR_HEADER = "cats_consommateur";
	public static final String CATS_CONSOMMATEUR_ORIGINE_HEADER = "cats_consommateurorigine";
	public static final String CATS_CANAL_HEADER = "cats_canal";
	public static final String REDIRECT_URL_HEADER = "redirectUrl";
	public static final String ACCESS_TOKEN_HEADER = "accesstoken";

	// Request Cookie
	public static final String STATE_COOKIE = "STATE";
	public static final String SESSION_ID_COOKIE = "SESSION_ID";

	// Request Params
	public static final String GRANT_TYPE_PARAM = "grant_type";
	public static final String SCOPE_PARAM = "scope";
	public static final String CODE_PARAM = "code";
	public static final String REDIRECT_URI_PARAM = "redirect_uri";
	public static final String TOKEN_PARAM = "token";
	public static final String REFRESH_TOKEN_PARAM = "refresh_token";
	public static final String USER_CONTEXT_PARAM = "user_context";
	public static final String CLIENT_ID_PARAM = "client_id";

	// Request Params Value
	public static final String AUTORIZATION_CODE_VALUE = "authorization_code";
	public static final String REFRESH_TOKEN_VALUE = "refresh_token";
	public static final String SCOPE_VALUE = "openid functional_posts";

	// Oauth Token
	public static final String SUB_KEY = "sub";
	public static final String FP_KEY = "functional_post";
	public static final String LABEL_FP_KEY = "label";

	// Request Response
	public static final String ACCESS_UNAUTHORIZED_RESPONSES = "Identifiants invalides";
}
