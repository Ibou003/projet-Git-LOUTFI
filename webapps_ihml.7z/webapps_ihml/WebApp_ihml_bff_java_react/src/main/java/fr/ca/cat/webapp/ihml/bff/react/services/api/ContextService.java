package fr.ca.cat.webapp.ihml.bff.react.services.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.react.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.react.models.context.ApplicationContext;
import fr.ca.cat.webapp.ihml.bff.react.models.context.Ctx9ReadContext;
import fr.ca.cat.webapp.ihml.bff.react.models.context.Ctx9WriteContext;
import fr.ca.cat.webapp.ihml.bff.react.utils.Constants;

/**
 * Service pour appeler les ressources de l'API CTX9
 * 
 * @author ET02720
 *
 */
public class ContextService extends ApiService {

	private MostLogger mostLogger = MostLogger.getLogger(ContextService.class);
	
	/**
	 * Injection de la propri�t� qui r�f�rence l'url de l'API CTX9
	 */
	@Value("${service.ctx9}")
	protected String ctx9Url;

	/**
	 * Retourne le contexte de l'application
	 * 
	 * @param ctxId
	 *            Id du contexte
	 * @return Le contexte de l'application
	 * @throws IOException
	 * @throws ApiException
	 * @see {@link ApplicationContext}
	 */
	public ApplicationContext getContext(String ctxId) throws IOException, ApiException {
		mostLogger.debugInfo(String.format("R�cup�ration du context: %s", ctxId));

		// Construction de la requ�te
		HttpGet getContextTequest = new HttpGet(String.format(Constants.GET_CONTEXT_URL, ctx9Url, ctxId));
		
		// Add security headers
		this.addSecurityRequestHeader(getContextTequest);

		// Set Headers
		getContextTequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

		// Execution de la requete
		Ctx9ReadContext ctx9Context = this.httpService.execute(getContextTequest, Ctx9ReadContext.class);

		// Mapping de la r�ponse de la requ�te
		mostLogger.debugInfo(String.format("R�cup�ration du context: %s --> OK", ctxId));
		return ctx9Context.toApplicationContext();
	}

	/**
	 * Retourne le contexte de l'application
	 * 
	 * @param ctxId
	 *            Id du contexte
	 * @return Le contexte de l'application
	 * @throws IOException
	 * @throws ApiException
	 * @see {@link ApplicationContext}
	 */
	public Ctx9WriteContext setContext(ApplicationContext applicationContext)
			throws IOException, ApiException {
		mostLogger.debugInfo("Sauvegarde du contexte");

		// Construction de la requ�te
		HttpPost postContextTequest = new HttpPost(String.format(Constants.POST_CONTEXT_URL, ctx9Url));
		
		
		// Add security headers
		this.addSecurityRequestHeader(postContextTequest);		
		
		// Set Headers
		postContextTequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);

		// Set Body
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair(Constants.USER_CONTEXT_PARAM, applicationContext.toJsonString()));

		if (Objects.nonNull(applicationContext.getClientId())) {
			params.add(new BasicNameValuePair(Constants.CLIENT_ID_PARAM, applicationContext.getClientId()));
		}
		postContextTequest.setEntity(new UrlEncodedFormEntity(params));

		// Execution de la requete
		Ctx9WriteContext writeContext = this.httpService.execute(postContextTequest, Ctx9WriteContext.class);

		// Mapping de la r�ponse de la requ�te
		mostLogger.debugInfo("Sauvegarde du contexte --> OK");
		return writeContext;
	}

}
