export interface TestSuite {
    name: string;
    description?: string;
    skip?: boolean;
    tests: Test[];
}

export interface Test {
    name: string;
    description?: string;
    skip?: boolean;
    context?: Context;
    cookies?: string;
    request: TestRequest;
    expected: ExpectedResult;
}

export interface Context {
    structureId?: string;
    eds?: string;
    operationalPost?: string;
}

export interface TestRequest {
    path: string;
    method: RequestMethod;
    body?: any;
    headers?: any;
}

export enum RequestMethod {
    GET = 'GET',
    POST = 'POST',
    PUT = 'PUT',
    DELETE = 'DELETE'
}

export interface ExpectedResult {
    httpStatus: number;
    body?: any;
}

export interface GotResult {
    httpStatus: number;
    body?: any;
    error?: any;
}

export interface TestResult {
    name: string;
    status: TestStatus;
    report?: TestReport;
}

export interface TestSuiteResult {
    name: string;
    status: TestStatus;
    report: TestSuiteReport;
}

export interface TestSuiteReport {
    testsTotal: number;
    testsPassed: number;
    testsFailed: number;
    testsSkipped: number;
    testsResult: TestResult[];
}

export interface TestReport {
    expected: ExpectedResult;
    got: GotResult;
}

export enum TestStatus {
    PASSED = 'PASSED',
    FAILED = 'FAILED',
    SKIPPED = 'SKIPPED'
}

