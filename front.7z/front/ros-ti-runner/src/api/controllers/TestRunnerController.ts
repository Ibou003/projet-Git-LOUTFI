import { Promise } from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Route, Tags, Post, Body} from 'tsoa';
import { TestRunnerService } from '../services/TestRunnerService';
import { TestSuite, TestSuiteResult, Test, TestResult } from '../models/Test';

@Route('run')
@Tags('run')
@provideSingleton(TestRunnerController)
export class TestRunnerController {

    @inject(TestRunnerService)
    private testRunnerService: TestRunnerService;

    @Post('testsuite')
    public runTestSuite(@Body() testSuite: TestSuite): Promise<TestSuiteResult> {
        return this.testRunnerService.runTestSuite(testSuite);
    }

    @Post('testsuites')
    public runTestSuites(@Body() testSuites: TestSuite[]): Promise<TestSuiteResult> {
        return this.testRunnerService.runTestSuites(testSuites);
    }

    @Post('test')
    public runTest(@Body() test: Test): Promise<TestResult> {
        return this.testRunnerService.runTest(test);
    }
}
