/* tslint:disable */
import { Controller, ValidateParam, FieldErrors, ValidateError, TsoaRoute } from 'tsoa';
import { iocContainer } from '../../ioc/ioc';

import { TestRunnerController } from './../controllers/TestRunnerController';

const models: TsoaRoute.Models = {
    "TestStatus": {
        "enums": ["PASSED", "FAILED", "SKIPPED"],
    },
    "ExpectedResult": {
        "properties": {
            "httpStatus": { "dataType": "double", "required": true },
            "body": { "dataType": "any" },
        },
    },
    "GotResult": {
        "properties": {
            "httpStatus": { "dataType": "double", "required": true },
            "body": { "dataType": "any" },
            "error": { "dataType": "any" },
        },
    },
    "TestReport": {
        "properties": {
            "expected": { "ref": "ExpectedResult", "required": true },
            "got": { "ref": "GotResult", "required": true },
        },
    },
    "TestResult": {
        "properties": {
            "name": { "dataType": "string", "required": true },
            "status": { "ref": "TestStatus", "required": true },
            "report": { "ref": "TestReport" },
        },
    },
    "TestSuiteReport": {
        "properties": {
            "testsTotal": { "dataType": "double", "required": true },
            "testsPassed": { "dataType": "double", "required": true },
            "testsFailed": { "dataType": "double", "required": true },
            "testsSkipped": { "dataType": "double", "required": true },
            "testsResult": { "dataType": "array", "array": { "ref": "TestResult" }, "required": true },
        },
    },
    "TestSuiteResult": {
        "properties": {
            "name": { "dataType": "string", "required": true },
            "status": { "ref": "TestStatus", "required": true },
            "report": { "ref": "TestSuiteReport", "required": true },
        },
    },
    "Context": {
        "properties": {
            "structureId": { "dataType": "string" },
            "eds": { "dataType": "string" },
            "operationalPost": { "dataType": "string" },
        },
    },
    "RequestMethod": {
        "enums": ["GET", "POST", "PUT", "DELETE"],
    },
    "TestRequest": {
        "properties": {
            "path": { "dataType": "string", "required": true },
            "method": { "ref": "RequestMethod", "required": true },
            "body": { "dataType": "any" },
            "headers": { "dataType": "any" },
        },
    },
    "Test": {
        "properties": {
            "name": { "dataType": "string", "required": true },
            "description": { "dataType": "string" },
            "skip": { "dataType": "boolean" },
            "context": { "ref": "Context", "required": true },
            "request": { "ref": "TestRequest", "required": true },
            "expected": { "ref": "ExpectedResult", "required": true },
        },
    },
    "TestSuite": {
        "properties": {
            "name": { "dataType": "string", "required": true },
            "description": { "dataType": "string" },
            "skip": { "dataType": "boolean" },
            "tests": { "dataType": "array", "array": { "ref": "Test" }, "required": true },
        },
    },
};

export function RegisterRoutes(app: any) {
    app.post('/ti-runner/run/testsuite',
        function(request: any, response: any, next: any) {
            const args = {
                testSuite: { "in": "body", "name": "testSuite", "required": true, "ref": "TestSuite" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<TestRunnerController>(TestRunnerController);

            const promise = controller.runTestSuite.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.post('/ti-runner/run/testsuites',
        function(request: any, response: any, next: any) {
            const args = {
                testSuites: { "in": "body", "name": "testSuites", "required": true, "dataType": "array", "array": { "ref": "TestSuite" } },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<TestRunnerController>(TestRunnerController);

            const promise = controller.runTestSuites.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });
    app.post('/ti-runner/run/test',
        function(request: any, response: any, next: any) {
            const args = {
                test: { "in": "body", "name": "test", "required": true, "ref": "Test" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<TestRunnerController>(TestRunnerController);

            const promise = controller.runTest.apply(controller, validatedArgs);
            promiseHandler(controller, promise, response, next);
        });

    function promiseHandler(controllerObj: any, promise: any, response: any, next: any) {
        return Promise.resolve(promise)
            .then((data: any) => {
                let statusCode;
                if (controllerObj instanceof Controller) {
                    const controller = controllerObj as Controller
                    const headers = controller.getHeaders();
                    Object.keys(headers).forEach((name: string) => {
                        response.set(name, headers[name]);
                    });

                    statusCode = controller.getStatus();
                }

                if (data) {
                    response.status(200).json(data);
                } else {
                    response.status(statusCode || 204).end();
                }
            }).catch(next);
    }

    function getValidatedArgs(args: any, request: any): any[] {
        const errorFields: FieldErrors = {};
        const values = Object.keys(args).map(function(key) {
            const name = args[key].name;
            switch (args[key].in) {
                case 'request':
                    return request;
                case 'query':
                    return ValidateParam(args[key], request.query[name], models, name, errorFields);
                case 'path':
                    return ValidateParam(args[key], request.params[name], models, name, errorFields);
                case 'header':
                    return ValidateParam(args[key], request.header(name), models, name, errorFields);
                case 'body':
                    return ValidateParam(args[key], request.body, models, name, errorFields);
                case 'body-prop':
                    return ValidateParam(args[key], request.body[name], models, name, errorFields);
            }
        });

        if (Object.keys(errorFields).length > 0) {
            throw new ValidateError(errorFields, '');
        }
        return values;
    }
}