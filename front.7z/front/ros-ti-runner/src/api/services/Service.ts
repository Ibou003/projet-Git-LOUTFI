import { provideSingleton } from '../../ioc/ioc';
import * as _ from 'lodash';
@provideSingleton('Service')
export class Service {
    public rp;

    constructor() {
        this.rp = require('request-promise');
    }

    getRequestOptions(url: string, method: string, body: any = {}, additionnalHeaders: any = null): any {
        let options = {
            headers: {
                'content-type': 'application/json',
            },
            json: true,
            method: method,
            uri: url,
            resolveWithFullResponse: true
        };

        if (url.startsWith('https')) {
            options['rejectUnauthorized'] = false;
        }

        if (!_.isNull(additionnalHeaders)) {
            options.headers = _.assign(options.headers, additionnalHeaders);
        }

        if (method === 'POST' && !_.isUndefined(body)) {
            options['body'] = body;
        }
        return options;
    }
}
