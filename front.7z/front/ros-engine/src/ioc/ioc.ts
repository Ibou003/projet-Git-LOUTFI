import { Container, inject, named } from 'inversify';
import { fluentProvide, buildProviderModule } from 'inversify-binding-decorators';

let iocContainer = new Container();

let provideSingleton = (identifier: any) => {
    return fluentProvide(identifier)
        .inSingletonScope()
        .done();
};

let provideFluent = (identifier: any) => {
    return fluentProvide(identifier)
        .done();
};

let provideFluentTaggedName = (identifier: any, targetName) => {
    return fluentProvide(identifier)
        .inSingletonScope()
        .whenTargetNamed(targetName)
        .done();
};

export { iocContainer, provideSingleton, provideFluent, provideFluentTaggedName, inject, buildProviderModule, named };

