export interface OAuthToken {
    expirationDate: number;
    access_token: string;
    type: string;
    id_token: string;
    refresh_token: string;
}
