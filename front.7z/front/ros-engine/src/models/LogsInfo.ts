export interface LogsInfo {
    usercontext: UserContext;
    inputRequest: InputRequest;
    outputRequest: OutputRequest;
    message?: string;
}

export interface UserContext {
    structureId?: string;
    operationalPost?: string;
    eds?: string;
    id_part?: string;
}

export interface InputRequest {
    host: string;
    method: string;
    path: string;
    headers: any;
    body: any;
}

export interface OutputRequest {
    url: string;
    service: string;
    rule: RuleType;
}

export enum RuleType {
    CR = 'CR',
    EDS = 'EDS',
    POSTOP = 'Poste Operationnel',
    ID_PART = 'ID Part',
    DEFAUT = 'Defaut'
}