export interface UserContext {
    structureId?: string;
    operationalPost?: string;
    eds?: string;
    id_part?: string;
}