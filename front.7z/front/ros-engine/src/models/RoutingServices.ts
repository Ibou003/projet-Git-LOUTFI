export interface Router {
    pagination: pagination;
    Branches: Branche [];
}

// tslint:disable-next-line:class-name
export interface pagination {
    count: number;
    has_next: boolean;
    next_set_start_index: string;
    previous_set_start_index: string;
    total: number;
}

export interface Branche {
    id: string;
    groupe: string;
    application: string;
    eds: string;
    poste: string;
    cr: string;
    branche: string;
}