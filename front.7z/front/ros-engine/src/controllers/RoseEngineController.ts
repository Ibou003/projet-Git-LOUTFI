import { AbstractController } from './AbstractController';
import { logger } from '../utils/Logger/Logger';
import { provideSingleton, inject, named } from '../ioc/ioc';
import { RepositoryService } from '../services/repository/RepositoryService';

@provideSingleton(RoseEngineController)
export class RoseEngineController extends AbstractController {

    @inject('RepositoryService')  @named(process.env.REPOSITORY_SERVICE)
    private repositoryService: RepositoryService;


    registerRoutes(app: any) {
        logger.info('RoseEngine - Enregistrement du controller de rose engine');

        /**
         * Get the status of server
         */

         app.get('/probes', (req, res, next) => {
            res.send('Liveness and Readiness');
            next();
        });

        app.get('/rose-engine/status', (req, res) => {
            res.send('Running');
        });

        app.get('/repository', (req, res, next) => {
            res.status(200).send(this.repositoryService.getRepository());
            next();
        });

    }
}