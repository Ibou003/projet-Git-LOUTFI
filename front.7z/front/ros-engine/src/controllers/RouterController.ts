/**
 * Controller for routing request
 */
import * as _ from 'lodash';
import * as httpProxy from 'http-proxy';
import { AbstractController } from './AbstractController';
import { logger } from '../utils/Logger/Logger';
import { LogsInfo, RuleType, UserContext } from '../models/LogsInfo';
import { provideFluent, inject, named } from '../ioc/ioc';
import { RouterService } from '../services/router/RouterService';
import { RepositoryService } from '../services/repository/RepositoryService';
import '../services/Services';

@provideFluent(RouterController)
export class RouterController extends AbstractController {

    private proxyServer: any;

    @inject('RouterService') @named(process.env.ROUTER_SERVICE)
    private routerService: RouterService;

    @inject('RepositoryService') @named(process.env.REPOSITORY_SERVICE)
    private repositoryService: RepositoryService;

    constructor() {
        super();
        this.proxyServer = httpProxy.createProxyServer({});
        this.proxyServer.on('error', this.onProxyError.bind(this));
    }

    registerRoutes(app: any) {
        logger.info('RouterController - Enregistrement du controller de routage');

        app.all('/:solution/*', (request, response) => {
            const userContext: UserContext = this.routerService.extractRoutingContext(request);
            return this.routeRequest(request, response, userContext);
        });
    }

    routeRequest(req: any, res, userContext: UserContext) {
        // Récupération des informations de la requête
        const host: string = req.hostname;
        const path: string = req.path;
        const method: string = req.method;
        const logsInfo: LogsInfo = {
            usercontext: userContext,
            inputRequest: {
                host: host,
                method: method,
                path: path,
                headers: req.headers,
                body: req.body
            },
            outputRequest: {
                rule: RuleType.DEFAUT,
                service: '',
                url: ''
            }
        };

        // Récupération des informations de la requête
        try {
            const serviceName = this.routerService.getServiceName(this.repositoryService, req.params.solution, userContext, logsInfo);
            const protocol = 'http';
            const requestDeploy = `${protocol}://${serviceName}`;
            // logger.info('Redirection vers l\'url => ' + requestDeploy + '/' + proxyReqParams);
            if (!_.isEmpty(serviceName)) {
                req.headers.host = serviceName;
                // Redirection de la requête
                logsInfo.message = 'Redirection de la requête OK';
                logsInfo.outputRequest.url = `${requestDeploy}${path}`;
                logger.info(JSON.stringify(logsInfo, null, 2));
                this.proxyServer.web(req, res, {
                    preserveHeaderKeyCase: true,
                    secure: false,
                    target: requestDeploy
                });
            } else {
                logsInfo.message = `Aucun service trouvé dans les règles de routage pour la solution ${req.params.solution} pour ce contexte utilisateur`;
                logger.warn(JSON.stringify(logsInfo, null, 2));
                res.status(404).send(`Aucun service trouvé dans les règles de routage pour la solution ${req.params.solution} pour ce contexte utilisateur`);
            }
        } catch (err) {
            // erreur 404 solution non existante
            logsInfo.message = err.message;
            logger.warn(JSON.stringify(logsInfo, null, 2));
            res.status(404).send(err.message);
        }
    }

    private onProxyError(err, req, res) {
        res.writeHead(500, {
            'Content-Type': 'text/plain'
        });
        logger.log('error', 'Une erreur est intervenue lors du routage de la requête => ' + err);
        res.end('Une erreur est intervenue lors du routage de la requête => ' + err);
    }
}