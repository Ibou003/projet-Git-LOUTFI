import { RouterController } from './RouterController';
import { PrometheusController} from './PrometheusController';
import { RoseEngineController } from './RoseEngineController';
import { ErrorController } from './ErrorController';
import { AbstractController } from './AbstractController';
import { provideSingleton, inject} from '../ioc/ioc';
@provideSingleton(MainController)
export class MainController extends AbstractController {

    @inject(RouterController)
    private routerController: RouterController;

    @inject(PrometheusController)
    private prometheusController: PrometheusController;

    @inject(RoseEngineController)
    private roseEngineController: RoseEngineController;

    @inject(ErrorController)
    private errorController: ErrorController;

    registerRoutes(app: any) {
        this.roseEngineController.registerRoutes(app);
        this.routerController.registerRoutes(app);
        this.prometheusController.registerRoutes(app);
        this.errorController.registerRoutes(app);
    }
}