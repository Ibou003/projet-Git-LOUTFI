
/**
 * Controller for error management
 *
 */
import { AbstractController } from './AbstractController';
import { logger } from '../utils/Logger/Logger';
import { provideSingleton } from '../ioc/ioc';

@provideSingleton(ErrorController)
export class ErrorController extends AbstractController {
    registerRoutes(app: any) {
    logger.info('ErrorController - Enregistrement du controller d\'erreur');

    app.use((err, req, res, next) => {
        res.statusCode = 500;
        logger.info('Ressource introuvable');
        // Do not expose your error in production
        res.end({ error: err.message });
        next();
      });
    }
}