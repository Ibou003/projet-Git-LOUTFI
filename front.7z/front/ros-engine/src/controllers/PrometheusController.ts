/**
 * Controller for getting metrics on ROS Engine
 *
 */
import { AbstractController } from './AbstractController';
import * as Prometheus from 'prom-client';
import { logger } from '../utils/Logger/Logger';
import { provideSingleton } from '../ioc/ioc';

@provideSingleton(PrometheusController)
export class PrometheusController extends AbstractController {

    private httpRequestDurationMicroseconds = new Prometheus.Histogram({
        name: 'http_request_duration_ms_ros_engine',
        help: 'Duration of HTTP requests in ms',
        labelNames: ['method', 'route', 'code'],
        buckets: [0.10, 5, 15, 50, 100, 200, 300, 400, 500]
    });

    registerRoutes(app: any) {
    logger.info('PrometheusController - Enregistrement du controller de metrics Prometheus');


    // Runs before each requests
    app.use((req, res, next) => {
      res.locals.startEpoch = Date.now();
      next();
    });

     /**
      * In order to have Prometheus get the data from this app a specific URL is registered
      */
    app.get('/metrics', (req, res) => {
          res.set('Content-Type', Prometheus.register.contentType);
          res.end(Prometheus.register.metrics());
    });

    app.use((req, res, next) => {
        res.end(JSON.stringify(req.body, null, 2));
        const responseTimeInMs = Date.now() - res.locals.startEpoch;
        this.httpRequestDurationMicroseconds
          .labels(req.method, req.route.path, res.statusCode)
          .observe(responseTimeInMs);
        next();
      });
    }
}
