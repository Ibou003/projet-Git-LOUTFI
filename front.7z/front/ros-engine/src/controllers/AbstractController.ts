import { provideFluent } from '../ioc/ioc';

@provideFluent(AbstractController)
export abstract class AbstractController {
    abstract registerRoutes(app: any);
}