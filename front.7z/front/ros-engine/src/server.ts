import 'reflect-metadata';
import * as express from 'express';
import * as cookieParser from 'cookie-parser';
import { MainController } from './controllers/MainControllers';
import * as  bodyParser from 'body-parser';
require('source-map-support').install();
import { logger } from './utils/Logger/Logger';
import * as fs from 'fs';
import * as https from 'https';
import * as http from 'http';
import * as Prometheus from 'prom-client';
import { inject, provideSingleton, iocContainer, buildProviderModule } from './ioc/ioc';
const app = express();

const metricsInterval = Prometheus.collectDefaultMetrics();
@provideSingleton(Server)
export default class Server {

    @inject(MainController)
    private mainController: MainController;

    public static bootstrap(): Server {
        const servers: Server = iocContainer.get<Server>(Server);
        servers.config();
        return servers;
    }

  /**
   * bootstrap the server and does not return anything
   */

   public config(): Server {
    const protocol = process.env.SERVER_PROTOCOL || 'http';
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 8080;
    const privateKey = fs.readFileSync('./resources/tokens/keystore.key', 'utf8');
    const certificate = fs.readFileSync('./resources/tokens/truststore.pem', 'utf8');
    const credentials = { key: privateKey, cert: certificate };

    app.disable('x-powered-by');
    app.use(require('morgan')('dev', {
        // Skip loggin of /probes request
        skip: function (req, res) { return req.path === '/probes'; }
      }));
    app.use(cookieParser());

    // Controllers registration
    // A faire avant l'enreigstrement des body parser
    this.mainController.registerRoutes(app);

    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(bodyParser.raw({type: 'application/*'}));
    app.use(bodyParser.text({type: 'text/*'}));
    app.use(bodyParser.json());

    let serv;
    if (protocol === 'http') {
        serv = http.createServer(app);
    } else {
        serv = https.createServer(credentials, app);
    }

    // tslint:disable-next-line:no-shadowed-variable
    serv.listen(port, () => {
        logger.info(`Server ${protocol.toLocaleUpperCase()} - ROS Engine démarré sur le port ${port}`);
    });

    // Graceful shutdown
    process.on('SIGTERM', () => {
      clearInterval(metricsInterval);

      serv.close((err) => {
        if (err) {
          logger.info('error', err);
          process.exit(1);
        }

        process.exit(0);
      });
    });
    process.on('SIGINT', () => {
      logger.error('Server - Arrêt du serveur.');
      process.exit(0);
    });
    return this;
  }
}
iocContainer.load(buildProviderModule());
let server = Server.bootstrap();
export { server };
