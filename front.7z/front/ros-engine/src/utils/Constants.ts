const constants = {
    HTTP: {
        RESPONSE: {
            STATUS: {
                BAD_REQUEST: {
                    CODE: 400,
                    MESSAGE: 'Bad request, front issue'
                },
                INTERNAL_ERROR: {
                    CODE: 500,
                    MESSAGE: 'Internal server error'
                },
                NOT_ALLOWED: {
                    CODE: 403,
                    MESSAGE: 'You\'re a not allowed to access this resource'
                },
                NOT_FOUND: {
                    CODE: 404,
                    MESSAGE: 'Resource not found'
                },
                UNAUTHORIZED: {
                    CODE: 401,
                    MESSAGE: 'Invalid credentials or session token'
                },
                SESSION_EXPIRED: {
                    CODE: 401,
                    MESSAGE: 'Session expired'
                }
            }
        }
    },
    RULES: {
        ID: 'id',
        SERVICE: 'serviceName',
        LABEL: 'label',
        VPUC_K8S: 'VPUC_K8S'
    },
    GDPI: {
        ID_CR: 'cr',
        ID_EDS: 'eds',
        ID_POSTE: 'poste',
        APPLICATION: 'application',
        DEFAULT: 'branche'
    }
};

export default constants;
