import * as fs from 'fs';
import * as _ from 'lodash';
import * as moment from 'moment';
import * as glob from 'glob';
import { logger } from '../../utils/Logger/Logger';
import { Solution } from '../../models/Solutions';
import * as schedule from 'node-schedule';
import { provideFluentTaggedName } from '../../ioc/ioc';
import { RepositoryService } from './RepositoryService';

@provideFluentTaggedName('RepositoryService', 'Folder')
export class FolderRepositoryService implements RepositoryService  {

    private solutions: Solution[] = [];
    private solutionsTemp: Solution[] = [];
    private lastUpdateTime = null;
    private folderPath = null;

    constructor() {
        logger.info(`FolderRepositoryService - Initialisation de la table routage`);
        this.folderPath = process.env.SOLUTIONS_FOLDER || './solutions';
        this.initRoutingTable();
        this.schedule();
    }

    public getRepository(): Solution[] {
        return this.solutions;
    }

    private initRoutingTable() {
        // Lecture fichier semaphore
        const modificationTime = this.readSemaphore();
        logger.info(`FolderRepositoryService - Date de semaphore: ${moment(modificationTime).format('DD/MM/YYYY - HH:mm:ss')}`);
        logger.info(`FolderRepositoryService - Initialisation de la table de routage`);
        this.computeSolutions();
        if (_.isNull(modificationTime)) {
            this.lastUpdateTime = moment().startOf('year');
        } else {
            this.lastUpdateTime = modificationTime;
        }
    }

    private schedule() {
        let cron = '*/120 * * * * *';

        if (!_.isEmpty(process.env.CRON)) {
            cron = process.env.CRON;
        }
        schedule.scheduleJob(cron, () => {
            const modificationTime = this.readSemaphore();
            if (!_.isNull(modificationTime) && !this.lastUpdateTime.isSame(modificationTime)) {
                logger.info(`FolderRepositoryService - Nouvelle date de semaphore détectée : ${moment(modificationTime).format('DD/MM/YYYY - HH:mm:ss')}`);
                logger.info(`FolderRepositoryService - Recalcul de la table de routage`);
                this.computeSolutions();
                this.lastUpdateTime = modificationTime;
            }
        });
    }

    private computeSolutions() {
        try {
            const files = glob.sync(`${this.folderPath}/*.json`);
            this.solutionsTemp = [];
            files.forEach(file => {
                this.addSolution(file);
            });
            this.solutions = _.concat([], this.solutionsTemp);
            logger.info(`FolderRepositoryService - Nouvelle table de routage à jour`);
        } catch (err) {
            logger.warn(`FolderRepositoryService - Erreur lors du calcul de routage depuis le dossier des solutions: ${this.folderPath}.`);
            logger.warn(err);
        }
    }

    private addSolution(filePath: string) {
        let fileContent;
        if (fs.lstatSync(filePath).isFile()) {
            fileContent = fs.readFileSync(filePath);
        } else if (fs.lstatSync(filePath).isSymbolicLink()) {
            let realPath = fs.realpathSync(filePath);
            fileContent = fs.readFileSync(realPath);
        } else {
            logger.warn(`FolderRepositoryService - Erreur lecture fichier: ${filePath}. Ceci n'est pas un fichier`);
        }

        if (!_.isEmpty(fileContent)) {
            logger.info(`FolderRepositoryService - Chargement des règles de routage depuis le fichier: ${filePath}`);
            let solution: Solution = JSON.parse(fileContent.toString());
            solution.source = filePath;
            this.solutionsTemp = _.concat(this.solutionsTemp, solution);
        }
    }

    private readSemaphore(): any {
        // Lecture fichier semaphore
        const path = `${this.folderPath}/semaphore.txt`;

        try {
            fs.statSync(path);
            const semaphoreFileContent = fs.readFileSync(`${this.folderPath}/semaphore.txt`);
            const modificationTime = moment.unix(parseInt(semaphoreFileContent.toString(), 10));
            return modificationTime;
        } catch (err) {
            logger.warn(`FolderRepositoryService - Le fichier ${this.folderPath}/semaphore.txt n'existe pas.`);
            logger.warn('FolderRepositoryService - Aucune nouvelle règle ne sera chargé');
            return null;
        }
    }
}