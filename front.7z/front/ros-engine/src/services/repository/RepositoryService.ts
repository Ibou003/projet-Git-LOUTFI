export interface RepositoryService {
    getRepository(): any;
}
