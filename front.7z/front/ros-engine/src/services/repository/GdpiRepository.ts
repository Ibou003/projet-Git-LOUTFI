import * as _ from 'lodash';
import { logger } from '../../utils/Logger/Logger';
import * as schedule from 'node-schedule';
import { provideFluentTaggedName } from '../../ioc/ioc';
import { RepositoryService } from './RepositoryService';
import { Service } from '../router/Service';
import { Branche, Router } from '../../models/RoutingServices';
import { BaseError } from '../../utils/Error/BaseError';
import { OAuthToken } from '../../models/Security';
// import constants from '../../utils/Constants';
// import moment = require('moment');

@provideFluentTaggedName('RepositoryService', 'Gdpi')
export class GdpiRepositoryService extends Service implements RepositoryService {
    private solutions: Branche[] = [];
    // tslint:disable-next-line:variable-name
    private start_index: string;
    private istoken = false;
    private solutionstmp= [];
    expirationDate = null;
    constructor() {
        super();
        this.initRoutingTable();
        this.schedule();
    }

    public getRepository(): any[] {
        return this.solutions;
    }

    private initRoutingTable() {
        logger.info(`GdpiRepositoryService - Initialisation de la table de routage`);
        this.solutions = [];
        this.start_index = null;
        this.getListeSolution();
    }
    private getListeSolution(): Promise<Branche[]> {
        return this.allPromises(this.start_index).then((router: Router) => {
            // logger.info(`Calling GDPI Done. pagination: ${JSON.stringify(router.pagination)}`);
            let pagination = router.pagination;
            let branches = router.Branches;
            this.istoken = false;
            if (this.start_index === null) {
                this.start_index = pagination.previous_set_start_index;
            }
            this.start_index = pagination.next_set_start_index;
            if (branches) {
                branches.forEach((result) => { this.solutionstmp.push(result); });
            }
            if (!pagination.has_next && pagination.count === 0) {
                // logger.info(JSON.stringify(this.solutions, null, 2));
                this.istoken = true;
                this.solutions = this.solutionstmp;
                this.solutionstmp = [];
                return Promise.resolve(this.solutions);
            }
            return this.getListeSolution();
        }).catch(error => {
            const err = new BaseError(error.message);
            logger.warn(err);
            return Promise.resolve(this.solutions);
        });
    }
    private allPromises(start_index: string): Promise<any> {
        // Première itération de notre requete
        if (!start_index) {
            start_index = '';
        }
        return this.getAcessToken(this.expirationDate, this.istoken).then((token: OAuthToken) => {
            const url = `${process.env.URL_ENV}/gdpi/v1/branches_production/branches?groupe=${process.env.GROUPE}&count=${process.env.COUNT}&start_index=${start_index}`;
            const options = this.getRequestOptions(token, url, 'GET');
            this.expirationDate = token.expirationDate;
            logger.info(`Calling GDPI. Groupe: ${process.env.GROUPE} - Count: ${process.env.COUNT} - startIndex: ${start_index}`);
            return this.rp(options).then((router: Router) => {
                return Promise.resolve(router);
            }).catch(error => {
                this.expirationDate = null;
                throw error;
            });
        }).catch(error => {
            throw error;
        });
    }
    private schedule(): void {
        // Appel de l'api GDPI aprés 5 minutes
        let cron = '*/5 * * * *';
        if (!_.isEmpty(process.env.CRON)) {
            cron = process.env.CRON;
        }
        schedule.scheduleJob(cron, () => {
            logger.info(`Rechargement des données pour une durée ${cron} minutes`);
            this.solutions = [];
            this.start_index = null;
            this.getListeSolution();
        });
    }
}