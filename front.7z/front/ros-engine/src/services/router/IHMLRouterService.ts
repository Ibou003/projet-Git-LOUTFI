import * as _ from 'lodash';
import { RouterService } from './RouterService';
import { UserContext, RuleType } from '../../models/LogsInfo';
import { provideFluentTaggedName } from '../../ioc/ioc';
import { logger } from '../../utils/Logger/Logger';
import { RepositoryService } from '../repository/RepositoryService';
import { Solution } from '../../models/Solutions';
import constants from '../../utils/Constants';
import { NotFoundAPIError } from '../../utils/Error/NotFoundAPIError';

const USER_INFO_COOKIE = 'USER_INFO';

@provideFluentTaggedName('RouterService', 'IHML')
export class IHMLRouterService implements RouterService {


    constructor() {
        logger.info('IHMLRouterService - Chargement du service de routage: IHMLRouterService');
    }

    extractRoutingContext(request: any): UserContext {

        const userContext: UserContext = {};

        // Récupération du cookie USER_INFO
        if (_.has(request.cookies, USER_INFO_COOKIE)) {
            const idPart: string = JSON.parse(request.cookies[USER_INFO_COOKIE]).id;
            userContext.id_part = !_.isEmpty(idPart) ? idPart : '';
        }

        return userContext;
    }

    getServiceName(repository: RepositoryService, solution: any, userContext: any, logsInfo: any): string {
        const resourceAuthorization: Solution = _.find(repository.getRepository(), [constants.RULES.ID, solution]);

        if (!_.isEmpty(resourceAuthorization)) {
            const idPartServiceName = _.find(resourceAuthorization.rules.id_part, [constants.RULES.ID, userContext.id_part]);
            const defaultRuleServiceName = resourceAuthorization.rules.defaultServiceName;

            if (!_.isEmpty(idPartServiceName)) {
                logsInfo.outputRequest.rule = RuleType.ID_PART;
                logsInfo.outputRequest.service = idPartServiceName.serviceName;
                return `${idPartServiceName.serviceName}`;
                // la l’EDS renseigné dans le cookies VPUC_K8S de ma requête est présente dans la règle de routage « solution= notre solution »
            } else {
                logsInfo.outputRequest.rule = RuleType.DEFAUT;
                logsInfo.outputRequest.service = defaultRuleServiceName;
                return `${defaultRuleServiceName}`;
            }
        }  else {
            throw new NotFoundAPIError(`La solution '${solution}' n'existe pas dans les règles de routage`);
        }
    }
}