import { provideSingleton} from '../../ioc/ioc';
import * as _ from 'lodash';
import { BaseError } from '../../utils/Error/BaseError';
import constants from '../../utils/Constants';
import * as Promise from 'bluebird';
import { OAuthToken } from '../../models/Security';
import * as rp from 'request-promise';
import * as moment from 'moment';
@provideSingleton(Service)
export class Service {
    public rp;
    public credential = null;
    constructor() {
       this.rp = require('request-promise');
    }

    getAcessToken(expirationDate: number, istoken:boolean): Promise<OAuthToken> {
        // console.log("expirationDate => " + expirationDate, moment().isBefore(expirationDate));
        if ((istoken && expirationDate ) || !expirationDate) {
            this.credential =  this.getAUC9Token();
        }
        if (_.isEmpty(this.credential)) {
            const err = new BaseError(constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE);
            throw err;
        } else {
            return Promise.resolve(this.credential);
        }
    }
    getRequestOptions(token: OAuthToken, msUrl: string, method: string, body: any = {}, additionnalHeaders: any = null): any {
        let options = {
        headers: {
        Authorization: `Bearer ${token.access_token}`
        },
            json: true,
            method: method,
            uri: msUrl
        };

        if (!_.isNull(additionnalHeaders)) {
            options.headers = _.assign(options.headers, additionnalHeaders);
        }

        if (method === 'POST' && !_.isUndefined(body)) {
            options['body'] = body;
        }
            return options;
    }
    private getApplicationAuthorizationToken(): Promise<string> {
        return Buffer.from(`${process.env.CLIENT_ID}:${process.env.CLIENT_SECRET}`).toString('base64');
    }
    getAUC9Token(): Promise<OAuthToken> {
        console.log(`Calling AUC9 openid token`);
        const options = {
            form: {
                grant_type: 'client_credentials',
                scope: 'openid'
            },
            headers: {
                Authorization: `Basic ${this.getApplicationAuthorizationToken()}`,
                cats_consommateur: '{\"consommateur\":{\"nom\":\"CATS_API_ROSE\",\"version\":\"1.0\"}}',
                cats_consommateurorigine: '{\"consommateur\":{\"nom\":\"CATS_API_ROSE\",\"version\":\"1.0\"}}',
                cats_canal: '{\"canal\": {\"canalId\": \"12\", \"canalDistribution\": \"BP\", \"transport\": \"INTRA\"} }',
                'content-type': 'application/x-www-form-urlencoded'
            },
            json: true,
            method: 'POST',
            uri: `${process.env.URL_ENV}/authentification_collaborateur/v2/openid/token`};
        return rp(options).then((response: any) => {
            console.log(`Calling AUC9 openid token done`);
            const token: OAuthToken = {
                access_token: response['access_token'],
                expirationDate: moment().add(response['expires_in'], 'seconds').valueOf(),
                type: response['token_type'],
                id_token: response['id_token'],
                refresh_token: response['refresh_token'],
            };
            return token;
        });
        }
}
