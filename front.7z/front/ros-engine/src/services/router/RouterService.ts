import { UserContext } from '../../models/RoutingContext';
import { LogsInfo } from '../../models/LogsInfo';
import { RepositoryService } from '../repository/RepositoryService';

export interface RouterService {
    extractRoutingContext(request): UserContext;
    getServiceName(repositoryService: RepositoryService, solution: string, userContext: UserContext, logsInfo: LogsInfo): string;
}
