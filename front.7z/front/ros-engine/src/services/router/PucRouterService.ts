import * as _ from 'lodash';
import { RouterService } from './RouterService';
import { UserContext } from '../../models/RoutingContext';
import constants from '../../utils/Constants';
import { provideFluentTaggedName } from '../../ioc/ioc';
import { RuleType, LogsInfo } from '../../models/LogsInfo';
import { NotFoundAPIError } from '../../utils/Error/NotFoundAPIError';
import { logger } from '../../utils/Logger/Logger';
import { RepositoryService } from '../repository/RepositoryService';
import { Branche } from '../../models/RoutingServices';
@provideFluentTaggedName('RouterService', 'Puc')
export class PucRouterService implements RouterService {
    constructor() {
        logger.info('PucRouterService - Chargement du service de routage: PucRouterService');
    }

    extractRoutingContext(request): UserContext {
        const cookies: any = request.cookies || {};
        const cookiesFormatting = _.split(cookies [constants.RULES.VPUC_K8S], '-', 2);
        // Test if there is a header contextExecution
        const contextExecution: any = _.has(cookies, constants.RULES.VPUC_K8S) ? cookiesFormatting : null;
        let eds = '';
        let operationalPost = '';
        let structureId = '';
        if (!_.isNull(contextExecution)) {
            // No header found. Try to extract information from query params
            eds = '';
            structureId = contextExecution [0] || '';
            operationalPost = contextExecution [1] || '';
        }
        const usercontext: UserContext = {
            eds: eds.trim(),
            operationalPost: operationalPost.trim(),
            structureId: structureId.trim()
        };
        return usercontext;
    }

    getServiceName(repository: RepositoryService, solution: string, userContext: UserContext, logsInfo: LogsInfo): string {
        const resourcebySolution: Branche [] = _.filter(repository.getRepository(), [constants.GDPI.APPLICATION, solution]);
        logger.info(`Données de la solution : ${solution}`);
       logger.info(JSON.stringify(resourcebySolution, null, 2));
        if (!_.isEmpty(resourcebySolution)) {
            const crRuleServiceName = _.find(resourcebySolution, [constants.GDPI.ID_CR, userContext.structureId]);
            const posteOpRuleServiceName = _.find(resourcebySolution, [constants.GDPI.ID_POSTE, userContext.operationalPost]);
            const defaultRuleServiceName = _.find(resourcebySolution, def => { return !def.cr && !def.poste && def.branche && constants.GDPI.DEFAULT; } );
            // la CR renseigné dans le cookies VPUC_K8S de ma requête est présente dans les règles de routage « solution»= notre solution »
            if (!_.isEmpty(crRuleServiceName)) {
                logsInfo.outputRequest.rule = RuleType.CR;
                logsInfo.outputRequest.service = crRuleServiceName.serviceName;
                return `${crRuleServiceName.serviceName}`;
                // le poste opérationnel renseigné dans le cookies VPUC_K8S de ma requête est présente dans la règle de routage « solution= notre solution »
            } else if (!_.isEmpty(posteOpRuleServiceName)) {
                logsInfo.outputRequest.rule = RuleType.POSTOP;
                logsInfo.outputRequest.service = posteOpRuleServiceName.branche;
                return `${posteOpRuleServiceName.branche}`;
                // je route vers le service current
            } else if (!_.isEmpty(defaultRuleServiceName)) {
                 logger.info(JSON.stringify(resourcebySolution, null, 2));
                logsInfo.outputRequest.rule = RuleType.DEFAUT;
                logsInfo.outputRequest.service = defaultRuleServiceName.branche;
                return `${defaultRuleServiceName.branche}`;
            } else {
                throw new NotFoundAPIError(`La règle de routage par défaut de la solution '${solution}' n'existe pas`);
            }
        } else {
            throw new NotFoundAPIError(`La solution '${solution}' n'existe pas dans les règles de routage`);
        }
    }
}