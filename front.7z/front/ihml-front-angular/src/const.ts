const constants = {
    ROUTES: {
        PATHS: {
            AUTHORIZE: '/authorize'
        },
        PARAMS: {
            ID_CONTEXT: 'idCtx'
        },
        X_CONNECT : {
            AUTHORIZE: 'authorize',
            LOGOUT: 'logout'
        },
        REACT : {
            AGENCES: 'agences'
        }
    },
    MENUS: {
        HOME: 'home',
        AGENCES: 'agences',
        POSTE_MESSAGE: 'postMessage'
    },
    LABELS: {
        ACTIONS: {
            LOGIN: 'Connexion',
            LOGOUT: 'Déconnexion'
        }
    },
    WEEK_DAYS: [
        {
            day_of_week: '1',
            label: 'Lundi'
        },
        {
            day_of_week: '2',
            label: 'Mardi'
        },
        {
            day_of_week: '3',
            label: 'Mercredi'
        },
        {
            day_of_week: '4',
            label: 'Jeudi'
        },
        {
            day_of_week: '5',
            label: 'Vendredi'
        },
        {
            day_of_week: '6',
            label: 'Samedi'
        },
        {
            day_of_week: '7',
            label: 'Dimanche'
        }
    ],
    ACTIONS: {
        REDIRECT_FROM_XCONNECT: 'Retour de la mire de connexion',
        GET_CONTEXT: 'Récupération du contexte: ',
        SAVE_CONTEXT: 'Sauvegarde du contexte',
        REDIRECTION_TO_XCONNECT: 'Vous allez être redirigé vers la mire de déconnexion',
        GET_CR_LIST: 'Récupération de la liste des CR',
        GET_CR_ENTITIES_LIST: 'Récupération de la liste des villes de la CR:',
        GET_CR_CITY_DISTRIBUTION_ENTITIES: 'Récupération de la liste des agences de la CR et de la ville:',
        USER_LOGIN: 'Connexion de l\'utilisateur',
        USER_LOGOUT: 'Déconnexion de l\'utilisateur',
        GET_USER_INFORMATION: 'Récupération information sur l\'utilisateur connecté'
    },
    ERROR_MESSAGES: {
        BAD_XCONNECT_INFORMATION: 'Les informations de retour de connexion sont incorrectes',
        SERVER_NOT_REACHABLE: '404 - Le serveur ne peut être contacté.'
    }
};
export default constants;
