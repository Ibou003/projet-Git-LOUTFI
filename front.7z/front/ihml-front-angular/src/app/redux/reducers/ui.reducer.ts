import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import Constants from '../../../const';
import { setActiveMenu, setLastError, setTitle } from '../actions/ui.actions';
import { UIState } from '../state/ui.state';

/**
 * Clé du store lié a l'ui
 */
export const uiFeatureKey = 'ui';

/**
 * State initial pour le store UI
 */
export const initialState: UIState = {
    title: null,
    activeMenu: Constants.MENUS.HOME,
    lastError: null
};

/**
 * Réducer pour la gesion du store UI
 */
const _uiReducer = createReducer(
    initialState,
    on(setTitle, (state, { title }) => {
        return _.assign({}, state, { title });
    }),
    on(setActiveMenu, (state, { activeMenu }) => {
        return _.assign({}, state, { activeMenu });
    }),
    on(setLastError, (state, { lastError }) => {
        return _.assign({}, state, { lastError });
    })
);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function uiReducer(state, action) {
    return _uiReducer(state, action);
}
