import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { PlacesEffects } from './places.effects';
import { SessionEffects } from './session.effects';
import { ContextEffects } from './context.effects';

/**
 * Module parent pour la déclaration des Effect NgRx
 */
@NgModule({
    imports: [
        EffectsModule.forRoot([]),
        EffectsModule.forFeature([PlacesEffects, SessionEffects, ContextEffects])
    ],
})
export class AppEffectsModule { }
