import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import {contextReducer, contextFeatureKey} from '../reducers/context.reducer';

/**
 * Module pour la déclaration du store liés aux agences
 */
@NgModule({
  imports: [
    StoreModule.forFeature(contextFeatureKey, contextReducer)
  ],
})
export class ContextModule {}
