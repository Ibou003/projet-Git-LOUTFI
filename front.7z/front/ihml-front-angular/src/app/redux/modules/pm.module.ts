import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import {pmReducer, pmFeatureKey} from '../reducers/pm.reducer';

/**
 * Module pour la déclaration du store lié aux post message
 */
@NgModule({
  imports: [
    StoreModule.forFeature(pmFeatureKey, pmReducer)
  ],
})
export class PMModule {}
