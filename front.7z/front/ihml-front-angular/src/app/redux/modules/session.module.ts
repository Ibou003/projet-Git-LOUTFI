import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import {sessionReducer, sessionFeatureKey} from '../reducers/session.reducer';

/**
 * Module déclarant le store lié à la session
 */
@NgModule({
  imports: [
    StoreModule.forFeature(sessionFeatureKey, sessionReducer)
  ],
})
export class SessionModule {}
