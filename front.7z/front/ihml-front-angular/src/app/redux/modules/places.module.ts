import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import {placesReducer, placesFeatureKey} from '../reducers/places.reducer';

/**
 * Module pour la déclaration du store liés aux agences
 */
@NgModule({
  imports: [
    StoreModule.forFeature(placesFeatureKey, placesReducer)
  ],
})
export class PlacesModule {}
