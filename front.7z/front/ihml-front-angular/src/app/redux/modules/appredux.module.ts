import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { UIModule } from './ui.module';
import { SessionModule } from './session.module';
import { PlacesModule } from './places.module';
import { PMModule } from './pm.module';
import { ContextModule } from './context.module';
import { ManifestModule } from './manifest.module';

/**
 * Module parent pour la déclaration du store NgRx
 */
@NgModule({
  imports: [
    StoreModule.forRoot({}),
    UIModule,
    SessionModule,
    PlacesModule,
    PMModule,
    ContextModule,
    ManifestModule
  ],
})
export class AppReduxModule {}
