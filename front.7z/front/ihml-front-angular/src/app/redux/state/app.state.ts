import { PlacesState } from './places.state';
import { SessionState } from './session.state';
import { UIState } from './ui.state';
import { PMState } from './pm.state';
import { ContextState } from './context.state';
import { ManifestState } from './manifest.state';

/**
 * Interface déclarant le state globale de l'application
 */
export interface AppState {
    pm: PMState;
    ui: UIState;
    session: SessionState;
    places: PlacesState;
    context: ContextState;
    manifest: ManifestState;
}
