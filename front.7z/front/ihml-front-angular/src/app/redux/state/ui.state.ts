import { Path } from '../../models/path';

/**
 * Interface décrivant le state ui
 */
export interface UIState {
    title: string;
    activeMenu: string;
    lastError: UIError;
}

/**
 * Interface décrivant une erreur
 */
export interface UIError {
    operation: string;
    errorMessage: string;
    details?: any;
    link?: Path;
    errorAction?: ErrorAction;
}

export interface ErrorAction {
    action: Action;
    label: string;
}

export enum Action {
    Deconnexion
}
