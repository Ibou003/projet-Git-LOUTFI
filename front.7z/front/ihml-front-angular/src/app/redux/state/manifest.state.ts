/**
 * Interface décrivant le state manifest
 */
export interface ManifestState {
    bff: BffState;
    front: FrontState;
}

/**
 * Interface décrivant le state Bff
 */
export interface BffState {
    version: string;
    framework: string;
}

/**
 * Interface décrivant le state Front
 */
export interface FrontState {
    version: string;
}

