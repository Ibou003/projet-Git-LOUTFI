import { createAction, props } from '@ngrx/store';
import { BffState, FrontState } from '../state/manifest.state';

/**
 * Actions concernant les UI
 */
export const setBffManifest = createAction('[Application] mise jour du manifest bff', props<{manifest: BffState}>());
export const setFrontManifest = createAction('[Application] mise jour du manifest front', props<{manifest: FrontState}>());
