import { createAction, props } from '@ngrx/store';
import { UIError } from '../state/ui.state';

/**
 * Actions concernant les UI
 */
export const setTitle = createAction('[Application] mise jour du titre de l\'application', props<{ title: string }>());
export const setActiveMenu = createAction('[Application] mise jour du menu sélectionné', props<{ activeMenu: string }>());
export const setLastError = createAction('[Application] mise jour de la dernière erreur', props<{ lastError: UIError }>());
