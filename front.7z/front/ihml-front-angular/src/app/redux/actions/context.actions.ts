import { createAction, props } from '@ngrx/store';
import { Context } from '../../models/context';


/**
 * Actions concernant le context
 */
export const getContext = createAction('[Context] récupération du contexte', props<{idCtx: string}>());
export const setContext = createAction('[Context] mise à jour du contexte', props<{context: Context}>());

/**
 * Action concernant la mise à jour de la CR dans le contexte
 */
export const resetContextCR = createAction('[Context] reset de la CR dans le context');
export const resetContextEntity = createAction('[Context] reset de l entity dans le context');
