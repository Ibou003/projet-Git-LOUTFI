import { createAction, props } from '@ngrx/store';
import { CR, DistributionEntity, Entity } from '../../models/places';

/**
 * Actions concernant les CR
 */
export const getCRList = createAction('[Places] récupération liste des CR');
export const setCRList = createAction('[Places] mise à jour liste des CR', props<{crsList: CR[]}>());
export const selectCRById = createAction('[Places] selection de la CR', props<{crId: string}>());

/**
 * Actions concernant les villes des agences
 */
export const getEntitiesList = createAction('[Places] récupération liste des villes de la CR', props<{selectedCrId: string}>());
export const setEntitiesList = createAction('[Places] mise à jour liste des villes de la CR', props<{entiesList: Entity[]}>());
export const selectEntityByZipCode = createAction('[Places] selection de la ville', props<{entityZipCode: string}>());

/**
 * Actions concernant les agences
 */
export const getDistributionEntities = createAction('[Places] récupération liste des agences de la ville de la CR', props<{selectedCrId: string, selectedEntityZipCode: string}>());
export const setDistributionEntities = createAction('[Places] mise à jour liste des agences de la ville de la CR', props<{distributionEntiesList: DistributionEntity[]}>());
export const selectDistributionEntityById = createAction('[Places] selection de l\'agence', props<{distributionEntityId: string}>());
