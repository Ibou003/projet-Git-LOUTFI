import { createSelector } from '@ngrx/store';
import { AppState } from '../state/app.state';
import { UIState } from '../state/ui.state';

/**
 * NgRx Selector pour le store ui
 */
export const selectUIState = (state: AppState) => state.ui;

/**
 * NgRx Selector pour le store ui.title
 */
export const selectTitle = createSelector(
    selectUIState,
    (state: UIState) => state.title
);

/**
 * NgRx Selector pour le store ui.tab
 */
export const selectTab = createSelector(
    selectUIState,
    (state: UIState) => state.activeMenu
);

/**
 * NgRx Selector pour le store ui.tab
 */
export const selectLastError = createSelector(
    selectUIState,
    (state: UIState) => state.lastError
);
