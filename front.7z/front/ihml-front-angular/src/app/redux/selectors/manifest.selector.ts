import { createSelector } from '@ngrx/store';
import { AppState } from '../state/app.state';
import { ManifestState } from '../state/manifest.state';

/**
 * NgRx Selector pour le store manifest
 */
export const selectManifestState = (state: AppState) => state.manifest;
