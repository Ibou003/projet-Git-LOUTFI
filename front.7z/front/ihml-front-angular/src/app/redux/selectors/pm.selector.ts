import { createSelector } from '@ngrx/store';
import { AppState } from '../state/app.state';
import { PMState } from '../state/pm.state';

/**
 * NgRx Selector pour le store post message
 */
export const selectPMState = (state: AppState) => state.pm;

/**
 * NgRx Selector pour le store pm.messages
 */
export const selectMessages = createSelector(
    selectPMState,
    (state: PMState) => state.messages
);
