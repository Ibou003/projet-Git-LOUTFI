import { createSelector, createFeatureSelector } from '@ngrx/store';
import { PlacesState } from '../state/places.state';

/**
 * NgRx Selector pour le store places
 */
export const selectPlacesState = createFeatureSelector<PlacesState>('places');

/**
 * NgRx Selector pour le store places.crs
 */
export const selectCRList = createSelector(
    selectPlacesState,
    (state: PlacesState) => state.crs
);

/**
 * NgRx Selector pour le store places.distributionEntities
 */
export const selectDistributionEntities = createSelector(
    selectPlacesState,
    (state: PlacesState) => state.distributionEntities
);

/**
 * NgRx Selector pour le store places.entities
 */
export const selectEntitiesList = createSelector(
    selectPlacesState,
    (state: PlacesState) => state.entities
);

/**
 * NgRx Selector pour le store places.selectedCR
 */
export const selectSelectCR = createSelector(
    selectPlacesState,
    (state: PlacesState) => state.selectedCR
);

/**
 * NgRx Selector pour le store places.selectedEntity
 */
export const selectEntity = createSelector(
    selectPlacesState,
    (state: PlacesState) => state.selectedEntity
);

/**
 * NgRx Selector pour le store places.selectedDistributionEntity
 */
export const selectDistributionEntity = createSelector(
    selectPlacesState,
    (state: PlacesState) => state.selectedDistributionEntity
);
