import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import * as _ from 'lodash';
import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { User } from '../models/user';
import * as SessionActions from '../redux/actions/session.actions';
import * as ManifestActions from '../redux/actions/manifest.actions';
import { AppState } from '../redux/state/app.state';
import { BffState, FrontState } from '../redux/state/manifest.state';
import { version } from '../../../package.json';

/**
 * Service pour l'initialisation de l'application
 */
@Injectable()
export class AppInitService {

    constructor(private http: HttpClient,
        private store: Store<AppState>) { }

    /**
     * Permet d'initialisation l'application.
     * Appeler au lancement de l'application
     * Important: It should return a Promise
     */
    public initialiseApp() {

        // Récupération de la configuration de l'application
        return this.http.get('configuration/app-config.json').pipe(
            map((config) => {
                _.assign(environment, config);
                return;
            }),
            mergeMap(() => {
                // Récupération du manifest du bff
                return this.http.get(`${environment.apiBasePath}/manifest`);
            }),
            map((manifest: BffState) => {
                // Mise à jour du manifes bff
                this.store.dispatch(ManifestActions.setBffManifest({manifest}));
                return manifest;
            }),
            map(() => {
                // Mise à jour du manifest front
                const manifest: FrontState = { version };

                this.store.dispatch(ManifestActions.setFrontManifest({manifest}));
                return manifest;
            }),
            mergeMap(() => {
                // Récupération de l'utilisateur lié à la session
                return this.http.get(`${environment.apiBasePath}/security/user`);
            }),
            map((user: User) => {
                // S'il y a un utilisateur connecté on le sauvergarde dans le store
                this.store.dispatch(SessionActions.setUser({ user: user }));
                return;
            }),
            catchError(err => {
                if (err.status === 404) {
                    // S'il n'y a pas d'utilisateur on le reset
                    this.store.dispatch(SessionActions.setUser({ user: null }));
                }

                return of(null);
            })).toPromise();
    }
}
