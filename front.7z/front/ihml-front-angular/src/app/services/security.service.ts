import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { HttpOperation } from '../models/http';
import { ErrorService } from './error.service';
import Constants from 'src/const';

@Injectable()
export class SecurityService {
    constructor(private http: HttpClient,
        private errorService: ErrorService) { }

    login(code: string, redirect_uri: string, sessionId: string) {
        // Ajout header pour l'authentification
        const headers = new HttpHeaders({
            'Authorization': code,
            'redirectUrl': redirect_uri,
            'state': sessionId
        });

        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/security/login`,
            operation: Constants.ACTIONS.USER_LOGIN,
            options: { headers, withCredentials: true }
        };

        return this.http.get(httpOperation.url, httpOperation.options).pipe(
            catchError(
                this.errorService.handleApiError<any>(httpOperation)
            )
        );
    }

    logout() {
        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/security/logout`,
            operation: Constants.ACTIONS.USER_LOGOUT,
            options: { responseType: 'text' }
        };

        return this.http.get(httpOperation.url, httpOperation.options).pipe(
            catchError(
                this.errorService.handleApiError<any>(httpOperation)
            )
        );
    }

    getUserConnected() {
        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/security/user`,
            operation: Constants.ACTIONS.GET_USER_INFORMATION,
            options: { responseType: 'text' }
        };

        return this.http.get(httpOperation.url).pipe(
            catchError(
                this.errorService.handleApiError<any>(httpOperation)
            )
        );
    }
}
