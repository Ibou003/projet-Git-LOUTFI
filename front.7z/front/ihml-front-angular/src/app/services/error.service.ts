import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import * as _ from 'lodash';
import { Observable } from 'rxjs';
import Constants from 'src/const';
import { HttpOperation } from '../models/http';
import { Path } from '../models/path';
import * as UIActions from '../redux/actions/ui.actions';
import { AppState } from '../redux/state/app.state';
import { Action, UIError } from '../redux/state/ui.state';

@Injectable()
export class ErrorService {
    constructor(private router: Router,
        private store: Store<AppState>) { }

    handleApiError<T>(httpOperation: HttpOperation) {
        // Reset de la dernière erreur
        this.store.dispatch(UIActions.setLastError({ lastError: null }));
        return (error: HttpErrorResponse): Observable<T> => {
            let redirectToError = false;
            const errorMsg = !_.isEmpty(error.error) ? error.error.message : error.message;

            // Création de l'objet d'affichage de l'erreur
            const uiError: UIError = {
                operation: httpOperation.operation,
                errorMessage: `${error.status} - ${errorMsg}`,
                link: {
                    root: this.router.url,
                    searchParams: null
                },
                details : {
                    Url: httpOperation.url,
                    Body: !_.isEmpty(httpOperation.body) ? JSON.stringify(httpOperation.body, null, '\t') : null
                }
            };

            switch (error.status) {
                case 0:
                    // Dans le cas d'une erreur CORS (ou serveur absent)
                    uiError.errorMessage = Constants.ERROR_MESSAGES.SERVER_NOT_REACHABLE;
                    redirectToError = true;
                    break;
                case 404:
                    redirectToError = !httpOperation.options.accept404;
                    break;
                case 401:
                    redirectToError = true;
                    uiError.details = {
                        Action: Constants.ACTIONS.REDIRECTION_TO_XCONNECT
                    },
                    uiError.link = null;
                    uiError.errorAction = {
                        action: Action.Deconnexion,
                        label: Constants.LABELS.ACTIONS.LOGOUT
                    };
                    break;
                default:
                    redirectToError = true;
            }

            if (redirectToError) {
                this.handleError(uiError);
            }

            throw error;
        };
    }

    handleError(uiError: UIError) {
        // Mise à jour de l'erreur dans le store
        this.store.dispatch(UIActions.setLastError({ lastError: uiError }));

        // Rédirection vers la page d'erreur pour l'afficher
        this.router.navigate(['/error']);
    }

    /**
 * Permet de parser la requête pour récupérer les query params
 * @param path Le chemin de la requête
 */
    getPathInfos(path: string): Path {
        const pathSplit = path.split('?');
        const queryString = pathSplit.length === 1 ? '' : pathSplit.pop();
        const queryParamsMap = {};
        if (!_.isEmpty(queryString)) {
            // Parse query string
            const params = queryString.split('&');
            params.forEach((param) => {
                const paramObject = param.split('=');
                queryParamsMap[paramObject[0]] = paramObject[1];
            });
        }

        return {
            root: pathSplit[0],
            searchParams: queryParamsMap
        };
    }
}
