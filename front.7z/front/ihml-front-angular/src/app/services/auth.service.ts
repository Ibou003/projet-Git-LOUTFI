import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as _ from 'lodash';
import { environment } from 'src/environments/environment';
import * as uuidv4 from 'uuid/v4';
import Constants from '../../const';
import { Path } from '../models/path';
import { User } from '../models/user';
import * as SessionActions from '../redux/actions/session.actions';
import * as UserSelectors from '../redux/selectors/session.selector';
import { AppState } from '../redux/state/app.state';
import { UIError } from '../redux/state/ui.state';
import { ErrorService } from './error.service';
import { SecurityService } from './security.service';

/**
 * Service pour la gestion de l'authentification
 */
@Injectable()
export class AuthService {

    // Internal variable
    private user: User;

    constructor(
        private securityService: SecurityService,
        private errorService: ErrorService,
        private router: Router,
        private store: Store<AppState>
    ) {
        // Ecoute du store pour savoir si un utilisateur a été sauvegardé
        this.store.pipe(select(UserSelectors.selectUser)).subscribe((user: User) => {
            this.user = user;

            if (!_.isEmpty(user)) {
                // Si un utilisateur existe on le redirige vers la page initialement demandée.
                const redirectTo = this.getRedirectTo();
                if (!_.isEmpty(redirectTo)) {
                    const pathInfos = this.getPathInfos(redirectTo);
                    this.removeRedirectTo();
                    this.router.navigate([pathInfos.root], {queryParams: pathInfos.searchParams});
                }
            }
        });
    }

    /**
     * Permet de savoir si un utilisateur est authentifié
     */
    get authenticated(): boolean {
        return !_.isEmpty(this.user);
    }

    /**
     * Gère la cinématique de connexion à la mire X Connect
     * @param redirectTo  Page de redirection une fois l'authentification faite
     */
    login(redirectTo: string) {
        // Sauvegarde dans le localstorage la page demandée par l'utilisateur
        this.storeRedirectTo(redirectTo);

        // Génération d'un state pour X Connect et la récupértion du refresh token
        const state: string = uuidv4();

        // Construction URL pour la redirection vers le mire X Connect
        const queryParams = {
            client_Id: environment.clientId,
            redirect_uri: environment.redirectUrl,
            response_type: 'code',
            scope: 'openid functional_posts',
            state: state
        };

        let queryParamsString = `client_id=${queryParams.client_Id}`;
        queryParamsString = `${queryParamsString}&redirect_uri=${queryParams.redirect_uri}`;
        queryParamsString = `${queryParamsString}&response_type=${queryParams.response_type}`;
        queryParamsString = `${queryParamsString}&scope=${queryParams.scope}`;
        queryParamsString = `${queryParamsString}&state=${queryParams.state}`;

        // Redirection vers la mire X Connect
        location.assign(`${environment.xConnectUrl}${Constants.ROUTES.X_CONNECT.AUTHORIZE}?${queryParamsString}`);
    }

    /**
     * Gère le retour de la mire X Connect après authentification
     */
    handleAuth() {
        // Récupération des paramètres de la requête
        const queryParamsMap = this.getPathInfos(location.search).searchParams;
        let code = null;
        let state = null;
        if (!_.isEmpty(queryParamsMap)) {
            // Sauvegarde de l'authorization code et du state
            code = queryParamsMap['code'];
            state = queryParamsMap['state'];
        }

        if (!_.isEmpty(code) && !_.isEmpty(state)) {
            // Si on un code et un state on demande la création d'un OAuthToken au BFF
            this.securityService.login(code, environment.redirectUrl, state).subscribe(() => {
                // Une fois connecté on demande les informations sur l'utilisateur
                this.store.dispatch(SessionActions.getUser());
            });
        } else {
            const uiError: UIError = {
                operation: Constants.ACTIONS.REDIRECT_FROM_XCONNECT,
                errorMessage: Constants.ERROR_MESSAGES.BAD_XCONNECT_INFORMATION,
                link: this.getPathInfos(this.router.url)
            };

            this.errorService.handleError(uiError);
        }
    }

    /**
     * Gestion de la déconnexion
     */
    logout() {
        // Appel de la déconnexion coté BFF pour revoké le refresh token
        this.securityService.logout().subscribe(
            () => { },
            () => { },
            () => {
                // Redirection vers la mire X Connect pour la déconnexion
                location.assign(`${environment.xConnectUrl}${Constants.ROUTES.X_CONNECT.LOGOUT}`);
            });
    }

    /**
     * Permet la sauvegarde de la page demandée par l'utilisateur dans le localstorage
     * @param redirectTo La page demandée
     */
    private storeRedirectTo(redirectTo: string) {
        localStorage.setItem('redirectTo', redirectTo);
    }

    /**
     * Permet la supression de la page demandée par l'utilisateur dans le localstorage
     */
    private removeRedirectTo() {
        localStorage.removeItem('redirectTo');
    }

    /**
     * Récupération de la page initialement demandée par l'utilisateur dans le localStorage
     */
    private getRedirectTo(): string {
        return _.isNull(localStorage.getItem('redirectTo')) ? null : localStorage.getItem('redirectTo');
    }

    /**
     * Permet de parser la requête pour récupérer les query params
     * @param path Le chemin de la requête
     */
    getPathInfos(path: string): Path {
        const pathSplit = path.split('?');
        const queryString = pathSplit.length === 1 ? '' : pathSplit.pop();
        const queryParamsMap = {};
        if (!_.isEmpty(queryString)) {
            // Parse query string
            const params = queryString.split('&');
            params.forEach((param) => {
                const paramObject = param.split('=');
                queryParamsMap[paramObject[0]] = paramObject[1];
            });
        }

        return {
            root: pathSplit[0],
            searchParams: queryParamsMap
        };
    }
}
