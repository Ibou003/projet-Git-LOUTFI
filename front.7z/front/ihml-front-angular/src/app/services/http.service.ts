import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpOperation } from '../models/http';
import { ErrorService } from './error.service';

/**
 * Service permettant la gestion des appels HTTP au BFF
 */
@Injectable()
export class HttpService {

    constructor(private http: HttpClient,
        private errorService: ErrorService) { }

    /**
     * Gestion des requêtes de type GET
     * @param url Chemin de l'url
     */
    public get(httpOperation: HttpOperation): Observable<any> {
        return this.http.get<any>(httpOperation.url, httpOperation.options).pipe(
            catchError(
                this.errorService.handleApiError<any>(httpOperation))
        );
    }

    /**
     * Gestion des requêtes de type POST
     * @param url Chemin de la requête
     * @param body Body de la requête
     */
    public post(httpOperation: HttpOperation): Observable<any> {
        return this.http.post<any>(httpOperation.url, httpOperation.body, httpOperation.options).pipe(
            catchError(
                this.errorService.handleApiError<any>(httpOperation))
        );
    }

    /**
     * Gestion des requêtes de type PATCH
     * @param url Chemin de la requête
     * @param body Body de la requête
     */
    public patch(httpOperation: HttpOperation): Observable<any> {
        return this.http.patch<any>(httpOperation.url, httpOperation.body, httpOperation.options).pipe(
            catchError(
                this.errorService.handleApiError<any>(httpOperation))
        );
    }

    /**
     * Gestion des requêtes de type DELETE
     * @param url Chemin de la requête
     */
    public delete(httpOperation: HttpOperation): Observable<any> {
        return this.http.delete<any>(httpOperation.url, httpOperation.options).pipe(
            catchError(
                this.errorService.handleApiError<any>(httpOperation))
        );
    }
}
