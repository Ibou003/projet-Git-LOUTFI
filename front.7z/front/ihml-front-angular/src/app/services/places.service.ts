import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { HttpOperation } from '../models/http';
import { environment } from 'src/environments/environment';
import Constants from 'src/const';

/**
 * Service pour la gestion des appels aux API places
 */
@Injectable()
export class PlacesService {
    constructor(
        private httpService: HttpService
    ) { }

    /**
     * Retourne la list des CR
     */
    getCRList() {
        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/places/regional_banks`,
            operation: Constants.ACTIONS.GET_CR_LIST
        };

        return this.httpService.get(httpOperation);
    }

    /**
     * Retourne la liste des villes d'une CR
     * @param crId L'id de la CR
     */
    getCREntities(crId: string) {
        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/places/regional_banks/${crId}/cities_with_distribution_entities`,
            operation: `${Constants.ACTIONS.GET_CR_ENTITIES_LIST} ${crId}`
        };

        return this.httpService.get(httpOperation);
    }

    /**
     * Retourne la liste des agences d'une ville d'une CR
     * @param crId L'Id de la CR
     * @param zipCode La code postal de la ville
     */
    getCRAgencesList(crId: string, zipCode: string) {
        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/places/distribution_entities/search_by_city/${crId}/${zipCode}`,
            operation: `${Constants.ACTIONS.GET_CR_CITY_DISTRIBUTION_ENTITIES}: ${crId} - ${zipCode}`
        };

        return this.httpService.get(httpOperation);
    }
}
