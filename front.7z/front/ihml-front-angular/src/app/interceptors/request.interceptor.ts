import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
/**
 * Intercepteur pour les requête HTTP
 */
@Injectable()
export class RequestInterceptor implements HttpInterceptor {

    constructor() { }

    /**
     * Intercepte la requête et rajoute la gestion des crédentials.
     * Envoi des cookies de session au BFF
     * @param req La requête
     * @param next Le prochain gestionnaire de la requête
     */
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const request = req.clone({
            withCredentials: true,
        });

        return next.handle(request);
    }
}
