import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import {SearchAgenceComponent} from './components/search-agence/root/search-agence.component';
import { ContainerComponent } from './components/container/container.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuard } from './auth/auth.guard';
import { ErrorComponent } from './components/error/error.component';
import { ComPostMessageComponent } from './components/com-post-message/com-post-message.component';
import { AuthorizeComponent } from './components/authorize/authorize.component';

/**
 * Tableau de routage de l'application
 */
const routes: Routes = [
  { path: '', children: [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'authorize', component: AuthorizeComponent },
    { path: 'error', component: ErrorComponent },
    { path: 'home', component: HomeComponent, canActivate: [AuthGuard] , data: {isSecure: false} },
    { path: 'postMessage', component: ComPostMessageComponent, canActivate: [AuthGuard], data: {isSecure: false} },
    { path: 'agences', component: SearchAgenceComponent, canActivate: [AuthGuard], data: {isSecure: true} },
  ],
    component: ContainerComponent
  }
];

/**
 * Module de routage des urls de l'application
 */
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
