import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule, MatIconModule, MatInputModule, MatProgressSpinnerModule, MatSelectModule, MatTableModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth/auth.guard';
import { AuthorizeComponent } from './components/authorize/authorize.component';
import { ComPostMessageComponent } from './components/com-post-message/com-post-message.component';
import { ContainerComponent } from './components/container/container.component';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { ListeAgenceComponent } from './components/search-agence/liste-agence/liste-agence.component';
import { SearchAgenceComponent } from './components/search-agence/root/search-agence.component';
import { appConfigurationProvider, requestInterceptorProvider } from './providers/app.provider';
import { AppEffectsModule } from './redux/effects/app.effects';
import { AppReduxModule } from './redux/modules/appredux.module';
import { AppInitService } from './services/app-init.service';
import { AuthService } from './services/auth.service';
import { HttpService } from './services/http.service';
import { PlacesService } from './services/places.service';
import { SecurityService } from './services/security.service';
import { ContextService } from './services/context.service';
import { ErrorService } from './services/error.service';

/**
 * Module principal de l'application
 */
@NgModule({
  declarations: [
    AppComponent,
    ContainerComponent,
    AuthorizeComponent,
    HomeComponent,
    SearchAgenceComponent,
    ListeAgenceComponent,
    ErrorComponent,
    ComPostMessageComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    FormsModule,
    MatProgressSpinnerModule,
    StoreDevtoolsModule.instrument({
        maxAge: 25,
        logOnly: false,
        features: {
        pause: false,
        lock: true,
        persist: true
      }
    }),
    AppReduxModule,
    AppEffectsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    AppInitService,
    appConfigurationProvider,
    requestInterceptorProvider,
    AuthGuard,
    HttpService,
    AuthService,
    SecurityService,
    PlacesService,
    ContextService,
    ErrorService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
