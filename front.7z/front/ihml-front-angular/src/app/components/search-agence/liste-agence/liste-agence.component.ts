import { Component, OnDestroy, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import * as L from 'leaflet';
import { icon, Marker } from 'leaflet';
import * as _ from 'lodash';
import { DistributionEntity, WeekSchedule } from '../../../models/places';
import { AppState } from '../../../../app/redux/state/app.state';
import * as Constants from '../../../../const';
import * as PlacesActions from '../../../redux/actions/places.actions';
import * as PlacesSelectors from '../../../redux/selectors/places.selector';

/**
 * Composant gérant la partie d'affichage des informations sur les agences
 */
@Component({
    selector: 'app-liste-agence',
    templateUrl: './liste-agence.component.html',
    styleUrls: ['./liste-agence.component.scss']
})
export class ListeAgenceComponent implements OnInit, OnDestroy {

    // Inner variable
    distributionEntities: DistributionEntity[] = [];
    selectedDistributionEntity: DistributionEntity = null;
    weekDays: any[] = Constants.default.WEEK_DAYS;
    dayOfWeekNumber: string = null;

    // OpenStreet Map variables
    map: any;
    latitude = 18.5204;
    longitude = 73.8567;

    private markers: any[] = [];
    private pinIconDefault = icon({
        iconRetinaUrl: 'assets/marker-icon-2x.png',
        iconUrl: 'assets/marker-icon-2x.png',
        shadowUrl: 'assets/marker-shadow.png',
        iconSize: [40, 41],
        iconAnchor: [20, 41],
        shadowAnchor: [12, 41],
        popupAnchor: [1, -34],
        tooltipAnchor: [16, -28],
        shadowSize: [41, 41]
    });

    private pinSelectedDefault = icon({
        iconRetinaUrl: 'assets/marker-icon-2x-selected.png',
        iconUrl: 'assets/marker-icon-2x-selected.png',
        shadowUrl: 'assets/marker-shadow.png',
        iconSize: [40, 41],
        iconAnchor: [20, 41],
        shadowAnchor: [12, 41],
        popupAnchor: [1, -34],
        tooltipAnchor: [16, -28],
        shadowSize: [41, 41]
    });

    private customMarker = L.Marker.extend({
        options: {
            distributionEntityId: ''
        }
    });

    // Listener manager
    subs = [];

    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.dayOfWeekNumber = `${new Date().getDay()}`;

        // initialisation de la map (centrée su Paris)
        this.map = L.map('map').setView(['48.8534', '2.3488'], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(this.map);

        // Initialisation variable Redux
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectDistributionEntities)).subscribe((distributionEntities: DistributionEntity[]) => {
            this.distributionEntities = distributionEntities;
            if (!_.isEmpty(distributionEntities)) {
                // Selection de la première DistributionEntity
                this.store.dispatch(PlacesActions.selectDistributionEntityById({ distributionEntityId: distributionEntities[0].id }));

                if (this.map) {
                    this.removeMarkers();

                    // Ajout des marquers
                    this.createMarkers(distributionEntities);

                    // Centrage de la map
                    this.map.setView([distributionEntities[0].coordinates.latitude, distributionEntities[0].coordinates.longitude], 15);
                }
            }
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectDistributionEntity)).subscribe((selectedDistributionEntity: DistributionEntity) => {
            this.selectedDistributionEntity = selectedDistributionEntity;

            if (!_.isNull(selectedDistributionEntity)) {
                this.onEntitySelected(selectedDistributionEntity.id);
            }
        }));
    }

    /**
     * Appeler lorsque le composant n'est plus affiché
     */
    ngOnDestroy() {
        this.subs.forEach(sub => {
            sub.unsubscribe();
        });
    }

    /**
     * Gestion d'ajouts des markers sur la map
     * @param distributionEntities Liste des agences à marquer
     */
    createMarkers(distributionEntities: DistributionEntity[]) {
        _.each(distributionEntities, (distributionEntity: DistributionEntity) => {
            const marker: Marker = new this.customMarker([distributionEntity.coordinates.latitude, distributionEntity.coordinates.longitude],
                {
                    riseOnHover: true,
                    icon: this.selectedDistributionEntity && distributionEntity.id === this.selectedDistributionEntity.id ? this.pinSelectedDefault : this.pinIconDefault,
                    distributionEntityId: distributionEntity.id
                }
            );
            this.markers.push({ id: distributionEntity.id, marker, selected: this.selectedDistributionEntity === distributionEntity });
        });

        this.addMarkers();
    }

    addMarkers() {
        _.each(this.markers, ((marker: any) => {
            marker.marker.addTo(this.map).on('click', this.onMarkerClick, this);
        }));
    }

    /**
     * Gestion de la suppression des markers sur la map
     */
    removeMarkers() {
        _.each(this.markers, (marker: Marker) => {
            this.map.removeLayer(marker);
        });
    }

    // -----------------
    // Listeners
    // -----------------


    /**
     * Listener appelé lorsqu'un marker est cliqué
     * @param marker Le marker cliqué
     */
    onMarkerClick(marker) {
        this.onEntitySelected(marker.sourceTarget.options.distributionEntityId);
    }

    /**
     * Listener appelé lorsqu'une une agence est séléctionnée
     * @param selectedEntityId L'id de l'agence séléctionnée
     */
    onEntitySelected(selectedEntityId: string) {
        this.store.dispatch(PlacesActions.selectDistributionEntityById({ distributionEntityId: selectedEntityId }));

        if (!_.isEmpty(this.map)) {
            this.map.setView([this.selectedDistributionEntity.coordinates.latitude, this.selectedDistributionEntity.coordinates.longitude], this.map.getZoom());

            // Récupération marqueur courrant
            let foundMarker: any = _.find(this.markers, { selected: true });
            if (!_.isEmpty(foundMarker)) {
                foundMarker.marker.setIcon(this.pinIconDefault);
                foundMarker.selected = false;
            }

            // Selection nouveau marqueur
            foundMarker = _.find(this.markers, { id: selectedEntityId });
            if (!_.isEmpty(foundMarker)) {
                foundMarker.marker.setIcon(this.pinSelectedDefault);
                foundMarker.selected = true;
            }
        }
    }

    /**
     * Methode pour gérer l'affichage des heures d'ouvertures.
     * Appelé depuis le HTML
     * @param dayOfWeek Le jour de la semaine à afficher
     */
    getOpeningHours(dayOfWeek) {

        let openingHours = '';
        if (!_.isEmpty(this.selectedDistributionEntity)) {
            const dayOfWeekInfo: WeekSchedule = _.find(this.selectedDistributionEntity.week_schedule, { day_of_week: dayOfWeek });

            if (!_.isEmpty(dayOfWeekInfo)) {

                if (_.isNull(dayOfWeekInfo.opening_hours[0].opening)) {
                    return 'Fermé';
                }

                // ajout de la date d'ouverture du matin
                openingHours = `${dayOfWeekInfo.opening_hours[0].opening.substr(0, 5).replace(':', 'h')}`;

                if (_.isNull(dayOfWeekInfo.opening_hours[1].opening)) {
                    // Cas ouverture non-stop
                    if (!_.isNull(dayOfWeekInfo.opening_hours[0].closing)) {
                        openingHours = `${openingHours}-${dayOfWeekInfo.opening_hours[0].closing.substr(0, 5).replace(':', 'h')}`;
                    }

                } else {

                    if (!_.isNull(dayOfWeekInfo.opening_hours[0].closing)) {
                        openingHours = `${openingHours}-${dayOfWeekInfo.opening_hours[0].closing.substr(0, 5).replace(':', 'h')}`;
                    }

                    if (!_.isNull(dayOfWeekInfo.opening_hours[1].opening)) {
                        // Cas ouverture après midi
                        openingHours = `${openingHours} ${dayOfWeekInfo.opening_hours[1].opening.substr(0, 5).replace(':', 'h')}`;

                        if (!_.isNull(dayOfWeekInfo.opening_hours[1].closing)) {
                            openingHours = `${openingHours}-${dayOfWeekInfo.opening_hours[1].closing.substr(0, 5).replace(':', 'h')}`;
                        }
                    }
                }
            }
            return openingHours;
        }
    }
}
