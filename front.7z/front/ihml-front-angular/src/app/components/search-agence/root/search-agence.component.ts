import { Component, OnDestroy, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { CR, DistributionEntity, Entity } from '../../../models/places';
import { AppState } from '../../../redux/state/app.state';
import Constants from '../../../../const';
import * as PlacesActions from '../../../redux/actions/places.actions';
import * as PlacesSelectors from '../../../redux/selectors/places.selector';
import * as ContextSelectors from '../../../redux/selectors/context.selector';
import * as UIActions from '../../../redux/actions/ui.actions';
import * as ContextActions from '../../../redux/actions/context.actions';
import * as _ from 'lodash';
import { Context, SavedContext } from '../../../models/context';
import { environment } from '../../../../environments/environment';
import { ContextService } from '../../../services/context.service';

/**
 * Composant parent gérant la page d'affichage des agences
 */
@Component({
    selector: 'app-search-agence',
    templateUrl: './search-agence.component.html',
    styleUrls: ['./search-agence.component.scss']
})
export class SearchAgenceComponent implements OnInit, OnDestroy {

    // Inner variable
    listCR: CR[] = [];
    entities: Entity[] = [];
    distributionEntities: DistributionEntity[] = [];
    selectedCR: CR = null;
    selectedEntity: Entity = null;
    context: Context = null;

    // Listener manager
    subs = [];

    constructor(private store: Store<AppState>, private contextService: ContextService) { }

    ngOnInit() {
        // Spécifie que l'onglet Home a été clické
        this.store.dispatch(UIActions.setActiveMenu({ activeMenu: Constants.MENUS.AGENCES }));

        // Initialisation redux
        this.subs.push(this.store.pipe(select(ContextSelectors.selectContextState)).subscribe((context: Context) => {
            this.context = context;
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectCRList)).subscribe((listCR: CR[]) => {
            this.listCR = listCR;

            // Si une CR est sélectionnée dans le contexte
            if (!_.isNull(this.context) && !_.isNull(this.context.regional_bank_id)) {
                this.store.dispatch(PlacesActions.selectCRById({ crId: this.context.regional_bank_id }));

                // Récupération de la liste des Entités de la CR sélectionnée
                this.store.dispatch(PlacesActions.getEntitiesList({ selectedCrId: this.context.regional_bank_id }));

                // Reset de la CR dans le context
                this.store.dispatch(ContextActions.resetContextCR());
            }
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectEntitiesList)).subscribe((entities: Entity[]) => {
            this.entities = entities;

            // Si une CR est sélectionnée dans le contexte
            if (!_.isNull(this.context) && !_.isNull(this.context.zip_code)) {
                this.store.dispatch(PlacesActions.selectEntityByZipCode({ entityZipCode: this.context.zip_code }));

                // Récupération de la liste des Entités de la CR sélectionnée
                this.store.dispatch(PlacesActions.getDistributionEntities({ selectedCrId: this.selectedCR.regional_bank_id, selectedEntityZipCode: this.context.zip_code }));

                // Reset du code postal dans le context
                this.store.dispatch(ContextActions.resetContextEntity());
            }
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectDistributionEntities)).subscribe((distributionEntities: DistributionEntity[]) => {
            this.distributionEntities = distributionEntities;
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectSelectCR)).subscribe((selectedCR: CR) => {
            this.selectedCR = selectedCR;
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectEntity)).subscribe((selectedEntity: Entity) => {
            this.selectedEntity = selectedEntity;
        }));

        // Récupération de la liste des CR
        this.store.dispatch(PlacesActions.getCRList());
    }

    /**
     * Appelé lorsque la page n'est plus affichée
     */
    ngOnDestroy() {
        this.subs.forEach(sub => {
            sub.unsubscribe();
        });
    }

    // -----------------
    // Listeners
    // -----------------

    /**
     * Listener appelé lorsque l'on change la CR selectionnée
     * @param selectedCRId L'id de la CR selectionnée
     */
    onCRChange(selectedCRId: string) {

        // Remise à zero des listes et de selections
        this.store.dispatch(PlacesActions.setDistributionEntities({ distributionEntiesList: [] }));
        this.store.dispatch(PlacesActions.setEntitiesList({ entiesList: [] }));
        this.store.dispatch(PlacesActions.selectEntityByZipCode({ entityZipCode: null }));
        this.store.dispatch(PlacesActions.selectDistributionEntityById({ distributionEntityId: null }));

        // Sauvegarde de la CR sélectionnée
        this.store.dispatch(PlacesActions.selectCRById({ crId: selectedCRId }));

        if (selectedCRId !== '') {
            // Récupération de la liste des Entités de la CR sélectionnée
            this.store.dispatch(PlacesActions.getEntitiesList({ selectedCrId: selectedCRId }));
        }

    }

    /**
     * Listener appelé lorsque l'on change la ville sélectionnée
     * @param selectedEntityZipCode Le code postal de la ville selectionnée
     */
    onEntityChange(selectedEntityZipCode: string) {

        // Remise à zero des listes et de selections
        this.store.dispatch(PlacesActions.setDistributionEntities({ distributionEntiesList: [] }));
        this.store.dispatch(PlacesActions.selectDistributionEntityById({ distributionEntityId: null }));

        // Sauvegarde du zip code l'entité sélectionnée
        this.store.dispatch(PlacesActions.selectEntityByZipCode({ entityZipCode: selectedEntityZipCode }));

        if (selectedEntityZipCode !== '') {
            // Récupération de la liste des agences
            this.store.dispatch(PlacesActions.getDistributionEntities({ selectedCrId: this.selectedCR.regional_bank_id, selectedEntityZipCode: selectedEntityZipCode }));
        }
    }

    /**
     * Listener sur le lien pour ouvrir l'application React
     */
    onOpenReactApplication() {

        // Sauvegarde du contexte
        const context: Context = {
            client_id: environment.reactClientId,
            regional_bank_id: this.selectedCR.regional_bank_id,
            zip_code: `${this.selectedEntity.zip_code}`
        };

        this.contextService.setContext(context).subscribe((savedContext: SavedContext) => {
            window.open(`${environment.reactUrl}/${Constants.ROUTES.REACT.AGENCES}?idCtx=${savedContext.context_id}`);
        });
    }

}
