import { Component, OnInit } from '@angular/core';
import Constants from '../../../const';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../redux/state/app.state';
import * as UIActions from '../../redux/actions/ui.actions';
import { ManifestState } from '../../redux/state/manifest.state';
import * as ManifestSelectors from '../../redux/selectors/manifest.selector';

/**
 * Composant affichant l'onglet Accueil
 */
@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

    // Redux Variable
    manifest: ManifestState;

    // Listener manager
    subs = [];

    constructor(private store: Store<AppState>) { }

    ngOnInit() {

        // Initialisation redux
        this.subs.push(this.store.pipe(select(ManifestSelectors.selectManifestState)).subscribe((manifest: ManifestState) => {
            this.manifest = manifest;
        }));

        // Spécifie que l'onglet Home a été clické
        this.store.dispatch(UIActions.setActiveMenu({ activeMenu: Constants.MENUS.HOME }));
    }

}
