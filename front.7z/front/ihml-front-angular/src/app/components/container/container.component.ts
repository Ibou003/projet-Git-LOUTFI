import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as _ from 'lodash';
import { ManifestState } from 'src/app/redux/state/manifest.state';
import Constants from '../../../const';
import { environment } from '../../../environments/environment';
import { Message } from '../../models/postmessage';
import { User } from '../../models/user';
import * as ContextActions from '../../redux/actions/context.actions';
import * as PostMessageActions from '../../redux/actions/pm.actions';
import * as UIActions from '../../redux/actions/ui.actions';
import * as ManifestSelectors from '../../redux/selectors/manifest.selector';
import * as UserSelectors from '../../redux/selectors/session.selector';
import * as UISelectors from '../../redux/selectors/ui.selector';
import { AppState } from '../../redux/state/app.state';
import { AuthService } from '../../services/auth.service';
/**
 * Composant principal englobant tous les autres
 */
@Component({
    selector: 'app-container',
    templateUrl: './container.component.html',
    styleUrls: ['./container.component.scss']
})
export class ContainerComponent implements OnInit, OnDestroy {

    // Redux Variable
    title: string;
    user: User;
    activeMenu = Constants.MENUS.HOME;
    manifest: ManifestState;

    // Inner variable
    userLoggedIn = false;
    loginAction = Constants.LABELS.ACTIONS.LOGIN;
    idCtx = null;
    envLoaded = false;

    // Listener manager
    subs = [];

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private authService: AuthService,
        private store: Store<AppState>
    ) { }

    ngOnInit() {
        // Initialisation redux
        this.subs.push(this.store.pipe(select(UISelectors.selectTitle)).subscribe((title: string) => {
            this.title = title;
        }));
        this.subs.push(this.store.pipe(select(UISelectors.selectTab)).subscribe((activeMenu: string) => {
            this.activeMenu = activeMenu;
        }));
        this.subs.push(this.store.pipe(select(UserSelectors.selectUser)).subscribe((user: User) => {
            this.user = user;
        }));
        this.subs.push(this.store.pipe(select(ManifestSelectors.selectManifestState)).subscribe((manifest: ManifestState) => {
            this.manifest = manifest;
        }));

        // Récupération des query params
        this.route.queryParamMap.subscribe(params => {
            this.idCtx = params.get(Constants.ROUTES.PARAMS.ID_CONTEXT) || null;

            // Récupération du context si besoin
            if (!_.isEmpty(this.idCtx)) {
                this.store.dispatch(ContextActions.getContext({ idCtx: this.idCtx }));
            }
        });

        // ecoute post message
        this.setUpPostMessage();

        // Selection du menu originel
        this.selectMenuItem();

        // Initialisation inner varialbes
        this.loginAction = Constants.LABELS.ACTIONS.LOGOUT;

        // Chargement initial de l'environnement de l'application
        if (!this.envLoaded) {
            this.loadEnvironment();
        }

    }

    /**
     * Appelé lorsque la page n'est plus affichée
     */
    ngOnDestroy() {
        this.subs.forEach(sub => {
            sub.unsubscribe();
        });
    }

    /**
     * Ecoute evenement message
     */
    setUpPostMessage() {
        window.addEventListener('message', this.onPostMessage.bind(this));
    }
    /**
     * Traitement du message à reception
     */
    onPostMessage(event) {

        try {
            if (event.origin === window.location.origin) {
                console.log('onpostMessage same origine ');
                if (event.type === 'message') {
                    const receiveData = JSON.parse(event.data);
                    if (receiveData.messageType) {
                        const message: Message = receiveData;
                        console.log('onpostMessage : ' + message.messageType);

                        this.store.dispatch(PostMessageActions.setMessage({ message }));
                    }
                }
            } else {
                console.log('onpostMessage origine: ' + event.origin);
                const receiveData = JSON.parse(event.data);
                if (receiveData.messageType) {
                    const message: Message = receiveData;
                    console.log('onpostMessage : ' + message.messageType);

                    this.store.dispatch(PostMessageActions.setMessage({ message }));
                }
            }
        } catch (exp) {

        }

    }
    /**
     * Selection du menu depuis l'url
     */
    selectMenuItem() {
        this.activeMenu = this.router.url.split('/')[1];
    }
    // -----------------
    // Listeners
    // -----------------

    /**
     * Listener pour la selection d'un item de menu
     * @param menuItem Menu selectionné
     */
    onMenuItemClicked(menuItem) {
        this.activeMenu = menuItem;
    }

    /**
     * Listener pour la déconnexion
     */
    onLogout() {
        this.authService.logout();
    }


    // -----------------
    // Api
    // -----------------

    /**
     * Chargement de l'environnement de l'application
     */
    loadEnvironment() {
        // Récupération du titre de l'application depuis la configuration
        this.store.dispatch(UIActions.setTitle({ title: environment.title }));
        this.envLoaded = true;
    }
}
