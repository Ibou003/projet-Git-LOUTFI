import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

/**
 * Composant pour appeler lors du retour de la mire X Connect
 */
@Component({
    selector: 'app-authorize',
    templateUrl: './authorize.component.html',
    styleUrls: ['./authorize.component.scss']
})
export class AuthorizeComponent implements OnInit {

    constructor(
        private authService: AuthService
    ) { }

    ngOnInit() {
        // Demande juste au service d'authentication de gérer le retour de la Mire
        this.authService.handleAuth();
    }
}
