/**
 * Interface décrivant le type d'un post message
 */
export interface MessageType {
    name: string;
    version: string;
}

/**
 * Interface décrivant le type d'un évnènement d'un post message
 */
export interface Evenement {
    eventId: string;
}

/**
 * Interface décrivant les data d'un post message
 */
export interface Data {
    value: string;
}

/**
 * Interface décrivant un post message
 */
export interface Message {
    version: string;
    messageType: string;
    eventId: string;
    data: string;
}