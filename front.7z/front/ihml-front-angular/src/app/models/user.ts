/**
 * Interface décrivant un utilisateur
 */
export interface User {
    id: string;
}
