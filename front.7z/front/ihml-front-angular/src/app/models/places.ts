/**
 * Interface décrivant un CR
 */
export interface CR {
    regional_bank_id: string;
    regional_bank_name: string;
}

/**
 * Interface décrivant une ville d'une CR
 */
export interface Entity {
    city_name: string;
    zip_code: number;
}

/**
 * Interface décrivant une agence
 */
export interface DistributionEntity {
    id: string;
    name: string;
    regional_bank_id: string;
    type: number;
    services: Services;
    address: Address;
    week_schedule?: Array<WeekSchedule>;
    coordinates: Coordinates;
    market: Market;
    contact: Contact;
    id_eds_banalise: string;
}

/**
 * Interface décrivant les services proprosés par une agence
 */
export interface Services {
    atm: boolean;
    automatic_cash_machine: boolean;
    wheel_chair_access: boolean;
    car_park: boolean;
    exchange_currency: boolean;
    extra_service_1: string;
    extra_service_2: string;
    extra_service_3: string;
}

/**
 * Interface décrivrant l'adresse d'une agence
 */
export interface Address {
    address: string;
    city_name: string;
    zip_code: string;
    business_zip_code: string;
}

/**
 * Interface décrivant le planning d'ouverture d'un journée d'une agence
 */
export interface WeekSchedule {
    day_of_week: string;
    opening_hours: Array<OpeningHours>;
}

/**
 * Interface décrivant les heures d'ouvertures d'une agence
 */
export interface OpeningHours {
    opening: string;
    closing: string;
}

/**
 * Interface décrivant le type de marché d'une agence
 */
export interface Market {
    general_public: boolean;
    private_banking: boolean;
    pro: boolean;
    farmer: boolean;
    association: boolean;
    enterprise: boolean;
    public_collectivity: boolean;
}

/**
 * Interface décrivant les informations de contact d'une agence
 */
export interface Contact {
    email_address: string;
    phone_number: string;
    phone_fee: string;
    fax: string;
}
