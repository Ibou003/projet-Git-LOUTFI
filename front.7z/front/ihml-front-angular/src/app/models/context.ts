export interface Context {
    client_id?: string;
    regional_bank_id?: string;
    zip_code?: string;
}

export interface SavedContext {
    context_id: string;
}
