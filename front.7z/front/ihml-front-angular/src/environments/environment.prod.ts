class Environment {

    public production: boolean;
    public title: string;
    public apiBasePath: string;
    public xConnectUrl: string;
    public clientId: string;
    public redirectUrl: string;
    public reactClientId: string;
    public reactUrl: string;
    constructor() {
        this.production = true;
    }
}

export const environment = new Environment();
