import {BaseError} from './BaseError';

export class APIError extends BaseError {

    public code: string;

    public  constructor(msg: string, previousError?: Error, data?: any) {
        super(msg, previousError, data);
        Object.setPrototypeOf(this, APIError.prototype);
        if (typeof data === 'number') {
            this.code = data.toString();
            this.data = null;
        } else if (typeof data === 'object' && this.data.code) {
            this.code = this.data.code;
            delete this.data.code;
        } else if (previousError) {
            this.code = '500';
            this.data = previousError;
        }
    }
}
