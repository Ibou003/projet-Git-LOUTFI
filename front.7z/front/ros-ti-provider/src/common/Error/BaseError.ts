export class BaseError extends Error {

    public uid: string;
    public data: any;
    public previousError: Error;

    public  constructor(msg: string, previousError?: Error, data?: any) {
        super();
        this.message = msg;
        Object.setPrototypeOf(this, BaseError.prototype);
        this.data = data;
        this.previousError = previousError;
    }
}
