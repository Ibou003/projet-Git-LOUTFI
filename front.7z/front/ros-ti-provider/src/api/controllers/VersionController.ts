/**
 * Controller for User
 */
import { provideSingleton, inject } from '../../ioc/ioc';
import { Route, Tags, Get, Body, Post} from 'tsoa';
import { VersionService } from '../services/VersionService';

@Route('version')
@Tags('version')
@provideSingleton(CheckVersionController)
export class CheckVersionController {

    @inject(VersionService)
    private versionService: VersionService;
    /**
     * Get routingChek API
     */
    @Get()
    public getTest(): string {
      return this.versionService.getVersion();
    }

    @Post()
    public postTest(@Body() body: any): any {
      return this.versionService.postVersion(JSON.stringify(body, null, 2));
    }
}
