/**
 * Controller for rds
 */
import * as Promise from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Get, Route, Post, Delete, Put, Body, Tags } from 'tsoa';
import { Eds } from '../models/Eds';
import { EdsService } from '../services/EdsService';

@Route('eds')
@Tags('eds')
@provideSingleton(EdsController)
export class EdsController {

    @inject(EdsService)
    private edsService: EdsService;

    /**
     * Get list of rdss
     */
    @Get()
    public getEdsList(): Promise<Eds[]> {
        return this.edsService.getEdsList();
    }

    /**
     * Get a specific rds
     */
    @Get('/{id}')
    public getEds(id: string): Promise<Eds> {
        return this.edsService.getEds(id);
    }

    /**
     * Add a rds
     */
    @Post()
    public addEds(@Body() eds: Eds): Promise<Eds> {
        return this.edsService.addEds(eds);
    }

    /**
     * Update a rds
     */
    @Put('/{id}')
    public updateEds(id: string, @Body() eds: Eds): Promise<Eds> {
        return this.edsService.updateEds(id, eds);
    }

    /**
     * Delete a specific rds
     */
    @Delete('/{id}')
    public removeEds(id: string): Promise<Eds> {
        return this.edsService.removeEds(id);
    }
}
