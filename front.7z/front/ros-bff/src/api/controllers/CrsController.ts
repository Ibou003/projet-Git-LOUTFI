/**
 * Controller for Crs
 */
import * as Promise from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Get, Route, Post, Delete, Put, Body, Tags } from 'tsoa';
import { Cr } from '../models/CR';
import { CrsService } from '../services/CrsService';

@Route('crs')
@Tags('crs')
@provideSingleton(CrsController)
export class CrsController {

    @inject(CrsService)
    private crsService: CrsService;

    /**
     * Get list of crs
     */
    @Get()
    public getCrs(): Promise<Cr[]> {
        return this.crsService.getCrs();
    }

    /**
     * Get a specific crs
     */
    @Get('/{id}')
    public getCr(id: string): Promise<Cr> {
        return this.crsService.getCr(id);
    }

    /**
     * Add a crs
     */
    @Post()
    public addCr(@Body() cr: Cr): Promise<Cr> {
        console.log('POST => ', cr);
        return this.crsService.addCr(cr);
    }

    /**
     * Update a crs
     */
    @Put('/{id}')
    public updateCr(id: string, @Body() cr: Cr): Promise<Cr> {
        return this.crsService.updateCr(id, cr);
    }

    /**
     * Delete a specific crs
     */
    @Delete('/{id}')
    public removeCr(id: string): Promise<Cr> {
        return this.crsService.removeCr(id);
    }
}
