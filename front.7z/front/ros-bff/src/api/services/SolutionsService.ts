import * as Promise from 'bluebird';
import { provideSingleton } from '../../ioc/ioc';
import { Solution } from '../models/Solution';
import * as _ from 'lodash';
import { NotFoundAPIError } from '../../common/Error/NotFoundAPIError';
import { IllegalArgumentError } from '../../common/Error/IllegalArgumentError';

@provideSingleton(SolutionsService)
export class SolutionsService {

    private solutions: Solution[];

    constructor() {
        this.solutions = [];
    }

    public getSolutions(): Promise<Solution[]> {
        return this.solutions;
    }

    public getSolution(id: string): Promise<Solution> {
        const solution: Solution = _.find(this.solutions, {id: id});

        if (!_.isEmpty(solution)) {
            return solution;
        } else {
            throw new NotFoundAPIError(`Solution with id ${id} not found`);
        }
    }

    public addSolution(solution: Solution): Promise<Solution> {
        // check if solution with id already exists
        const foundSolution = _.find(this.solutions, {id: solution.id});

        if (!_.isEmpty(foundSolution)) {
            throw new IllegalArgumentError(`Solution with id ${solution.id} already exists`);
        } else {
            this.solutions.push(solution);
            return solution;
        }
    }

    public updateSolution(id: string, solution: Solution): Promise<Solution> {
        // Check if solution with id exists
        const solutionIndex = _.findIndex(this.solutions, {id: id});

        if (solutionIndex > -1) {
            this.solutions[solutionIndex] = solution;
            return solution;
        } else {
            throw new NotFoundAPIError(`Solution with id ${id} not found`);
        }
    }

    public removeSolution(id: string): Promise<Solution> {
        const solutionRemoved: Solution[] = _.remove(this.solutions, (solution) => {
            return solution.id === id;
        });

        if (!_.isEmpty(solutionRemoved)) {
             return solutionRemoved;
        } else {
            throw new NotFoundAPIError(`Solution with id ${id} not found`);
        }
    }
}
