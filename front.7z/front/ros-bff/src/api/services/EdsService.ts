import * as Promise from 'bluebird';
import { provideSingleton } from '../../ioc/ioc';
import { Eds } from '../models/Eds';
import * as _ from 'lodash';
import { NotFoundAPIError } from '../../common/Error/NotFoundAPIError';
import { IllegalArgumentError } from '../../common/Error/IllegalArgumentError';

@provideSingleton(EdsService)
export class EdsService {

    private edsList: Eds[];

    constructor() {
        this.edsList = [];
    }

    public getEdsList(): Promise<Eds[]> {
        return this.edsList;
    }

    public getEds(id: string): Promise<Eds> {
        const eds: Eds = _.find(this.edsList, {id: id});

        if (!_.isEmpty(eds)) {
            return eds;
        } else {
            throw new NotFoundAPIError(`Eds with id ${id} not found`);
        }
    }

    public addEds(eds: Eds): Promise<Eds> {
        // check if eds with id already exists
        const foundEds = _.find(this.edsList, {id: eds.id});

        if (!_.isEmpty(foundEds)) {
            throw new IllegalArgumentError(`Eds with id ${eds.id} already exists`);
        } else {
            this.edsList.push(eds);
            return eds;
        }
    }

    public updateEds(id: string, eds: Eds): Promise<Eds> {
        // Check if eds with id exists
        const edsIndex = _.findIndex(this.edsList, {id: id});

        if (edsIndex > -1) {
            this.edsList[edsIndex] = eds;
            return eds;
        } else {
            throw new NotFoundAPIError(`Eds with id ${id} not found`);
        }
    }

    public removeEds(id: string): Promise<Eds> {
        const edsRemoved: Eds[] = _.remove(this.edsList, (eds) => {
            return eds.id === id;
        });

        return edsRemoved.length > 0 ? edsRemoved[0] : null ;
    }
}
