export interface Eds {
    id: string;
    label: string;
}
