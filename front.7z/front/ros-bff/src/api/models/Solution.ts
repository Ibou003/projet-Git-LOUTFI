export interface Solution {
    id: string;
    label: string;
    description: string;
    rules: SolutionRules;
}

export interface SolutionRules {
    defaultServiceName: string;
    crs: Rule[];
    eds: Rule[];
    posteOp: Rule[];
}

export interface Rule {
    id: string;
    serviceName: string;
}
