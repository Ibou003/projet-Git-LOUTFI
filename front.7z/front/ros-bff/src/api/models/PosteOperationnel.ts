export interface PosteOperationnel {
    id: string;
    label: string;
}
