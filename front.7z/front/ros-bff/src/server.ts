import 'reflect-metadata';
import * as bodyParser from 'body-parser';
import * as cors from 'cors';
import * as express from 'express';
import * as cookieParser from 'cookie-parser';
import * as morgan from 'morgan';
import {APIError} from './common/Error/APIError';
import { RegisterRoutes } from './api/routes/routes';

const app = express();
 const options: cors.CorsOptions = {
    credentials: true,
    methods: 'GET,HEAD,OPTIONS,PUT,PATCH,POST,DELETE',
    origin: '*',
    preflightContinue: false
};

require('source-map-support').install();

class Server {

    public static bootstrap(): Server {
        const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 8080;

        app.use(cors(options));

        app.disable('x-powered-by');
        app.use(morgan('dev'));
        app.use(cookieParser());

        console.log(`Starting ROS IHM server on port ${port} ...`);

        app.use(bodyParser.urlencoded({extended: true}));
        app.use(bodyParser.json());

        RegisterRoutes(app);
        app.use(function (err: any, req: express.Request, res: express.Response, next: express.NextFunction) {
            let apiErr = null;
            if (err instanceof APIError) {
                apiErr = err;
            } else {
                apiErr = new APIError('internal_error', err);
            }

            err = {
                uid: apiErr.uid,
                message: apiErr.message,
                data: apiErr.data
            };
            res.status(apiErr.code).json(err);
        });

        app.listen(port, '0.0.0.0', () => {
            console.log('Server stated !!!');
        });

        process.on('SIGINT', function () {
            console.error('Caught SIGINT, shutting down.');
            process.exit(0);
        });

        return this;
    }
}

let server = Server.bootstrap();
export { server };
