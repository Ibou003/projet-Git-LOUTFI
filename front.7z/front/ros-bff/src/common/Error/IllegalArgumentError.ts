import {APIError} from './APIError';
import Constants from '../../utils/Constants';

export class IllegalArgumentError extends APIError {

    public  constructor(msg: string, previousError?: Error, data?: any) {
        super(msg, previousError, data);
        this.code = `${Constants.HTTP.RESPONSE.STATUS.PRECONDITION_FAILED.CODE}`;
    }
}
