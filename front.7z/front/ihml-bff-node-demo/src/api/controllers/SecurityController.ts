/**
 * Controller for security / authentication
 * @class: SecurityController
 */
import * as Promise from 'bluebird';
import * as express from 'express';
import { provideFluent, inject} from '../../ioc/ioc';
import { Get, Route, Tags, Header, Delete, Request, Security, Post } from 'tsoa';
import { SecurityService } from '../services/SecurityService';
import { Session } from '../models/Security';
import { ApiController } from './ApiController';
import Constants from '../../utils/Constants';
import { User } from '../models/User';

@Route('security')
@provideFluent(SecurityController)
export class SecurityController extends ApiController {

    @inject(SecurityService)
    private securityService: SecurityService;

    @Tags('Security')
    @Get('/login')
    public login(@Header('Authorization') code: string, @Header('RedirectUrl') redirectUri: string, @Header('SessionId') sessionId: string): Promise<Session> {
        return this.securityService.login(code, redirectUri, sessionId).then((session: Session) => {
            this.addHeader('Set-Cookie', `${Constants.SECURITY.SESSION.COOKIE}=${session.id}; Domain=${process.env.DOMAIN}; path=/; Max-Age=28800`);
            return session;
        });
    }

    @Tags('Security')
    @Get('/logout')
    public logout(@Request() request: express.Request): Promise<string> {
        return this.securityService.logout(this.getSessionId(request));
    }

    @Tags('Security')
    @Post('/logout')
    public postLogout(@Request() request: express.Request): Promise<string> {
        return this.securityService.logout(this.getSessionId(request));
    }

    @Tags('Security')
    @Get('user')
    public getUserConnected(@Request() request: express.Request): Promise<User> {
        return this.securityService.getUserSession(this.getSessionId(request)).then((user: User) => {
            this.addHeader('Set-Cookie', `${Constants.SECURITY.USER_INFO.COOKIE}=${JSON.stringify(user)}; Domain=${process.env.DOMAIN}; path=/; Max-Age=28800`);
            return user;
        });
    }

    @Tags('Security')
    @Get('/sessions')
    @Security('admin_token')
    public getSession(): Promise<Session> {
       return this.securityService.getSessions();
    }

    @Tags('Security')
    @Delete('/sessions')
    @Security('admin_token')
    public clearSessions(): Promise<any> {
        return this.securityService.clearSessions();
    }
}
