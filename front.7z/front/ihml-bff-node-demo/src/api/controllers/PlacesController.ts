/**
 * Controller for Places
 */
import * as express from 'express';
import * as Promise from 'bluebird';
import { provideSingleton, inject } from '../../ioc/ioc';
import { Get, Route, Tags, Security, Request } from 'tsoa';
import { CR, Entity, DistributionEntity } from '../models/Places';
import { PlacesService } from '../services/PlacesService';
import { ApiController } from './ApiController';

@Route('places')
@Tags('Places')
@provideSingleton(PlacesController)
export class PlacesController extends ApiController {

    @inject(PlacesService)
    private placesService: PlacesService;

    /**
     * Get list of CR
     */
    @Get('regional_banks')
    @Security('api_token')
    public getCRList(@Request() request: express.Request): Promise<CR[]> {
        return this.placesService.getCRList(request['session']);
    }

    /**
     * Get list of CR
     */
    @Get('regional_banks/{crId}/cities_with_distribution_entities')
    @Security('api_token')
    public getCREntities(@Request() request: express.Request, crId: number): Promise<Entity[]> {
        return this.placesService.getCREntities(request['session'], crId);
    }

    /**
     * Get list of Agences par CR
     */
    @Get('distribution_entities/search_by_city/{crId}/{zipCode}')
    @Security('api_token')
    public getCRAgencesList(@Request() request: express.Request, crId: number, zipCode: number): Promise<DistributionEntity[]> {
        return this.placesService.getCRAgencesList(request['session'], crId, zipCode);
    }
}
