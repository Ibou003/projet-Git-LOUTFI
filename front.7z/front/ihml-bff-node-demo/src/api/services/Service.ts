import { provideSingleton, inject } from '../../ioc/ioc';
import { SecurityService } from './SecurityService';
import { Session } from '../models/Security';
import * as configuration from 'config';
import * as _ from 'lodash';
import * as uuidV4 from 'uuid/v4';
import { BaseError } from '../../common/Error/BaseError';
import Constants from '../../utils/Constants';

@provideSingleton(Service)
export class Service {
    @inject(SecurityService) securityService: SecurityService;

    public rp;

    constructor() {
        this.rp = require('request-promise');
    }

    getSession(sessionId: string): Promise<Session> {
        if (sessionId) {
            const session =  this.securityService.getSession(sessionId);
            if (_.isEmpty(session)) {
                // Aucune session trouvée
                const err = new BaseError(Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE);
                throw err;
            } else {
                return Promise.resolve(session);
            }
        } else {
            const err = new BaseError(Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE);
            throw err;
        }
    }

    getRequestOptions(session: Session, msUrl: string, method: string, body: any = {}, additionnalHeaders: any = null): any {
        let options = {
            headers: {
                authorization: `Bearer ${session.token.access_token}`,
                correlationId: uuidV4(),
                cats_consommateur: configuration.get('security.catsConsommateur')
            },
            json: true,
            method: method,
            uri: msUrl,
        };

        if (!_.isNull(additionnalHeaders)) {
            options.headers = _.assign(options.headers, additionnalHeaders);
        }

        if (method === 'POST' && !_.isUndefined(body)) {
            options['body'] = body;
        }
        return options;
    }
}
