import * as Promise from 'bluebird';
import { provideSingleton } from '../../ioc/ioc';
import { CR, Entity, DistributionEntity } from '../models/Places';
import { Service } from './Service';
import { Session } from '../models/Security';
import Constants from '../../utils/Constants';

@provideSingleton(PlacesService)
export class PlacesService extends Service {

    public getCRList(sessionId: string): Promise<CR[]> {
        return this.getSession(sessionId).then((session: Session) => {
            const url = Constants.URLS.MS.PLACES + '/regional_banks';
            const options = this.getRequestOptions(session, url, 'GET');
            return this.rp(options).then((crs: CR[]) =>  {
                return crs;
            });
        });
    }

    public getCREntities(sessionId: string, crId: number): Promise<Entity[]> {
        return this.getSession(sessionId).then((session: Session) => {
            const url = Constants.URLS.MS.PLACES + `/regional_banks/${crId}/cities_with_distribution_entities?type=1`;
            const options = this.getRequestOptions(session, url, 'GET');
            return this.rp(options).then((entities: Entity[]) =>  {
                return entities;
            });
        });
    }

    public getCRAgencesList(sessionId: string, crId: number, zipCode: number): Promise<DistributionEntity[]> {
        return this.getSession(sessionId).then((session: Session) => {
            const url = Constants.URLS.MS.PLACES + `/distribution_entities/search_by_city?regional_bank_id=${crId}&zip_code=${zipCode}`;
            const options = this.getRequestOptions(session, url, 'GET');
            return this.rp(options).then((agences) =>  {
                return agences;
            });
        });
    }
}
