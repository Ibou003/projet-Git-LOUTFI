/**
 * Authentication service to check jwt Token
 */

// Import for JWT token
import * as Promise from 'bluebird';
import * as express from 'express';
import * as _ from 'lodash';
import * as moment from 'moment';
import Constants from '../../utils/Constants';
import { APIError } from '../../common/Error/APIError';
import { SecurityService } from './SecurityService';
import { Session } from '../models/Security';

export function expressAuthentication(request: express.Request, securityService: SecurityService, securityName: string, scopes?: string[]): Promise<any> {
    if (securityName === 'api_token') {
        // Get token from cookie
        const cookies = request.cookies;
        let sessionId = _.has(cookies, Constants.SECURITY.SESSION.COOKIE) ? cookies[Constants.SECURITY.SESSION.COOKIE] : '';

        // Split token string --> remove Bearer attributes
        return new Promise((resolve, reject) => {
            // si aucune session --> 401
            if (sessionId === '') {
                reject(new APIError(Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE));
            }

            // Récupération du token associé à la sessionId
            const session: Session = securityService.getSession(sessionId);
            if (_.isEmpty(session)) {
                // Si aucun token pour cette session --> 401
                reject(new APIError(Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE));
            }


            const timeoutSession = moment(session.token.expirationDate).add(2, 'hours');
            if (moment().isBefore(session.token.expirationDate)) {
                // Le token de la sessionb est toujours valide
                resolve(session.id);
            } else if (moment().isBefore(timeoutSession)) {
                // Si le token de la session a expîré depuis moins de 2 heures alors on refresh le token
                return securityService.refreshSessionToken(session.id).then(() => {
                    resolve(session.id);
                });
            } else {
                // Le token est expiré depuis plus de 5 mins on tue la sessions
                securityService.logout(session.id);
                reject(new APIError(Constants.HTTP.RESPONSE.STATUS.SESSION_EXPIRED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.SESSION_EXPIRED.CODE));
            }
        });
    } else if (securityName === 'admin_token') {
        // Get token from cookie
        let authorizationHeader = request.headers['authorization'];
        const loginPwd = !_.isEmpty(authorizationHeader) ? authorizationHeader.split(' ').pop() : null;

        return new Promise((resolve, reject) => {
            if (_.isEmpty(loginPwd)) {
                reject(new APIError(Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE));
            } else {
                const loginwPwdInfo = Buffer.from(loginPwd, 'base64').toString('ascii').split(':');
                const login = loginwPwdInfo[0];
                const pwd = loginwPwdInfo[1];

                if (_.isEmpty(login) || _.isEmpty(pwd)) {
                    reject(new APIError(Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE));
                } else if (login !== process.env.ADMIN_LOGIN || pwd !== process.env.ADMIN_LOGIN) {
                    reject(new APIError(Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.MESSAGE, null, Constants.HTTP.RESPONSE.STATUS.UNAUTHORIZED.CODE));
                } else {
                    resolve(login);
                }
            }
        });
    }
}

