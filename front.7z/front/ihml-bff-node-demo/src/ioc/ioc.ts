import { Container, inject } from 'inversify';
import { fluentProvide, buildProviderModule } from 'inversify-binding-decorators';

let iocContainer = new Container();

let provideSingleton = (identifier: any) => {
    return fluentProvide(identifier)
        .inSingletonScope()
        .done();
};

let provideFluent = (identifier: any) => {
    return fluentProvide(identifier)
        .done();
};

export { iocContainer, provideSingleton, provideFluent, inject, buildProviderModule };

