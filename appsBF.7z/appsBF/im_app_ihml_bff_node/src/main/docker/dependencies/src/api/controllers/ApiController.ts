import { provideFluent} from '../../ioc/ioc';
import * as _ from 'lodash';
import Constants from '../../utils/Constants';

@provideFluent(ApiController)
export class ApiController {
    private headers =  {} as { [name: string]: string | undefined };
    status: number;

    addHeader(name: string, value: string) {
        this.headers[name] = value;
    }

    getHeaders() {
        return this.headers;
    }

    getStatus() {
        return this.status;
    }

    setStatus(status: number) {
        this.status = status;
    }

    getSessionId(request: any) {
        const cookieSession = _.has(request.cookies, Constants.SECURITY.SESSION.COOKIE) ? request.cookies[Constants.SECURITY.SESSION.COOKIE] : '';
        console.log(`Getting sessionId from cookie: ${cookieSession}`);
        return cookieSession;
    }
}
