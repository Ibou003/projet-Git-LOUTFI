/* tslint:disable */
import { ValidateParam, FieldErrors, ValidateError, TsoaRoute } from 'tsoa';
import { iocContainer, buildProviderModule } from './../../ioc/ioc';
import { SecurityService } from '../services/SecurityService';
import { ServerController } from './../controllers/ServerController';
import { PlacesController } from './../controllers/PlacesController';
import { SecurityController } from './../controllers/SecurityController';
import { expressAuthentication } from './../services/Authentication';

iocContainer.load(buildProviderModule());
import { ApiController } from '../controllers/ApiController'
const models: TsoaRoute.Models = {
    "CR": {
        "dataType": "refObject",
        "properties": {
            "regional_bank_id": { "dataType": "string", "required": true },
            "regional_bank_name": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "Entity": {
        "dataType": "refObject",
        "properties": {
            "city_name": { "dataType": "string", "required": true },
            "zip_code": { "dataType": "double", "required": true },
        },
        "additionalProperties": true,
    },
    "Services": {
        "dataType": "refObject",
        "properties": {
            "atm": { "dataType": "boolean", "required": true },
            "automatic_cash_machine": { "dataType": "boolean", "required": true },
            "wheel_chair_access": { "dataType": "boolean", "required": true },
            "car_park": { "dataType": "boolean", "required": true },
            "exchange_currency": { "dataType": "boolean", "required": true },
            "extra_service_1": { "dataType": "string", "required": true },
            "extra_service_2": { "dataType": "string", "required": true },
            "extra_service_3": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "Address": {
        "dataType": "refObject",
        "properties": {
            "address": { "dataType": "string", "required": true },
            "city_name": { "dataType": "string", "required": true },
            "zip_code": { "dataType": "string", "required": true },
            "business_zip_code": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "OpeningHours": {
        "dataType": "refObject",
        "properties": {
            "opening": { "dataType": "string", "required": true },
            "closing": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "WeekSchedule": {
        "dataType": "refObject",
        "properties": {
            "day_of_week": { "dataType": "string", "required": true },
            "opening_hours": { "dataType": "array", "array": { "ref": "OpeningHours" }, "required": true },
        },
        "additionalProperties": true,
    },
    "Coordinates": {
        "dataType": "refObject",
        "properties": {
            "latitude": { "dataType": "string", "required": true },
            "longitude": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "Market": {
        "dataType": "refObject",
        "properties": {
            "general_public": { "dataType": "boolean", "required": true },
            "private_banking": { "dataType": "boolean", "required": true },
            "pro": { "dataType": "boolean", "required": true },
            "farmer": { "dataType": "boolean", "required": true },
            "association": { "dataType": "boolean", "required": true },
            "enterprise": { "dataType": "boolean", "required": true },
            "public_collectivity": { "dataType": "boolean", "required": true },
        },
        "additionalProperties": true,
    },
    "Contact": {
        "dataType": "refObject",
        "properties": {
            "email_address": { "dataType": "string", "required": true },
            "phone_number": { "dataType": "string", "required": true },
            "phone_fee": { "dataType": "string", "required": true },
            "fax": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "DistributionEntity": {
        "dataType": "refObject",
        "properties": {
            "id": { "dataType": "string", "required": true },
            "name": { "dataType": "string", "required": true },
            "regional_bank_id": { "dataType": "string", "required": true },
            "type": { "dataType": "double", "required": true },
            "services": { "ref": "Services", "required": true },
            "address": { "ref": "Address", "required": true },
            "week_schedule": { "dataType": "array", "array": { "ref": "WeekSchedule" } },
            "coordinates": { "ref": "Coordinates", "required": true },
            "market": { "ref": "Market", "required": true },
            "contact": { "ref": "Contact", "required": true },
            "id_eds_banalise": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "User": {
        "dataType": "refObject",
        "properties": {
            "id": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "OAuthToken": {
        "dataType": "refObject",
        "properties": {
            "expirationDate": { "dataType": "double", "required": true },
            "access_token": { "dataType": "string", "required": true },
            "type": { "dataType": "string", "required": true },
            "id_token": { "dataType": "string", "required": true },
            "refresh_token": { "dataType": "string", "required": true },
            "user": { "ref": "User" },
        },
        "additionalProperties": true,
    },
    "State": {
        "dataType": "refObject",
        "properties": {
            "redirectUri": { "dataType": "string", "required": true },
        },
        "additionalProperties": true,
    },
    "Session": {
        "dataType": "refObject",
        "properties": {
            "id": { "dataType": "string", "required": true },
            "token": { "ref": "OAuthToken" },
            "state": { "ref": "State" },
            "user": { "ref": "User" },
        },
        "additionalProperties": true,
    },
};

export function RegisterRoutes(app: any) {
    app.get('/ihml-bff-node/api/server/status',
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<ServerController>(ServerController);


            const promise = controller.getCRList.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/ihml-bff-node/api/places/regional_banks',
        authenticateMiddleware([{ "api_token": [] }]),
        function(request: any, response: any, next: any) {
            const args = {
                request: { "in": "request", "name": "request", "required": true, "dataType": "object" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<PlacesController>(PlacesController);


            const promise = controller.getCRList.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/ihml-bff-node/api/places/regional_banks/:crId/cities_with_distribution_entities',
        authenticateMiddleware([{ "api_token": [] }]),
        function(request: any, response: any, next: any) {
            const args = {
                request: { "in": "request", "name": "request", "required": true, "dataType": "object" },
                crId: { "in": "path", "name": "crId", "required": true, "dataType": "double" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<PlacesController>(PlacesController);


            const promise = controller.getCREntities.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/ihml-bff-node/api/places/distribution_entities/search_by_city/:crId/:zipCode',
        authenticateMiddleware([{ "api_token": [] }]),
        function(request: any, response: any, next: any) {
            const args = {
                request: { "in": "request", "name": "request", "required": true, "dataType": "object" },
                crId: { "in": "path", "name": "crId", "required": true, "dataType": "double" },
                zipCode: { "in": "path", "name": "zipCode", "required": true, "dataType": "double" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<PlacesController>(PlacesController);


            const promise = controller.getCRAgencesList.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/ihml-bff-node/api/security/login',
        function(request: any, response: any, next: any) {
            const args = {
                code: { "in": "header", "name": "Authorization", "required": true, "dataType": "string" },
                redirectUri: { "in": "header", "name": "RedirectUrl", "required": true, "dataType": "string" },
                sessionId: { "in": "header", "name": "SessionId", "required": true, "dataType": "string" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SecurityController>(SecurityController);


            const promise = controller.login.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/ihml-bff-node/api/security/logout',
        function(request: any, response: any, next: any) {
            const args = {
                request: { "in": "request", "name": "request", "required": true, "dataType": "object" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SecurityController>(SecurityController);


            const promise = controller.logout.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.post('/ihml-bff-node/api/security/logout',
        function(request: any, response: any, next: any) {
            const args = {
                request: { "in": "request", "name": "request", "required": true, "dataType": "object" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SecurityController>(SecurityController);


            const promise = controller.postLogout.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/ihml-bff-node/api/security/user',
        function(request: any, response: any, next: any) {
            const args = {
                request: { "in": "request", "name": "request", "required": true, "dataType": "object" },
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SecurityController>(SecurityController);


            const promise = controller.getUserConnected.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.get('/ihml-bff-node/api/security/sessions',
        authenticateMiddleware([{ "admin_token": [] }]),
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SecurityController>(SecurityController);


            const promise = controller.getSession.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });
    app.delete('/ihml-bff-node/api/security/sessions',
        authenticateMiddleware([{ "admin_token": [] }]),
        function(request: any, response: any, next: any) {
            const args = {
            };

            let validatedArgs: any[] = [];
            try {
                validatedArgs = getValidatedArgs(args, request);
            } catch (err) {
                return next(err);
            }

            const controller = iocContainer.get<SecurityController>(SecurityController);


            const promise = controller.clearSessions.apply(controller, validatedArgs as any);
            promiseHandler(controller, promise, response, next);
        });

    function authenticateMiddleware(securities: TsoaRoute.Security[] = []) {
        return (request: any, _response: any, next: any) => {
            let responded = 0;
            let success = false;
            const securityService = iocContainer.get<SecurityService>(SecurityService);
            securities
                .forEach(security => {
                    const securityKey = Object.keys(security)[0]
                    expressAuthentication(request, securityService, securityKey, security[securityKey]).then((token: any) => {
                        // only need to respond once
                        if (!success) {
                            success = true;
                            responded++;
                            request['session'] = token;
                            next();
                        }
                    })
                        .catch((error: any) => {
                            responded++;
                            if (responded == securities.length && !success) {
                                _response.status(401);
                                next(error)
                            }
                        })
                })
        }
    }

    function promiseHandler(controllerObj: any, promise: any, response: any, next: any) {
        return Promise.resolve(promise)
            .then((data: any) => {
                let statusCode;
                if (controllerObj instanceof ApiController) {
                    const controller = controllerObj as ApiController
                    const headers = controller.getHeaders();
                    Object.keys(headers).forEach((name: string) => {
                        response.set(name, headers[name]);
                    });

                    statusCode = controller.getStatus();
                }

                if (data || data === false) {
                    response.status(statusCode || 200).json(data);
                } else {
                    response.status(statusCode || 204).end();
                }
            })
            .catch((error: any) => next(error));
    }

    function getValidatedArgs(args: any, request: any): any[] {
        const errorFields: FieldErrors = {};
        const values = Object.keys(args).map(function(key) {
            const name = args[key].name;
            switch (args[key].in) {
                case 'request':
                    return request;
                case 'query':
                    return ValidateParam(args[key], request.query[name], models, name, errorFields, undefined, { "specVersion": 2 });
                case 'path':
                    return ValidateParam(args[key], request.params[name], models, name, errorFields, undefined, { "specVersion": 2 });
                case 'header':
                    return ValidateParam(args[key], request.header(name), models, name, errorFields, undefined, { "specVersion": 2 });
                case 'body':
                    return ValidateParam(args[key], request.body, models, name, errorFields, undefined, { "specVersion": 2 });
                case 'body-prop':
                    return ValidateParam(args[key], request.body[name], models, name, errorFields, undefined, { "specVersion": 2 });
            }
        });

        if (Object.keys(errorFields).length > 0) {
            throw new ValidateError(errorFields, '');
        }
        return values;
    }
}