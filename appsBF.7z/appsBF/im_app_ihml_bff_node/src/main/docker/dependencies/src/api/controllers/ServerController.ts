/**
 * Controller for Places
 */
import * as Promise from 'bluebird';
import { provideSingleton} from '../../ioc/ioc';
import { Get, Route} from 'tsoa';
import { ApiController } from './ApiController';

@Route('server')
@provideSingleton(ServerController)
export class ServerController extends ApiController {

    /**
     * Get list of CR
     */
    @Get('status')
    public getCRList(): Promise<string> {
        return Promise.resolve('Started');
    }
}
