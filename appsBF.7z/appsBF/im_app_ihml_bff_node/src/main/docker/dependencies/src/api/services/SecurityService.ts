import * as Promise from 'bluebird';
import { provideSingleton } from '../../ioc/ioc';
import * as configuration from 'config';
import Constants from '../../utils/Constants';
import * as rp from 'request-promise';
import * as moment from 'moment';
import * as _ from 'lodash';
import { OAuthToken, Session } from '../models/Security';
import { User } from '../models/User';
import { NotFoundAPIError } from '../../common/Error/NotFoundAPIError';

@provideSingleton(SecurityService)
export class SecurityService {

    sessions: Session[] = [];

    getSessions(): Promise<Session> {
        console.log(`Getting all current sessions`);
        return Promise.resolve(this.sessions);
    }

    clearSessions(): Promise<any> {
        this.sessions = [];
        console.log(`Clearing all current sessions`);
        return Promise.resolve('All sessions cleared');
    }

    login(code: string, redirectUri: string, sessionId: string): Promise<Session> {
        console.log(`Logging in`);
        const newSession: Session = {
            id: sessionId
        };
        return this.createSession(newSession).then((session: Session) => {
            console.log(`Getting AUC9 Token`);
            return this.getAUC9Token(code, redirectUri, sessionId).then((token: OAuthToken) => {
                if (!_.isEmpty(session)) {
                    session.token = token;
                    session.user = token.user;
                } else {
                    throw new NotFoundAPIError(`Session with Id: ${sessionId} does'nt exist`);
                }
                console.log(`Getting AUC9 Token done`);
                return {
                    id: sessionId,
                    state: session.state,
                    user: session.user
                };
            });
        });
    }

    refreshSessionToken(sessionId: string): Promise<Session> {
        console.log(`Refreshing session ${sessionId} Token` );
        const session: Session = _.find(this.sessions, {id: sessionId});
        if (!_.isEmpty(session)) {
            return this.refreshAUC9Token(session).then((token: OAuthToken) => {
                console.log(`Refreshing session ${sessionId} Token done`);
                session.token = token;
                return {id: sessionId};
            });
        } else {
            throw new NotFoundAPIError(`Session with Id: ${sessionId}, not found`);
        }
    }

    revokeSessionToken(sessionId: string): Promise<Session> {
        console.log(`Revoking session  ${sessionId} Token`);
        const session: Session = _.find(this.sessions, {id: sessionId});
        if (!_.isEmpty(session)) {
            return this.revokeAUC9Token(session).then((token: OAuthToken) => {
                console.log(`Revoking session ${sessionId} Token done`);
                return {id: sessionId};
            });
        } else {
            console.log(`Revoking session ${sessionId} Token done`);
            return Promise.resolve({id: sessionId});
        }
    }

    logout(sessionId: string): Promise<string> {
        console.log(`Loggin out session ${sessionId}`);
        return this.revokeSessionToken(sessionId).then((session: Session) => {
            _.remove(this.sessions, {id: session.id});
            console.log(`Loggin out session ${sessionId} done`);
            return `Session ${sessionId} logged out`;
        });
    }

    getUserSession(sessionId: string): Promise<User> {
        const session: Session = _.find(this.sessions, {id: sessionId});
        console.log(`Getting user session ${sessionId}`);
        if (!_.isEmpty(session)) {
            console.log(`Getting user session ${sessionId} done`);
            return Promise.resolve(session.user);
        } else {
            throw new NotFoundAPIError(`User with session: ${sessionId}, not found`);
        }
    }

    getSession(sessionId: string): Session {
        return _.find(this.sessions, {id: sessionId});
    }

    getApplicationAuthorizationToken(): Promise<string> {
        const clientID = configuration.get('security.clientID');
        const clientSecret = configuration.get('security.clientSecret');

        return Buffer.from(`${clientID}:${clientSecret}`).toString('base64');
    }

    private createSession(newSession: Session):  Promise<Session> {
        console.log(`Creating new session ${newSession.id}`);
        let session: Session = _.find(this.sessions, {id: newSession.id});
        if (!_.isEmpty(session)) {
            session = newSession;
            console.log(`Creating new session ${newSession.id} done`);
            return Promise.resolve(session);
        } else {
            this.sessions.push(newSession);
            console.log(`Creating new session ${newSession.id} done`);
            return Promise.resolve(newSession);
        }
    }

    private getAUC9Token(code: string, redirectUri: string, sessionId: string): Promise<OAuthToken> {
        console.log(`Calling AUC9 openid token`);
        const options = {
            form: {
                grant_type: 'authorization_code',
                scope: 'openid functionnal_posts',
                code: code,
                redirect_uri: redirectUri
            },
            headers: {
                Authorization: `Basic ${this.getApplicationAuthorizationToken()}`,
                correlationId: sessionId,
                cats_consommateur: configuration.get('security.catsConsommateur'),
                cats_consommateurorigine: configuration.get('security.catsConsommateurorigine'),
                cats_canal: configuration.get('security.catsCanal'),
                'content-type': 'application/x-www-form-urlencoded',
            },
            json: true,
            method: 'POST',
            uri: Constants.URLS.MS.AUC9 + '/openid/token'
        };

        return rp(options).then((response: any) => {
            console.log(`Calling AUC9 openid token done`);
            const token: OAuthToken = {
                access_token: response['access_token'],
                expirationDate: moment().add(response['expires_in'], 'seconds').valueOf(),
                type: response['token_type'],
                id_token: response['id_token'],
                refresh_token: response['refresh_token'],
                user: this.getUserFromToken(response['id_token'])
            };
            return token;
        });
    }

    private refreshAUC9Token(session: Session): Promise<OAuthToken> {
        console.log(`Calling AUC9 openid refresh token`);
        const options = {
            form: {
                grant_type: 'refresh_token',
                scope: 'openid functional_posts',
                refresh_token: session.token.refresh_token
            },
            headers: {
                Authorization: `Basic ${this.getApplicationAuthorizationToken()}`,
                correlationId: session.id,
                cats_consommateur: configuration.get('security.catsConsommateur'),
                cats_consommateurorigine: configuration.get('security.catsConsommateurorigine'),
                cats_canal: configuration.get('security.catsCanal'),
                'content-type': 'application/x-www-form-urlencoded',
            },
            json: true,
            method: 'POST',
            uri: Constants.URLS.MS.AUC9 + '/openid/token'
        };

        return rp(options).then((response: any) => {
            console.log(`Calling AUC9 openid refresh token done`);
            const token: OAuthToken = {
                access_token: response['access_token'],
                expirationDate: moment().add(response['expires_in'], 'seconds').valueOf(),
                type: response['token_type'],
                id_token: response['id_token'],
                refresh_token: session.token.refresh_token,
                user: session.token.user
            };
            return token;
        });
    }

    private revokeAUC9Token(session: Session): Promise<string> {
        console.log(`Calling AUC9 openid revoke token`);
        const options = {
            form: {
                token: session.token.refresh_token
            },
            headers: {
                Authorization: `Basic ${this.getApplicationAuthorizationToken()}`,
                correlationId: session.id,
                cats_consommateur: configuration.get('security.catsConsommateur'),
                cats_consommateurorigine: configuration.get('security.catsConsommateurorigine'),
                cats_canal: configuration.get('security.catsCanal'),
                'content-type': 'application/x-www-form-urlencoded',
            },
            json: true,
            method: 'POST',
            uri: Constants.URLS.MS.AUC9 + '/openid/revoke'
        };

        return rp(options).then((response: any) => {
            console.log(`Calling AUC9 openid revoke token done`);
            return 'revoked';
        });
    }

    private getUserFromToken(idToken: string): User {
        const base64Token: string = _.split(idToken, '.')[1];
        const tokenId: any = new Buffer(base64Token, 'base64').toString('ascii');
        const user: User = {
            id: JSON.parse(tokenId)['sub']
        };
        return user;
    }
 }
