import * as _ from 'lodash';

/**
 * Permet de parser la requête pour récupérer les query params
 * @param path Le chemin de la requête
 */
export const getPathInfos = (searchPath) => {
    const queryParamsMap = {};
    if (!_.isEmpty(searchPath)) {
        const pathSplit = searchPath.split('?');
        const queryString = pathSplit.length === 1 ? '' : pathSplit.pop();

        if (!_.isEmpty(queryString)) {
            // Parse query string
            const params = queryString.split('&');
            params.forEach((param) => {
                const paramObject = param.split('=');
                queryParamsMap[paramObject[0]] = paramObject[1];
            });
        }
    }
    return queryParamsMap;

};

/**
 * Permet la sauvegarde de la page demandée par l'utilisateur dans le sessionStorage
 * @param redirectTo La page demandée
 */
export const storeRedirectTo = (redirectTo) => {
    sessionStorage.setItem('redirectTo', redirectTo); // NOSONAR
};

/**
 * Permet la supression de la page demandée par l'utilisateur dans le sessionStorage
 */
export const removeRedirectTo = () => {
    sessionStorage.removeItem('redirectTo'); // NOSONAR
};

/**
 * Récupération de la page initialement demandée par l'utilisateur dans le sessionStorage
 */
export const getRedirectTo = () => {
    return _.isNull(sessionStorage.getItem('redirectTo')) ? null : sessionStorage.getItem('redirectTo'); // NOSONAR
};