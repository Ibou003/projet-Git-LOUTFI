import { Provider } from "inversify-react";
import React from 'react';
import 'react-app-polyfill/stable';
import ReactDOM from 'react-dom';
import { Provider as ReactReduxProvider } from 'react-redux';
import { Router } from "react-router-dom";
import Container from './app/components/container/Container';
import history from './app/context/History';
import './index.scss';
import { iocContainer, TYPES } from './ioc/ioc';


// Instantiation du store
const reduxService = iocContainer.get(TYPES.ReduxService);
reduxService.configureStore();
const store = reduxService.getStore();

// Rendu du composant principal de l'application
ReactDOM.render(
    // Injection de l'historique de navigation
    <Router history={history}>
        {/* Injection du store redux */}
        <ReactReduxProvider store={store}>
            {/* Injection des objets inversify */}
            <Provider container={iocContainer}>
                {/* Instantiation containeur principal */}
                <Container />
            </Provider>
        </ReactReduxProvider>
    </Router>,
    document.getElementById('root'));
