import CircularProgress from '@material-ui/core/CircularProgress';
import * as _ from 'lodash';
import React from 'react';
import { connect } from "react-redux";
import { Route, withRouter } from "react-router-dom";
import { iocContainer, TYPES } from '../../../ioc/ioc';
import './PrivateRoute.scss';
import {getPathInfos} from '../../../utils';
import Constants from '../../../const';

/**
 * Classe pour sécurisée les pages nécesaires
 */
class PrivateRoute extends React.Component {
   
    constructor(props) {
        super(props);
        this.authentificationService = iocContainer.get(TYPES.AuthentificationService);
    }

    /**
     * Rendu du composant
     */
    render() {
        // Récupération des paramètres de la requête
        const queryParamsMap = getPathInfos(this.props.history.location.search);

        // Test si on n'a pas de context Id et si la route demandée n'est pas sécurisée
        const noContextNoSecure = !this.props.isSecure && !_.has(queryParamsMap, Constants.ROUTES.PARAMS.ID_CONTEXT);

        // Récupération de la page demandée
        if (!_.isEmpty(this.props.user) || noContextNoSecure) {
            // Si un utilisateur est connecté on affiche le composant principal de la page demandée
            return <Route path={this.props.path} component={this.props.component}/>;
        } else {
            let redirectTo = this.props.history.location.pathname;

            // Si aucun utilisateur n'est connecté
            if (!_.isEmpty(this.props.history.location.search)) {
                redirectTo = `${redirectTo}${this.props.history.location.search}`;
            }

            // Gestion de la connexion avec X Connect
            this.authentificationService.login(redirectTo);

            // On affiche un spinner
            return <div className="loader">
                <div className="preloader">
                    <CircularProgress size={100}/>
                </div>
            </div>;
        }
    }

}
export default withRouter(connect(
    (state) => ({
        user: state.session.user
    }),
    null
)(PrivateRoute));