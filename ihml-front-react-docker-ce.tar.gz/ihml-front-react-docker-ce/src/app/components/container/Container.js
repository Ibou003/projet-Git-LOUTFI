import CircularProgress from '@material-ui/core/CircularProgress';
import AccountCircle from '@material-ui/icons/AccountCircle';
import HomeIcon from '@material-ui/icons/Home';
import SearchIcon from '@material-ui/icons/Search';
import classNames from 'classnames';
import * as _ from 'lodash';
import React from 'react';
import { connect } from "react-redux";
import { Link, Redirect, Route, Switch, withRouter } from "react-router-dom";
import logo from '../../../assets/images/react.png';
import Constants from '../../../const';
import { iocContainer, TYPES } from '../../../ioc/ioc';
import { setUser } from '../../redux/actions/SessionAction';
import { setTitle } from '../../redux/actions/UiAction';
import { setEnv } from '../../redux/thunks/EnvThunk';
import { getContext } from '../../redux/thunks/ContextThunk';
import Authorize from '../authorize/Authorize';
import ErrorPage from '../error/Error';
import Home from '../home/Home';
import PrivateRoute from '../routes/PrivateRoute';
import SearchAgenceRoot from '../search-agence/root/SearchAgenceRoot';
import './Container.scss';
import { getPathInfos } from '../../../utils';

/**
 * Classe pour la containeur prinicipal de l'application
 */
class Container extends React.Component {

    /**
     * Constructeur
     * @param {} props Les propriétés du composant
     */
    constructor(props) {
        super(props);

        // Injection du service de configuration
        this.configurationService = iocContainer.get(TYPES.ConfigurationService);

        // Injection du service d'authentification
        this.authentificationService = iocContainer.get(TYPES.AuthentificationService);

        // Injection du service de sécurité
        this.securityService = iocContainer.get(TYPES.SecurityService);

        // Initialisation du contexte du composant
        this.state = {
            contextLoaded: false
        };
    }

    /**
     * Appeler quand le composant est affiché dans le DOM
     */
    componentDidMount() {
        // On charge la configuration à l'initialisation de l'application
        this.props.setEnv();
    }

    componentDidUpdate() {
        // Chargement du contexte si on est connecté
        const queryParamMaps = getPathInfos(this.props.history.location.search);
        if (!this.state.contextLoaded && !_.isNull(this.props.user) && _.has(queryParamMaps, Constants.ROUTES.PARAMS.ID_CONTEXT)) {
            this.props.getContext(queryParamMaps[Constants.ROUTES.PARAMS.ID_CONTEXT]);
            this.setState({ contextLoaded: true });
        }
    }

    /**
     * Listener pour le click sur le bouton de déconnexion
     */
    onLogoutButtonActionClicked() {
        // Déconnexion de l'application
        this.authentificationService.logout();
    }

    /**
     * Rendu du contenu du composant
     */
    render() {

        // Définition des styles des liens du menu
        const homeLinkClass = classNames(
            'menu-item',
            {
                'active': this.props.activeMenu === Constants.MENUS.HOME
            }
        );

        const searchAgenceLinkClass = classNames(
            'menu-item',
            {
                'active': this.props.activeMenu === Constants.MENUS.AGENCES
            }
        );

        if (this.props.envLoaded) {
            // Si l'environnement est chargé
            return (
                <div className="app-container">
                    <header>
                        <div className="banner">
                            <div className="logo">
                                <img src={logo} alt="logo" />
                            </div>
                            <div className="title">{this.props.title}</div>
                            {!_.isNull(this.props.user) && <div className="login">
                                <div className="login-user-container">
                                    <AccountCircle className="login-icon connected" />
                                    <div className="login-user">{this.props.user.id}</div>
                                    <div className="login-fpLabel">{this.props.user.fpLabel}</div>
                                    <div className="login-button connected" onClick={() => this.onLogoutButtonActionClicked()}>{Constants.LABELS.ACTIONS.LOGOUT}</div>
                                </div>
                               
                            </div>}
                        </div>
                        <nav>
                            <div className="menu">
                                <Link className={homeLinkClass} to="/home">
                                    <HomeIcon className='menu-item-icon' />
                                    <span className="menu-item-label">Accueil</span>
                                </Link>
                                <Link className={searchAgenceLinkClass} to="/agences">
                                    <SearchIcon className='menu-item-icon' />
                                    <span className="menu-item-label">Trouver une agence</span>
                                </Link>
                            </div>
                        </nav>
                    </header>
                    <div className="app-content">
                        <Switch>
                            <Route path="/authorize" component={Authorize} />
                            <Route path="/error" component={ErrorPage} />
                            <PrivateRoute path="/home" component={Home} isSecure={false} />
                            <PrivateRoute path="/agences" component={SearchAgenceRoot} isSecure={true} />
                            <Redirect from="*" to="/home" />
                        </Switch>
                    </div>
                    <footer className="footer">
                        <div className="footer-content">
                            <div>Front: {this.props.manifest.front.version}</div>
                            <div>Back For Front: {this.props.manifest.bff.version}</div>
                        </div>
                    </footer>
                </div>

            );
        } else {
            // Si l'environnement n'est pas chargé on affiche un spinner
            return <div className="loader">
                <div className="preloader">
                    <CircularProgress size={100} />
                </div>
            </div>;
        }
    }
}

// Déclaration du composant avec les fonctions de Redux
export default withRouter(connect(
    (state) => ({
        envLoaded: state.ui.envLoaded,
        title: state.ui.title,
        activeMenu: state.ui.activeMenu,
        user: state.session.user,
        manifest: state.manifest
    }),
    {
        setEnv,
        setTitle,
        setUser,
        getContext
    }
)(Container));
