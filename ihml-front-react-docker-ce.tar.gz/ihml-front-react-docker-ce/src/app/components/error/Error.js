import * as _ from 'lodash';
import React from 'react';
import { connect } from "react-redux";
import { Link, withRouter } from "react-router-dom";
import Constants from '../../../const';
import { iocContainer, TYPES } from '../../../ioc/ioc';
import './Error.scss';

/**
 * Classe pour le composant de la page d'erreur
 */
class ErrorPage extends React.Component {

    /**
     * Constructeur du composant
     * @param {*} props Les propriétés initiales
     */
    constructor(props) {
        super(props);

        // Injection du service d'authentification
        this.authentificationService = iocContainer.get(TYPES.AuthentificationService);

        // Binding des listeners
        this.onErrorActionClick = this.onErrorActionClick.bind(this);
    }

    // Listeners
    onErrorActionClick() {
        switch (this.props.lastError.errorAction.action) {
            case Constants.ENUM.ACTIONS.DECONNEXION:
                this.authentificationService.logout();
                break;
            default:
                break;
        }
    }

    /**
     * Rendu des détails de l'erreur
     */
    renderErrorDetails() {
        const errorDetails = [];
        _.each(this.props.lastError.details, (value, key) => {
            if (!_.isNull(value)) {
                errorDetails.push(<span key={key}>
                    <b>{key}:</b> {value}
                </span>);
            }
        });

        return errorDetails;
    }

    /**
     * Rendu du composant
     */
    render() {
        return <div className="error-container">
            <h1>Oups...Désolé</h1>
            Une erreure est intervenue lors de votre dernière requête
            {!_.isNull(this.props.lastError) && <div className="error-content">
                <div className="error-message-content">
                    <h3>Opération</h3>
                    <div>{this.props.lastError.operation}</div>
                </div>
                <div className="error-detail-content">
                    <div className="error-detail-result">
                        <h3>Erreur</h3>
                        <div>{this.props.lastError.errorMessage}</div>
                    </div>
                    <div className="error-detail-operation">
                        <h3>Détails</h3>
                        <div>
                            {this.renderErrorDetails()}
                        </div>
                    </div>
                </div>
            </div>}
            <div className="error-link-content">
                {
                    (!_.isEmpty(this.props.lastError) && !_.isEmpty(this.props.lastError.errorAction)) &&
                    <Link onClick={this.onErrorActionClick}>{this.props.lastError.errorAction.label}</Link>
                }
                {
                    (!_.isEmpty(this.props.lastError) && !_.isEmpty(this.props.lastError.link)) &&
                    <Link to={this.props.lastError.link.root}>Retour</Link>
                }
                {
                    (_.isEmpty(this.props.lastError) || (_.isEmpty(this.props.lastError.link) && _.isEmpty(this.props.lastError.errorAction))) &&
                    <Link to="/home">Accueil</Link>
                }
            </div>
        </div>;
    }
}

// Déclaration du composant avec les fonctions de Redux
export default withRouter(connect(
    (state) => ({
        lastError: state.ui.lastError
    }),
    null
)(ErrorPage));