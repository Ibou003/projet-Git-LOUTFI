import { Link } from '@material-ui/core';
import classNames from 'classnames';
import * as _ from 'lodash';
import React from 'react';
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import Constants from '../../../../const';
import { iocContainer, TYPES } from '../../../../ioc/ioc';
import { setCrsList, setDistributionEntitiesList, setEntitiesList, setSelectedCr, setSelectedDistributionEntityById, setSelectedEntityByZipCode } from '../../../redux/actions/PlacesAction';
import { setActiveMenu } from '../../../redux/actions/UiAction';
import { getCRAgencesList, getCREntities, getCRList } from '../../../redux/thunks/PlacesThunk';
import ListeAgence from '../liste-agence/ListeAgence';
import './SearchAgenceRoot.scss';
import { setContext } from '../../../redux/actions/ContextAction';
/**
 * Classe pour le composant de la page des agences
 */
class SearchAgenceRoot extends React.Component {

    /**
     * Constructeur du composant
     * @param {*} props Les propriétés initiales
     */
    constructor(props) {
        super(props);

        // Injection du service Configuration
        this.configurationService = iocContainer.get(TYPES.ConfigurationService);

        // Injection du service Places
        this.placesService = iocContainer.get(TYPES.PlacesService);

        // Injection du service Context
        this.contextService = iocContainer.get(TYPES.ContextService);

        // Binding des listeners
        this.onCRChange = this.onCRChange.bind(this);
        this.onEntityChange = this.onEntityChange.bind(this);
        this.onOpenAngularApplication = this.onOpenAngularApplication.bind(this);

        this.state = {
            context: {
                crSelected: false,
                entitySelected: false
            }
        };
    }

    /**
     * Appelé une fois le composant affiché dans le DOM
     */
    componentDidMount() {
        this.props.setActiveMenu(Constants.MENUS.AGENCES);

        // Récupération de la liste des agences
        this.props.getCRList();
    }

    componentDidUpdate() {
        // Selection de la cr par contexte
        if (!_.isEmpty(this.props.crs) && !_.isNull(this.props.context.regional_bank_id) && !this.state.context.crSelected) {
            this.props.getCREntities(this.props.context.regional_bank_id);
            this.props.setSelectedCr(this.props.context.regional_bank_id);
            
            // Mise à jour du state - la cr a été séléctionnée par le contexte
            const context = {
                crSelected: true,
                entitySelected: false
            };

            this.setState({context});

        }

        // Selection de la ville par contexte
        if (!_.isEmpty(this.props.entities) && !_.isNull(this.props.context.zip_code) && !this.state.context.entitySelected) {
            this.props.getCRAgencesList(this.props.context.regional_bank_id, this.props.context.zip_code);
            this.props.setSelectedEntityByZipCode(this.props.context.zip_code);
            
            // Mise à jour du state - la ville a été séléctionnée par le contexte
            const context = {
                crSelected: true,
                entitySelected: true
            };

            this.setState({context});

            // Reset du context une fois celui-ci chargé
            this.props.setContext({regional_bank_id: null, zip_code: null});
        }
    }

    /**
     * Méthode pour le rendu de la combo box des CR
     */
    renderCRSSelectOptions() {
        const options = [];
        _.each(this.props.crs, cr => {
            options.push(<option value={cr.regional_bank_id} key={cr.regional_bank_id}>{cr.regional_bank_name.toLowerCase()}</option>);
        });

        return options;
    }

    /**
     * Méthode pour le rendu de la com box des villes d'une CR
     */
    renderEntitiesSelectOptions() {
        const options = [];
        _.each(this.props.entities, (entity, index) => {
            options.push(<option value={entity.zip_code} key={index}>{entity.city_name.toLowerCase()} - {entity.zip_code.toLowerCase()}</option>);
        });

        return options;
    }


    /**
     * Listener pour la selection de la CR
     * @param {*} event Evènement de selection de la combo box
     */
    onCRChange(event) {
        this.props.setEntitiesList([]);
        this.props.setDistributionEntitiesList([]);
        this.props.setSelectedEntityByZipCode(null);
        this.props.setSelectedDistributionEntityById(null);

        this.props.setSelectedCr(event.target.value);

        // Récupération de la liste des villes de la CR
        if (event.target.value !== '') {
            this.props.getCREntities(event.target.value);
        }
    }

    /**
     * Listener pour la sélection de la ville de la CR
     * @param {*} event Evènement de selection de la combo box
     */
    onEntityChange(event) {
        this.props.setDistributionEntitiesList([]);
        this.props.setSelectedDistributionEntityById(null);

        this.props.setSelectedEntityByZipCode(event.target.value);

        // Récupération de la liste des agences
        if (event.target.value !== '') {
            this.props.getCRAgencesList(this.props.selectedCR.regional_bank_id, event.target.value);
        }
    }

    /**
     * Listener pour ouvrir l'application Angular avec un context
     */
    onOpenAngularApplication() {
        const context = {
            client_id: this.configurationService.get(Constants.APPLICATION.CONFIGURATION.ANGULAR_CLIENT_ID),
            regional_bank_id: this.props.selectedCR.regional_bank_id,
            zip_code: this.props.selectedEntity.zip_code
        };

        // sauvegarde du context puis on ouvre l'application angular
        this.contextService.setContext(context).then((context) => {
            const angularUrl = `${this.configurationService.get(Constants.APPLICATION.CONFIGURATION.ANGULAR_URL)}/${Constants.ROUTES.ANUGLAR.AGENCES}`;
            window.open(`${angularUrl}?idCtx=${context.context_id}`);
        });
    }

    /**
     * Rendu du composant
     */
    render() {

        const onOpenAngularLink = classNames(
            'search-agences-open-angular-link',
            {
                'disabled': _.isNull(this.props.selectedEntity)
            }
        );

        // Déinition des valeurs par défaut des CR et Ville sélectionné (par contexte normalement)
        const defaultValueCR = !_.isNull(this.props.selectedCR) ? this.props.selectedCR.regional_bank_id : '';
        const defaultValueEntiity = !_.isNull(this.props.selectedEntity) ? this.props.selectedEntity.zip_code : '';
        return (
            <div className="search-agences-container">
                <nav className="menu">
                    <h3>Trouver une agence</h3>
                    <div className="input-container">
                        <h5>Caisses Régionales</h5>
                        <select onChange={this.onCRChange} value = {defaultValueCR}>
                            <option value="">Selectionner votre caisse</option>
                            {this.renderCRSSelectOptions()}
                        </select>
                    </div>

                    <div className="input-container">
                        <h5>Ville</h5>
                        <select onChange={this.onEntityChange} disabled={_.isNull(this.props.selectedCR)} value = {defaultValueEntiity}>
                            <option value="">Selectionner votre ville</option>
                            {this.renderEntitiesSelectOptions()}
                        </select>
                    </div>

                    <Link className={onOpenAngularLink} onClick={this.onOpenAngularApplication} >Ouvrir application Angular</Link>
                </nav>
                <div className="search-agences-content">
                    <h3>Liste des agences de votre ville</h3>
                    {_.isNull(this.props.selectedCR) &&
                        <div className="welcome-message">Veuillez selectionner une caisse régionale</div>
                    }
                    {!_.isNull(this.props.selectedCR) && _.isNull(this.props.selectedEntity) &&
                        <div className="welcome-message">Veuillez selectionner une ville</div>
                    }
                    {this.props.distributionEntities.length > 0 &&
                        <div className="search-agences-content-container">
                            <ListeAgence />
                        </div>
                    }
                    {this.props.distributionEntities.length === 0 && !_.isNull(this.props.selectedCR) && !_.isNull(this.props.selectedEntity) &&
                        <div className="search-agences-content-container">
                            Aucune agence trouvée pour cette ville
                        </div>
                    }

                </div>
            </div>
        );
    }
}

export default withRouter(connect(
    (state) => ({
        crs: state.places.crs,
        entities: state.places.entities,
        distributionEntities: state.places.distributionEntities,
        selectedCR: state.places.selectedCR,
        selectedEntity: state.places.selectedEntity,
        selectedDistributionEntity: state.places.selectedDistributionEntity,
        context: state.context
    }),
    {
        setActiveMenu,
        getCRList,
        getCREntities,
        getCRAgencesList,
        setEntitiesList,
        setCrsList,
        setDistributionEntitiesList,
        setSelectedCr,
        setSelectedEntityByZipCode,
        setSelectedDistributionEntityById,
        setContext
    }
)(SearchAgenceRoot));