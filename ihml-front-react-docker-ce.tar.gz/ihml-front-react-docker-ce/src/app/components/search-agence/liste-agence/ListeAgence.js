import Accessible from '@material-ui/icons/Accessible';
import CreditCard from '@material-ui/icons/CreditCard';
import LocalAtm from '@material-ui/icons/LocalAtm';
import LocalParking from '@material-ui/icons/LocalParking';
import classNames from 'classnames';
import L from 'leaflet';
import * as _ from 'lodash';
import React from 'react';
import { Map, Marker, TileLayer } from 'react-leaflet';
import { connect } from "react-redux";
import '../../../../../node_modules/leaflet/dist/leaflet.css';
import Constants from '../../../../const';
import { setSelectedDistributionEntityById } from '../../../redux/actions/PlacesAction';
import './ListeAgence.scss';

/**
 * Définition de l'objet pour les markers sur la map
 */
export const pinIconDefault = new L.Icon({
    iconRetinaUrl: require('../../../../assets/marker-icon-2x.png'),
    iconUrl: require('../../../../assets/marker-icon-2x.png'),
    shadowUrl: require('../../../../assets/marker-shadow.png'),
    iconSize: [40, 41],
    iconAnchor: [20, 41],
    shadowAnchor: [12, 41],
    popupAnchor: [1, -34],
    tooltipAnchor: [16, -28],
    shadowSize: [41, 41]
});

/**
 * Définition de l'objet pour le markers séléctionné sur la map
 */
export const pinSelectedDefault = new L.Icon({
    iconRetinaUrl: require('../../../../assets/marker-icon-2x-selected.png'),
    iconUrl: require('../../../../assets/marker-icon-2x-selected.png'),
    shadowUrl: require('../../../../assets/marker-shadow.png'),
    iconSize: [40, 41],
    iconAnchor: [20, 41],
    shadowAnchor: [12, 41],
    popupAnchor: [1, -34],
    tooltipAnchor: [16, -28],
    shadowSize: [41, 41]
});

/**
 * Classe pour le composant d'affichage des détails d'une agence
 */
class ListeAgence extends React.Component {

    /**
     * Constructeur du composant
     * @param {} props 
     */
    constructor(props) {
        super(props);

        // Binding des listeners
        this.onMarkerClick = this.onMarkerClick.bind(this);
    }

    componentDidMount() {
        // Selection de la première agences
        this.props.setSelectedDistributionEntityById(this.props.distributionEntities[0].id);
    }

    /**
     * Méthod pour le rendu de la liste des agences
     */
    renderListAgenceItem() {
        const entities = [];

        _.each(this.props.distributionEntities, distributionEntity => {

            // Style pour les items de la liste des agences
            const listAgenceItemClass = classNames(
                'liste-agences-item',
                {
                    'selected': !_.isNull(this.props.selectedDistributionEntity) && this.props.selectedDistributionEntity.id === distributionEntity.id
                }
            );

            // Création de chaque item de la liste
            entities.push(
                <div className={listAgenceItemClass} key={distributionEntity.id} onClick={() => this.onEntitySelected(distributionEntity)}>
                    <div className="liste-agences-item-name">
                        {distributionEntity.name.toLowerCase()}
                    </div>
                    <div className="liste-agences-item-adresse">
                        <div className="liste-agences-item-adresse-street">{distributionEntity.address.address.toLowerCase()}</div>
                        <div className="liste-agences-item-adresse-city">{distributionEntity.address.zip_code} - {distributionEntity.address.city_name}</div>
                    </div>
                </div>
            );
        });
        return entities;
    }

    /**
     * Méthode pour le rendu des heures d'ouvertures de l'agence séléctionnée
     */
    renderOpenHours() {
        const openHours = [];

        _.each(Constants.WEEK_DAYS, dayOfWeek => {
            const dayOfWeekNumber = `${new Date().getDay()}`;
            const openHoursClass = classNames(
                'liste-agences-item-detail-openhours',
                {
                    'today': dayOfWeek.day_of_week === dayOfWeekNumber
                }
            );
            openHours.push(
                <div className={openHoursClass} key={dayOfWeek.day_of_week}>
                    <span className="label">{dayOfWeek.label}</span>
                    <span className="separator"></span>
                    <span className="input">{this.getOpeningHours(dayOfWeek.day_of_week)}</span>
                </div>
            );
        });

        return openHours;
    }

    /**
     * Méthode pour le rendu de chaque jour d'ouverture
     * @param {*} dayOfWeek Jour de la semaine
     */
    getOpeningHours(dayOfWeek) {

        const dayOfWeekInfo = _.find(this.props.selectedDistributionEntity.week_schedule, { day_of_week: dayOfWeek });

        let openingHours = '';
        if (!_.isEmpty(dayOfWeekInfo)) {

            if (_.isNull(dayOfWeekInfo.opening_hours[0].opening)) {
                return 'Fermé';
            }

            // ajout de la date d'ouverture du matin
            openingHours = `${dayOfWeekInfo.opening_hours[0].opening.substr(0, 5).replace(':', 'h')}`;

            if (_.isNull(dayOfWeekInfo.opening_hours[1].opening)) {
                // Cas ouverture non-stop
                if (!_.isNull(dayOfWeekInfo.opening_hours[0].closing)) {
                    openingHours = `${openingHours}-${dayOfWeekInfo.opening_hours[0].closing.substr(0, 5).replace(':', 'h')}`;
                }

            } else {

                if (!_.isNull(dayOfWeekInfo.opening_hours[0].closing)) {
                    openingHours = `${openingHours}-${dayOfWeekInfo.opening_hours[0].closing.substr(0, 5).replace(':', 'h')}`;
                }

                if (!_.isNull(dayOfWeekInfo.opening_hours[1].opening)) {
                    // Cas ouverture après midi
                    openingHours = `${openingHours} ${dayOfWeekInfo.opening_hours[1].opening.substr(0, 5).replace(':', 'h')}`;

                    if (!_.isNull(dayOfWeekInfo.opening_hours[1].closing)) {
                        openingHours = `${openingHours}-${dayOfWeekInfo.opening_hours[1].closing.substr(0, 5).replace(':', 'h')}`;
                    }
                }
            }
        }
        return openingHours;
    }

    /**
     * Listener pour la choix de l'agence sélectionnée
     * @param {} distributionEntity 
     */
    onEntitySelected(distributionEntity) {
        this.props.setSelectedDistributionEntityById(distributionEntity.id);

        if (!_.isEmpty(this.map)) {
            this.map.setView([distributionEntity, distributionEntity], this.map.getZoom());
        }
    }

    /**
     * Méthode pour l'ajout des marqueurs sur la carte pour chaque agence
     */
    addMarkers() {
        const markers = [];
        _.each(this.props.distributionEntities, (distributionEntity) => {
            const position = [distributionEntity.coordinates.latitude, distributionEntity.coordinates.longitude];
            const icon = distributionEntity.id === this.props.selectedDistributionEntity.id ? pinSelectedDefault : pinIconDefault;
            markers.push(<Marker position={position} icon={icon} key={distributionEntity.id} onClick={() => { this.onMarkerClick(distributionEntity) ;}} />);
        });

        return markers;
    }

    /**
     * Listener pour la sélection d'un marqueur
     * @param {*} distributionEntity 
     */
    onMarkerClick(distributionEntity) {
        this.setState({ selectedEntity: distributionEntity });
    }

    /**
     * Rendu du composant
     */
    render() {
        // Défintion du style pour les différents services de l'agence
        const atmClass = classNames(
            'service-item-icon',
            {
                'disable': !_.isNull(this.props.selectedDistributionEntity) && !this.props.selectedDistributionEntity.services.atm
            }
        );

        const accessibleClass = classNames(
            'service-item-icon',
            {
                'disable': !_.isNull(this.props.selectedDistributionEntity) && !this.props.selectedDistributionEntity.services.wheel_chair_access
            }
        );

        const carParkClass = classNames(
            'service-item-icon',
            {
                'disable': !_.isNull(this.props.selectedDistributionEntity) && !this.props.selectedDistributionEntity.services.car_park
            }
        );

        const exchangeCurrencyClass = classNames(
            'service-item-icon',
            {
                'disable': this.props.selectedDistributionEntity && !this.props.selectedDistributionEntity.services.exchange_currency
            }
        );

        // Définition de la position par défaut de la carte
        let position = [51.505, -0.09];

        // Définition de la position de l'agence séléctionnée
        if (!_.isNull(this.props.selectedDistributionEntity)) {
            position = [this.props.selectedDistributionEntity.coordinates.latitude, this.props.selectedDistributionEntity.coordinates.longitude];
        }

        return (
            <div className="liste-agences-container">
                <div className="liste-agences-content">
                    <div className="liste-agences-items">
                        {this.renderListAgenceItem()}
                    </div>
                    {!_.isNull(this.props.selectedDistributionEntity) &&
                        <div className="liste-agences-item-detail">
                            <div className="liste-agences-item-detail-container">
                                <div className="liste-agences-item-detail-name">{this.props.selectedDistributionEntity.name.toLowerCase()}</div>
                                <div className="liste-agences-item-detail-infos">
                                    <div className="liste-agences-item-detail-infos-contact">
                                        <h5>CONTACT :</h5>
                                        <div className="liste-agences-item-detail-adresse">
                                            <div className="liste-agences-item-detail-adresse-street">{this.props.selectedDistributionEntity.address.address.toLowerCase()}</div>
                                            <div className="liste-agences-item-detail-adresse-city">{this.props.selectedDistributionEntity.address.zip_code} - {this.props.selectedDistributionEntity.address.city_name}</div>
                                        </div>
                                        <div className="liste-agences-item-detail-phone">
                                            <span className="label">Tel: </span>
                                            <span className="input">{this.props.selectedDistributionEntity.contact.phone_number}</span>
                                        </div>
                                        <div className="liste-agences-item-detail-fax">
                                            <span className="label">Fax: </span>
                                            <span className="input">{this.props.selectedDistributionEntity.contact.fax}</span>
                                        </div>
                                        <div className="liste-agences-item-detail-mail">
                                            <span className="label">Email: </span>
                                            <span className="input">{this.props.selectedDistributionEntity.contact.email_address}</span>
                                        </div>
                                    </div>
                                    <div className="liste-agences-item-detail-infos-openhours">
                                        <h5>OUVERTURE :</h5>
                                        {this.renderOpenHours()}
                                    </div>
                                    <div className="liste-agences-item-detail-infos-services">
                                        <h5>SERVICES :</h5>
                                        <div className="liste-agences-item-detail-services">
                                            <CreditCard className={atmClass} title="Distributeur de billets" />
                                            <Accessible className={accessibleClass} title="Accès personne à mobilité réduite" />
                                            <LocalParking className={carParkClass} title="Parking" />
                                            <LocalAtm className={exchangeCurrencyClass} title="Echange de monnaies" />
                                        </div>
                                    </div>
                                </div>
                                <div className="liste-agences-item-detail-map">
                                    <Map center={position} zoom={15}>
                                        <TileLayer
                                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                            attribution="&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors"
                                        />
                                        {this.addMarkers()}
                                    </Map>
                                </div>
                            </div>
                        </div>}
                </div>
            </div>
        );
    }
}

export default connect(
    (state) => ({
        distributionEntities: state.places.distributionEntities,
        selectedDistributionEntity: state.places.selectedDistributionEntity
    }),
    {
        setSelectedDistributionEntityById
    }
)(ListeAgence);