import React from 'react';
import { connect } from "react-redux";
import Constants from '../../../const';
import { setActiveMenu } from '../../redux/actions/UiAction';
import './Home.scss';

/**
 * Classe pour le composant de la page d'accueil
 */
class Home extends React.Component {

    /**
     * Appelé une fois le composant affiché dans le DOM
     */
    componentDidMount() {
        this.props.setActiveMenu(Constants.MENUS.HOME);
    }

    /**
     * Rendu du composant
     */
    render() {
        return (
            <div className="home-container">
                <h3>Bienvenu sur l'application de demonstration de la filière IHM Light - React</h3>
                <div className="home-content">
                    Cette application à pour but de demontrer la mise en oeuvre des différents patterns de la filière IHM Light.
                    <ul>
                        <li>Gestion de la connexion à une application client ou collaborateur</li>
                        <li>Gestion de la déconnexion à une application client ou collaborateur</li>
                        <li>Persistance de session</li>
                        <li>Appel d'API</li>
                        <li>Transfert de contexte</li>
                    </ul>

                    Cette application est développée en <b>React</b>.
                    <br></br>
                    Le Back For Front est développé en <b>{this.props.manifest.bff.framework}</b>
                </div>
            </div>
        );
    }
}

export default connect(
    (state) => ({
        manifest: state.manifest
    }),
    {
        setActiveMenu
    }
)(Home);