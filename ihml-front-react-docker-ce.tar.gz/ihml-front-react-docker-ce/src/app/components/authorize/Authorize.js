import CircularProgress from '@material-ui/core/CircularProgress';
import * as _ from 'lodash';
import React from 'react';
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { iocContainer, TYPES } from '../../../ioc/ioc';
import history from '../../context/History';
import { getUser } from '../../redux/thunks/SessionThunk';
import './Authorize.scss';
import { getRedirectTo, removeRedirectTo} from '../../../utils';

/**
 * Classe pour définir le composant de la page authorize
 */
class Authorize extends React.Component {

    /**
     * Constructeur du composant
     * @param {*} props Les propriétés initiales du composant
     */
    constructor(props) {
        super(props);

        // Injection du service d'authentification
        this.authentificationService = iocContainer.get(TYPES.AuthentificationService);
    }

    /**
     * Appelé une fois le composant affiché dans le DOM
     */
    componentDidMount() {
        this.authentificationService.handleAuth().then(() => {
            // Une fois connecté on demande les informations sur l'utilisateur
            return this.props.getUser();
        }).then((user) => {
            if (!_.isEmpty(user)) {
                // Si un utilisateur existe on le redirige vers la page initialement demandée.
                // Sinon vers la page d'acceuil
                const redirectTo = getRedirectTo();
                if (!_.isEmpty(redirectTo)) {
                    removeRedirectTo();
                    history.push(redirectTo);
                } else {
                    // Redirection vers la page d'accueil par défaut
                    history.push('/home');
                }
            }
        }).catch(() => {
            // Rédirection vers la page d'erreur
            history.push('/error');
        });;
    }

    /**
     * Rendu du composant
     */
    render() {
        // Le composant ne sert qu'à afficher une spinner
        return <div className="loader">
            <div className="preloader">
                <CircularProgress size={100} />
            </div>
        </div>;
    }
}

export default withRouter(connect(
    null,
    {
        getUser
    }
)(Authorize));