import * as axios from 'axios';
import * as _ from 'lodash';
import Constants from '../../const';
import { iocContainer, TYPES } from '../../ioc/ioc';

/**
 * Classe pour la gestion des API de Sécurité
 */
class SecurityService {

    // Constructeur du service
    constructor() {
        // Injection du service de configuration
        this.configurationService = iocContainer.get(TYPES.ConfigurationService);

        // Injection du service d'erreur
        this.errorService = iocContainer.get(TYPES.ErrorService);
    }

    /**
     * API de connexion
     * @param {*} code AZ Code retourné par X-Connect
     * @param {*} redirect_uri Url de redirection de l'application
     * @param {*} state UUID généré par l'application
     */
    login(code, redirect_uri, state) {
        const httpOperation = {
            operation: Constants.ACTIONS.USER_LOGIN,
            url: `${this.configurationService.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/security/login`,
            method: 'GET',
            headers: {
                'Authorization': code,
                'redirectUrl': redirect_uri,
                'state': state
            }
        };

        const axiosOptions = this._getAxiosOptions(httpOperation);

        // Envoi de la requête de loing au BFF
        return axios(axiosOptions).catch(error => {
            this.errorService.handleApiError(httpOperation, error);
        });
    }

    /**
     * API de déconnexion
     */
    logout() {
        const httpOperation = {
            operation: Constants.ACTIONS.USER_LOGIN,
            url: `${this.configurationService.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/security/logout`,
            method: 'GET'
        };
        const axiosOptions = this._getAxiosOptions(httpOperation);

        // Envoi de la requête de déconnexion au BFF
        return axios(axiosOptions).catch(error => {
            this.errorService.handleApiError(httpOperation, error);
        });
    }

    /**
     * API pour récupérer l'utilisateur connecté
     */
    getUserConnected() {
        const httpOperation = {
            operation: Constants.ACTIONS.USER_LOGIN,
            url: `${this.configurationService.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/security/user`,
            method: 'GET',
            options: {
                accept404: true
            }
        };
        const axiosOptions = this._getAxiosOptions(httpOperation);

        // Envoi de la requête pour récupéré l'utilisateur connecté
        return axios(axiosOptions).then(
            (response) => { return response.data; }
        ).catch((error) => {
            this.errorService.handleApiError(httpOperation, error);
        });
    }

    // Private
    _getAxiosOptions(httpOperation) {
        let options = {
            headers: {},
            responseType: 'json',
            method: httpOperation.method,
            withCredentials: true,
            url: httpOperation.url
        };

        if (!_.isNull(httpOperation.headers)) {
            options.headers = httpOperation.headers;
        }

        if ((httpOperation.method === 'POST' || httpOperation.method === 'PUT') && !_.isUndefined(httpOperation.body)) {
            options['body'] = httpOperation.body;
        }

        return options;
    }
}

export default SecurityService;
