import Constants from "../../const";
import HttpService from "./HttpService";

/**
 * Classe pour définir le service d'appel aux API Manifest
 */
class ManifestService extends HttpService {

    /**
     * Récupération du manifest de l'application
     */
    getManifest() {
        const httpOperation = {
            operation: Constants.ACTIONS.GET_MANIFEST,
            url: `${this.configurationservice.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/manifest`,
            method: 'GET'
        };

        return this.executeRequest(httpOperation).then(manifest => {
            return manifest;
        });
    }
}

export default ManifestService;