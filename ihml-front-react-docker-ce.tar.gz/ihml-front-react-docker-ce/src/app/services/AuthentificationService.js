import * as _ from 'lodash';
import * as uuidv4 from 'uuid/v4';
import Constants from '../../const';
import { iocContainer, TYPES } from '../../ioc/ioc';
import history from '../context/History';
import { storeRedirectTo, getPathInfos } from '../../utils';

/**
 * Classe pour définir le service d'authenfication
 */
class AuthentificationService {

    /**
     * Constructeur du service
     */
    constructor() {
        // Injection du service de configuration
        this.configurationService = iocContainer.get(TYPES.ConfigurationService);

        // Injection du service de sécurité
        this.securityService = iocContainer.get(TYPES.SecurityService);
    }

    /**
     * Gestion de la connexion
     * @param {} redirectTo Url de la page demandée par l'utilisateur
     */
    login(redirectTo) {
        // Sauvegarde dans le localstorage de la page demandée par l'utilisateur
        storeRedirectTo(redirectTo);

        // Génération d'un state pour X Connect et la récupértion du refresh token
        const state = uuidv4();

        // Construction URL pour la redirection vers le mire X Connect
        const queryParams = {
            client_Id: this.configurationService.get(Constants.APPLICATION.CONFIGURATION.CLIENT_ID),
            redirect_uri: this.configurationService.get(Constants.APPLICATION.CONFIGURATION.REDIRECT_URL),
            response_type: 'code',
            scope: 'openid functional_posts',
            state: state
        };

        let queryParamsString = `client_id=${queryParams.client_Id}`;
        queryParamsString = `${queryParamsString}&redirect_uri=${queryParams.redirect_uri}`;
        queryParamsString = `${queryParamsString}&response_type=${queryParams.response_type}`;
        queryParamsString = `${queryParamsString}&scope=${queryParams.scope}`;
        queryParamsString = `${queryParamsString}&state=${queryParams.state}`;

        // Redirection vers la mire X Connect
        const xConnectRootUrl = this.configurationService.get(Constants.APPLICATION.CONFIGURATION.X_CONNECT_URL);
        window.location.assign(`${xConnectRootUrl}/${Constants.ROUTES.X_CONNECT.AUTHORIZE}?${queryParamsString}`);
    }

    /**
     * Gestion du retour de l'auhthentification de la mire X Connect
     */
    handleAuth() {
        // Récupération des paramètres de la requête
        const queryParamsMap = getPathInfos(window.location.search);
        let code = null;
        let state = null;
        if (!_.isEmpty(queryParamsMap)) {
            // Sauvegarde de l'authorization code et du state
            code = queryParamsMap['code'];
            state = queryParamsMap['state'];
        }

        if (!_.isEmpty(code) && !_.isEmpty(state)) {
            // Si on un code et un state on demande la création d'un OAuthToken au BFF
            const redirectUrl = this.configurationService.get(Constants.APPLICATION.CONFIGURATION.REDIRECT_URL);
            return this.securityService.login(code, redirectUrl, state);
        } else {
            // Erreur lors de la connexion à la mire X Connect
            console.log('Authentification impossible');
            history.push('/error');
            return Promise.resolve();
        }
    }

    /**
     * Gestion de la déconnexion
     */
    logout() {
        // Appel de la déconnexion coté BFF pour revoké le refresh token
        this.securityService.logout().finally(
            () => {
                // Redirection vers la mire X Connect pour la déconnexion
                window.location.assign(`${this.configurationService.get(Constants.APPLICATION.CONFIGURATION.X_CONNECT_URL)}/logout`);
            });
    }
}

export default AuthentificationService;