import Constants from "../../const";
import HttpService from "./HttpService";

/**
 * Classe pour définir le service d'appel aux API Context
 */
class ContextService extends HttpService {

    /**
     * Récupération du context de l'application
     */
    getContext(idCtx) {
        const httpOperation = {
            operation: Constants.ACTIONS.GET_CONTEXT,
            url: `${this.configurationservice.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/context/${idCtx}`,
            method: 'GET',
            options: {
                accept404: true
            }
        };

        return this.executeRequest(httpOperation).then(context => {
            return context;
        });
    }

    /**
     * Sauvegarder un contexte d'application
     */
    setContext(context) {
        const httpOperation = {
            operation: Constants.ACTIONS.SAVE_CONTEXT,
            url: `${this.configurationservice.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/context`,
            method: 'POST',
            body: context,
            options: {
                accept404: true
            }
        };

        return this.executeRequest(httpOperation).then(idCtx => {
            return idCtx;
        });
    }
}

export default ContextService;