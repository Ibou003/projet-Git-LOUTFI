import * as axios from 'axios';
import * as _ from 'lodash';
import Constants from "../../const";

/**
 * Classe pour définir le service de configuration
 */
class ConfigurationService {

    /**
     * Constructeur du service
     */
    constructor() {
        // Initialisation de la configuration
        this.configuration = {};
    }

    /**
     * Récupération d'une valeur de la configuration
     * @param {*} key clé de configuration souhaitée
     */
    get(key) {
        return _.has(this.configuration, key) ? this.configuration[key] : null; 
    }
    
    /**
     * Récupération de la configuration
     */
    getConfiguration() {
        const options = {
            headers: {
                "Content-type": "application/json"
            },
            responseType: 'json',
            method: 'GET',
            url: `${Constants.ROUTES.PATHS.ROOT_BUILD}/configuration/app-config-react.json`
        };
        return axios(options).then(response => {
            // Sauvagarde de la configuration
            this.configuration = _.assign({}, this.configuration, response.data);
            return this.configuration;
        });       
    }
}

export default ConfigurationService;