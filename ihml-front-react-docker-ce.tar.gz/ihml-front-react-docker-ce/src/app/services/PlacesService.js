import Constants from "../../const";
import HttpService from "./HttpService";

/**
 * Classe pour définir le service d'appel aux API Places
 */
class PlacesService extends HttpService {

    /**
     * Récupération de la liste des CR
     */
    getCRList() {
        const httpOperation = {
            operation: Constants.ACTIONS.GET_CR_LIST,
            url: `${this.configurationservice.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/places/regional_banks`,
            method: 'GET'
        };
        return this.executeRequest(httpOperation).then(crs => {
            return crs;
        });
    }

    /**
     * Récupération de la liste des villes d'un CR
     * @param {*} crId Id de la CR
     */
    getCREntities(crId) {
        const httpOperation = {
            operation: `${Constants.ACTIONS.GET_CR_ENTITIES_LIST} ${crId}`,
            url: `${this.configurationservice.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/places/regional_banks/${crId}/cities_with_distribution_entities`,
            method: 'GET'
        };
        return this.executeRequest(httpOperation).then(entities => {
            return entities;
        });
    }

    /**
     * Récupération de la liste des agences d'une ville d'une CR
     * @param {*} crId Id de la CR
     * @param {*} zipCode Code postal de la ville
     */
    getCRAgencesList(crId, zipCode) {
        const httpOperation = {
            operation: `${Constants.ACTIONS.GET_CR_CITY_DISTRIBUTION_ENTITIES}: ${crId} - ${zipCode}`,
            url: `${this.configurationservice.get(Constants.APPLICATION.CONFIGURATION.API_BASE_PATH)}/places/distribution_entities/search_by_city/${crId}/${zipCode}`,
            method: 'GET'
        };

        return this.executeRequest(httpOperation).then(distributionEntities => {
            return distributionEntities;
        });
    }
}

export default PlacesService;