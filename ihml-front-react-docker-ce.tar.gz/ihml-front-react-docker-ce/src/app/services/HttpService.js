import * as axios from 'axios';
import * as _ from 'lodash';
import { iocContainer, TYPES } from '../../ioc/ioc';


/**
 * Classe pour définir le service pour l'envoir de requête au BFF
 */
class HttpService {

    /**
     * Constructeur du service
     */
    constructor() {
        // Innjection du service de configuration
        this.configurationservice = iocContainer.get(TYPES.ConfigurationService);

        // Injection du service d'erreur
        this.errorService = iocContainer.get(TYPES.ErrorService);
    }

    /**
     * Execution des requêtes
     * @param {} httpOperation Options de la requête
     */
    executeRequest(httpOperation) {
        let axiosOptions = {
            headers: {},
            responseType: 'json',
            method: httpOperation.method,
            withCredentials: true,
            url: httpOperation.url
        };

        if (!_.isNull(httpOperation.headers)) {
            axiosOptions.headers = httpOperation.headers;
        }

        if ((httpOperation.method === 'POST' || httpOperation.method === 'PUT') && !_.isUndefined(httpOperation.body)) {
            axiosOptions['data'] = httpOperation.body;
        }

        return axios(axiosOptions).then(response => {
            // Retour de la réponse
            return response.data;
        }).catch((error => {
            this.errorService.handleApiError(httpOperation, error);
        }));
    }
}

export default HttpService;