import * as _ from 'lodash';
import Constants from '../../const';
import { iocContainer, TYPES } from '../../ioc/ioc';
import history from '../context/History';
import { setLastError } from '../redux/actions/UiAction';

/**
 * Classe pour définir le service pour l'envoir de requête au BFF
 */
class ErrorService {

    /**
     * Constructeur du service
     */
    constructor() {
        // Injection du service Redux
        this.reduxService = iocContainer.get(TYPES.ReduxService);
    }

    /**
     * Gestion des erreurs Http
     * @param {} httpOperation L'operation Http qui a provoquée l'erreur
     * @param {*} error L'erreur provoquée
     */
    handleApiError(httpOperation, error) {

        let redirectToError = false;

        // Construction du status et du message de l'erreur
        const errorStatus = !_.isEmpty(error.response) ? error.response.data.status || error.response.status : 0;
        const errorMsg = !_.isEmpty(error.response) && !_.isEmpty(error.response.data.message) ? error.response.data.message : error.message;

        // Création de l'objet d'affichage de l'erreur
        const uiError = {
            operation: httpOperation.operation,
            errorMessage: `${errorStatus} - ${errorMsg}`,
            link: {
                root: this.buildRoute()
            },
            details: {
                Url: httpOperation.url,
                Body: !_.isEmpty(httpOperation.body) ? JSON.stringify(httpOperation.body, null, '\t') : null
            }
        };

        switch (errorStatus) {
            case 0:
                // Dans le cas d'une erreur CORS (ou serveur absent)
                uiError.errorMessage = Constants.ERROR_MESSAGES.SERVER_NOT_REACHABLE;
                redirectToError = true;
                break;
            case 404:
                redirectToError = !httpOperation.options.accept404;
                break;
            case 401:
                redirectToError = true;
                uiError.details = {
                    Action: Constants.ACTIONS.REDIRECTION_TO_XCONNECT
                };
                uiError.link = null;
                uiError.errorAction = {
                    action: Constants.ENUM.ACTIONS.DECONNEXION,
                    label: Constants.LABELS.ACTIONS.LOGOUT
                };
                break;
            default:
                redirectToError = true;
        }

        if (redirectToError) {
            this.handleError(uiError);
        }

        throw error;

    }

    /**
     * Gestion de l'affichage de l'erreur
     * @param {*} uiError 
     */
    handleError(uiError) {
        // Mise à jour de l'erreur dans le store
        this.reduxService.dispatch(setLastError(uiError));

        // Rédirection vers la page d'erreur pour l'afficher
        history.push('/error');
    }

    // Construction de la route de redirection après l'erreur
    buildRoute() {
        let root = '';

        const rootUrl = `${Constants.ROUTES.PATHS.ROOT_BUILD}`;
        const urlSplits = window.location.pathname.split('/');

        // Construction chemin de redirection
        _.each(urlSplits, (urlSplit) => {
            const path = `/${urlSplit}`;
            if (!_.isEmpty(urlSplit) && `${path}` !== rootUrl) {
                root = `${root}${path}`;
            }
        });

        // Rajout des search Params s'il y en 
        if (!_.isEmpty(window.location.search)) {
            root = `${root}${window.location.search}`;
        }

        return root;
    }
}

export default ErrorService;