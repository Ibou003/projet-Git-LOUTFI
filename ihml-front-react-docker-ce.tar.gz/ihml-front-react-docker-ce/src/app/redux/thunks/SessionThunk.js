import { iocContainer, TYPES } from '../../../ioc/ioc';
import { setUser } from '../actions/SessionAction';

/**
 * Thunk pour récupérer l'utilisateur connecté
 */
export const getUser = () => {
    return (dispatch) => {
        const securityService = iocContainer.get(TYPES.SecurityService);
        return securityService.getUserConnected().then(
            (user) => {
                dispatch(setUser(user));
                return user;
            }
        );
    } ;
};