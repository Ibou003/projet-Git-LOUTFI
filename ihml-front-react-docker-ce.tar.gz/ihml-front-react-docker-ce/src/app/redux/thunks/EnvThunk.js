import * as _ from 'lodash';
import Constants from '../../../const';
import { iocContainer, TYPES } from '../../../ioc/ioc';
import { setBffManifest, setFrontManifest } from '../actions/ManifestAction';
import { setUser } from '../actions/SessionAction';
import { setEnvloaded, setTitle } from '../actions/UiAction';

/**
 * Thunk pour setter l'environnement de l'application
 */
export const setEnv = () => {
    return (dispatch) => {
        const configurationService = iocContainer.get(TYPES.ConfigurationService);
        const manifestService = iocContainer.get(TYPES.ManifestService);
        const securityService = iocContainer.get(TYPES.SecurityService);
        // On charge la configuration à l'initialisation de l'application
        configurationService.getConfiguration().then(configuration => {
            // Mise à jour du store avec le titre de l'application
            dispatch(setTitle(configuration[Constants.APPLICATION.CONFIGURATION.TITLE]));
            return;
        }).then(() => {
            // Récupération du manifest du Front End
            const packJson = require('../../../../package.json');
            dispatch(setFrontManifest({ version: packJson.version }));
            // Récupération du manifest du bff
            return manifestService.getManifest().then((manifest) => {
                dispatch(setBffManifest(manifest));
            });
        }).then(() => {
            // On demande des informations sur l'utilisateur connecté
            return securityService.getUserConnected().then((user) => {
                dispatch(setUser(user));
            });
        }).catch((error) => {
            if (_.isEmpty(error.response) || error.response.status === 404) {
                dispatch(setUser(null));
            }
        }).finally(() => {
            dispatch(setEnvloaded(true));
        });
    };
};