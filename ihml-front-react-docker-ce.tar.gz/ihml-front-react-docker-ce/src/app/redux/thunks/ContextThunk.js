import { iocContainer, TYPES } from '../../../ioc/ioc';
import { setContext} from '../actions/ContextAction';

/**
 * Thunk pour setter l'environnement de l'application
 */
export const getContext = (idCtx) => {
    return (dispatch) => {
        const contextService = iocContainer.get(TYPES.ContextService);
        // Chargement du context
        return contextService.getContext(idCtx).then((context) => {
            dispatch(setContext(context));
        }).catch((error) => {
            if (error.status === 404) {
                dispatch(setContext({
                    regional_bank_id: null,
                    zip_code: null
                }));
            };
            return Promise.resolve(null);
        });
    };
};