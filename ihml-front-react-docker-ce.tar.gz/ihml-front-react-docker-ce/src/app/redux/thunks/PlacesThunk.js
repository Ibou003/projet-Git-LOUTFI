import { iocContainer, TYPES } from '../../../ioc/ioc';
import { setCrsList, setDistributionEntitiesList, setEntitiesList } from '../actions/PlacesAction';

/**
 * Thunk pour récupérer la liste des CR
 */
export const getCRList = () => {
    return (dispatch) => {
        const placesServices = iocContainer.get(TYPES.PlacesService);
        return placesServices.getCRList().then(
            (crsList) => {
                dispatch(setCrsList(crsList));
                return crsList;
            }
        );
    };
};

/**
 * Thunk pour récupérer la liste des villes d'une CR
 * @param {} crId L'Id de la CR
 */
export const getCREntities = (crId) => {
    return (dispatch) => {
        const placesServices = iocContainer.get(TYPES.PlacesService);
        return placesServices.getCREntities(crId).then(
            (entitiesList) => {
                dispatch(setEntitiesList(entitiesList));
                return entitiesList;
            }
        );
    } ;   
};

/**
 * Thunk pour récupérer la liste des agences d'une ville d'une CR
 * @param {*} crId L'Id de la CR
 * @param {*} zipCode Le code postal de la ville
 */
export const getCRAgencesList = (crId, zipCode) => {
    return (dispatch) => {
        const placesServices = iocContainer.get(TYPES.PlacesService);
        return placesServices.getCRAgencesList(crId, zipCode).then(
            (distributionEntitiesList) => {
                dispatch(setDistributionEntitiesList(distributionEntitiesList));
                return distributionEntitiesList;
            }
        );
    }; 
};