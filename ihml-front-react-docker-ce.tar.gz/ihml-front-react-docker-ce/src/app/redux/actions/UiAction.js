/**
 * Constants pour les actions de UI
 */
export const SET_TITLE = 'SET_TITLE';
export const SET_ACTIVE_MENU = 'SET_ACTIVE_MENU';
export const SET_ENV_LOADED = 'SET_ENV_LOADED';
export const SET_LAST_ERROR = 'SET_LAST_ERROR';

/**
 * Action pour Spécifie le titre de l'application
 * @param {string} title Le titre de l'application
 */
export const setTitle = (title) => {
  return {
    type: SET_TITLE,
    title
  };
};

/**
 * Action pour spécifier le menu actif
 * @param {string} activeMenu Le menu actif
 */
export const setActiveMenu = (activeMenu) => {
  return {
    type: SET_ACTIVE_MENU,
    activeMenu
  };
};

/**
 * Action pour spécifier le chargement de l'environnement
 * @param {boolean} envLoaded Le statu du chargement
 */
export const setEnvloaded = (envLoaded) => {
  return {
    type: SET_ENV_LOADED,
    envLoaded
  };
};

/**
 * Action pour spécifier la dernière erreur à afficher
 * @param {boolean} lastError La dernière erreur
 */
export const setLastError = (lastError) => {
  return {
    type: SET_LAST_ERROR,
    lastError
  };
};
