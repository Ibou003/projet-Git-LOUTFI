/**
 * Constants pour les actions de sessions
 */
export const SET_CRS_LIST = 'SET_CRS_LIST';
export const SET_SELECTED_CR = 'SET_SELECTED_CR';
export const SET_ENTITIES_LIST = 'SET_ENTITIES_LIST';
export const SET_SELECTED_ENTITY_BY_ZIPCODE = 'SET_SELECTED_ENTITY_BY_ZIPCODE';
export const SET_DISTRIBUTION_ENTITIES_LIST = 'SET_DISTRIBUTION_ENTITIES_LIST';
export const SET_SELECTED_DISTRIBUTION_ENTITY_BY_ID = 'SET_SELECTED_DISTRIBUTION_ENTITY_BY_ID';

/**
 * Action pour specifier la listes des CR
 * @param {*} crsList La liste des CR
 */
export const setCrsList = (crsList) => {
  return {
    type: SET_CRS_LIST,
    crsList
  };
};

/**
 * Action pour spécifier la CR séléctionner
 * @param {*} selectedCrId L'Id de la CR séléctionnée
 */
export const setSelectedCr = (selectedCrId) => {
  return {
    type: SET_SELECTED_CR,
    selectedCrId
  };
};

/**
 * Action pour spécifier la liste des villes d'une CR
 * @param {*} entitiesList La liste des villes
 */
export const setEntitiesList = (entitiesList) => {
  return {
    type: SET_ENTITIES_LIST,
    entitiesList
  };
};

/**
 * Action pour spécifier la ville séléctionnée pour une CR
 * @param {*} zipcode La code postal de la ville séléctionnée
 */
export const setSelectedEntityByZipCode = (zipcode) => {
  return {
    type: SET_SELECTED_ENTITY_BY_ZIPCODE,
    zipcode
  };
};

/**
 * Action pour spécifier la liste des agences d'une ville d'une CR
 * @param {*} distributionEntitiesList La liste des agences
 */
export const setDistributionEntitiesList = (distributionEntitiesList) => {
  return {
    type: SET_DISTRIBUTION_ENTITIES_LIST,
    distributionEntitiesList
  };
};

/**
 * Action pour spécifier l'agence de la ville séléctionnée
 * @param {*} distributionEntityId L'id de l'agence
 */
export const setSelectedDistributionEntityById = (distributionEntityId) => {
  return {
    type: SET_SELECTED_DISTRIBUTION_ENTITY_BY_ID,
    distributionEntityId
  };
};

