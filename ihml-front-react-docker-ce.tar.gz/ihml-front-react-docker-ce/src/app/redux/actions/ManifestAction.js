/**
 * Constants pour les actions du manifest
 */
export const SET_BFF_MANIFEST = 'SET_BFF_MANIFEST';
export const SET_FRONT_MANIFEST = 'SET_FRONT_MANIFEST';

/**
 * Action pour specifier le manifest du back for front
 * @param {*} manifest La manifest à spécifier
 */
export const setBffManifest = (manifest) => {
  return {
    type: SET_BFF_MANIFEST,
    manifest
  };
};

/**
 * Action pour specifier le manifest du front
 * @param {*} manifest La manifest à spécifier
 */
export const setFrontManifest = (manifest) => {
  return {
    type: SET_FRONT_MANIFEST,
    manifest
  };
};
