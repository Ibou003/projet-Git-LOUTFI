/**
 * Constants pour les actions de sessions
 */
export const SET_USER = 'SET_USER';

/**
 * Action pour spécifier l'utilisateur connecté
 * @param {*} user L'utilisateur connecté
 */
export const setUser = (user) => {
  return {
    type: SET_USER,
    user
  };
};
