/**
 * Constants pour les actions du context
 */
export const SET_CONTEXT = 'SET_CONTEXT';
export const RESET_CONTEXT_CR = 'RESET_CONTEXT_CR';
export const RESET_CONTEXT_ENTITY = 'RESET_CONTEXT_ENTITY';

/**
 * Action pour specifier le context
 * @param {*} context La contexte à spécifier
 */
export const setContext = (context) => {
  return {
    type: SET_CONTEXT,
    context
  };
};
