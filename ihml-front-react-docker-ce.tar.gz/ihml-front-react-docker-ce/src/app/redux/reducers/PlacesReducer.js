import * as _ from 'lodash';
import { SET_CRS_LIST, SET_DISTRIBUTION_ENTITIES_LIST, SET_ENTITIES_LIST, SET_SELECTED_CR, SET_SELECTED_DISTRIBUTION_ENTITY_BY_ID, SET_SELECTED_ENTITY_BY_ZIPCODE } from '../actions/PlacesAction';

/**
 * State initial pour le store places
 */
const initialState = {
    crs: [],
    entities: [],
    distributionEntities: [],
    selectedCR: null,
    selectedEntity: null,
    selectedDistributionEntity: null
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_CRS_LIST:
            const crs = action.crsList ? _.concat([], action.crsList) : [];
            return _.assign({}, state, { crs });
        case SET_SELECTED_CR:
            const selectedCR = action.selectedCrId ? _.find(state.crs, { regional_bank_id: action.selectedCrId }) : null;
            return _.assign({}, state, { selectedCR });
        case SET_ENTITIES_LIST:
            const entities = action.entitiesList ? _.concat([], action.entitiesList) : [];
            return _.assign({}, state, { entities: entities });
        case SET_SELECTED_ENTITY_BY_ZIPCODE:
            const selectedEntity = action.zipcode ? _.find(state.entities, { zip_code: action.zipcode }) : null;
            return _.assign({}, state, { selectedEntity });
        case SET_DISTRIBUTION_ENTITIES_LIST:
            const distributionEntities = action.distributionEntitiesList ? _.concat([], action.distributionEntitiesList) : [];
            return _.assign({}, state, { distributionEntities });
        case SET_SELECTED_DISTRIBUTION_ENTITY_BY_ID:
            const selectedDistributionEntity = action.distributionEntityId ? _.find(state.distributionEntities, { id: action.distributionEntityId }) : null;
            return _.assign({}, state, { selectedDistributionEntity });
        default:
            return state;
    };
};