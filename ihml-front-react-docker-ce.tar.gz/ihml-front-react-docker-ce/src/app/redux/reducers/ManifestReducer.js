import * as _ from 'lodash';
import { SET_BFF_MANIFEST, SET_FRONT_MANIFEST } from '../actions/ManifestAction';

/**
 * Store initial pour le context
 */
const initialState = {
    bff: {
        version: null,
        framework: null
    },
    front: {
        version: null
    }
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_BFF_MANIFEST:
            return _.assign({}, state, { bff: action.manifest });
        case SET_FRONT_MANIFEST:
            return _.assign({}, state, { front: action.manifest });
        default:
            return state;
    };
};