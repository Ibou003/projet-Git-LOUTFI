import * as _ from 'lodash';
import { SET_USER } from '../actions/SessionAction';

/**
 * Store initial pour la session
 */
const initialState = {
    user: null
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_USER:
            return _.assign({}, state, { user: action.user });
        default:
            return state;
    };
};
