import * as _ from 'lodash';
import { SET_ACTIVE_MENU, SET_TITLE, SET_ENV_LOADED, SET_LAST_ERROR } from '../actions/UiAction';

/**
 * Store initial pour l'UI
 */
const initialState = {
    title: null,
    activeMenu: null,
    envLoaded: false,
    lastError: null
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_TITLE:
            return _.assign({}, state, { title: action.title });
        case SET_ACTIVE_MENU:
            return _.assign({}, state, { activeMenu: action.activeMenu });
        case SET_ENV_LOADED:
            return _.assign({}, state, { envLoaded: action.envLoaded });
        case SET_LAST_ERROR:
            return _.assign({}, state, { lastError: action.lastError });
        default:
            return state;
    };
};