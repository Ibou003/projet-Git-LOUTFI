import * as _ from 'lodash';
import { SET_CONTEXT } from '../actions/ContextAction';

/**
 * Store initial pour le context
 */
const initialState = {
    regional_bank_id: null,
    zip_code: null
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SET_CONTEXT:
            return _.assign({}, state, { regional_bank_id: action.context.regional_bank_id, zip_code: action.context.zip_code });
        default:
            return state;
    };
};