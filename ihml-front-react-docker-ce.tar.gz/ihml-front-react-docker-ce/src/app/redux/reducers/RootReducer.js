import { combineReducers } from 'redux';
import placesReducer from './PlacesReducer';
import sessionReducer from './SessionReducer';
import uiReducer from './UiReducer';
import contextReducer from './ContextReducer';
import manifestReducer from './ManifestReducer';

/**
 * Reducer parent
 */
export const rootReducer = combineReducers({
    ui: uiReducer,
    session: sessionReducer,
    places: placesReducer,
    context: contextReducer,
    manifest: manifestReducer
});