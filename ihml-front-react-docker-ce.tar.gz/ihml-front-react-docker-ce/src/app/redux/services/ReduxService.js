import { applyMiddleware, createStore } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
import thunkMiddleware from 'redux-thunk';
import { rootReducer } from '../reducers/RootReducer';

/**
 * Classe pour exposer les méthodes et le store de Redux
 */
class ReduxService {

    /**
     * Constructeur du service
     */
    constructor() {
        // Initiallisation du store
        this.store = null;
    }

    /**
     * Récupération du store redux
     */
    getStore() {
        return this.store;
    }

    /**
     * Méthode pour dispatcher une action redux
     * @param {*} action 
     */
    dispatch(action) {
        return this.store.dispatch(action);
    }

    /**
     * Configuration de Redux
     * @param {} preloadedState State initial si besoin
     */
    configureStore(preloadedState) {
        // configuration des middlewares. Utilisation de redux-thunk
        const middlewares = [thunkMiddleware];
        const middlewareEnhancer = applyMiddleware(...middlewares);

        const enhancers = [middlewareEnhancer];
        const composedEnhancers = composeWithDevTools(...enhancers);

        // Création du store
        this.store = createStore(rootReducer, preloadedState, composedEnhancers);
    }

}

export default ReduxService;
