import { createBrowserHistory } from 'history';

/**
 * Définition de l'historique
 */
export default createBrowserHistory({
    basename: process.env.PUBLIC_URL
});