import * as inversify from 'inversify';
import 'reflect-metadata';
import ReduxService from '../app/redux/services/ReduxService';
import ConfigurationService from '../app/services/ConfigurationService';
import AuthentificationService from '../app/services/AuthentificationService';
import SecurityService from '../app/services/SecurityService';
import PlacesService from '../app/services/PlacesService';
import HttpService from '../app/services/HttpService';
import ContextService from '../app/services/ContextService';
import ManifestService from '../app/services/ManifestService';
import ErrorService from '../app/services/ErrorService';

const TYPES = {
    ReduxService: 'ReduxService',
    AuthentificationService: 'AuthentificationService',
    ConfigurationService: 'ConfigurationService',
    SecurityService: 'SecurityService',
    PlacesService: 'PlacesService',
    ContextService: 'ContextService',
    ManifestService: 'ManifestService',
    ErrorService: 'ErrorService'
};
inversify.decorate(inversify.injectable(), ReduxService);
inversify.decorate(inversify.injectable(), HttpService);
inversify.decorate(inversify.injectable(), ConfigurationService);
inversify.decorate(inversify.injectable(), ErrorService);
inversify.decorate(inversify.injectable(), SecurityService);
inversify.decorate(inversify.injectable(), AuthentificationService);
inversify.decorate(inversify.injectable(), PlacesService);
inversify.decorate(inversify.injectable(), ContextService);
inversify.decorate(inversify.injectable(), ManifestService);

let iocContainer = new inversify.Container();
iocContainer.bind(TYPES.ReduxService).to(ReduxService).inSingletonScope();
iocContainer.bind(TYPES.ConfigurationService).to(ConfigurationService).inSingletonScope();
iocContainer.bind(TYPES.ErrorService).to(ErrorService).inSingletonScope();
iocContainer.bind(TYPES.AuthentificationService).to(AuthentificationService).inSingletonScope();
iocContainer.bind(TYPES.SecurityService).to(SecurityService).inSingletonScope();
iocContainer.bind(TYPES.PlacesService).to(PlacesService).inSingletonScope();
iocContainer.bind(TYPES.ContextService).to(ContextService).inSingletonScope();
iocContainer.bind(TYPES.ManifestService).to(ManifestService).inSingletonScope();


export {iocContainer, TYPES};
