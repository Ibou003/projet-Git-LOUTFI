const constants = {
    APPLICATION: {
        CONFIGURATION: {
            TITLE: 'title',
            API_BASE_PATH: 'apiBasePath',
            X_CONNECT_URL: 'xConnectUrl',
            CLIENT_ID: 'clientId',
            REDIRECT_URL: 'redirectUrl',
            ANGULAR_CLIENT_ID: 'angularClientId',
            ANGULAR_URL: 'angularUrl'
        }
    },
    ROUTES: {
        PATHS: {
            ROOT_BUILD: process.env.PUBLIC_URL,
            LOGIN: '/login'
        },
        PARAMS: {
            ID_CONTEXT: 'idCtx'
        },
        X_CONNECT: {
            AUTHORIZE: 'authorize',
            LOGOUT: 'logout'
        },
        ANUGLAR: {
            AGENCES: 'agences'
        }
    },
    MENUS: {
        HOME: 'home',
        AGENCES: 'agences'
    },
    LABELS: {
        ACTIONS: {
            LOGOUT: 'Déconnexion'
        }
    },
    WEEK_DAYS: [
        {
            day_of_week: '1',
            label: 'Lundi'
        },
        {
            day_of_week: '2',
            label: 'Mardi'
        },
        {
            day_of_week: '3',
            label: 'Mercredi'
        },
        {
            day_of_week: '4',
            label: 'Jeudi'
        },
        {
            day_of_week: '5',
            label: 'Vendredi'
        },
        {
            day_of_week: '6',
            label: 'Samedi'
        },
        {
            day_of_week: '7',
            label: 'Dimanche'
        }
    ],
    ACTIONS: {
        REDIRECT_FROM_XCONNECT: 'Retour de la mire de connexion',
        GET_CONTEXT: 'Récupération du contexte: ',
        SAVE_CONTEXT: 'Sauvegarde du contexte',
        REDIRECTION_TO_XCONNECT: 'Vous allez être redirigé vers la mire de déconnexion',
        GET_CR_LIST: 'Récupération de la liste des CR',
        GET_CR_ENTITIES_LIST: 'Récupération de la liste des villes de la CR:',
        GET_CR_CITY_DISTRIBUTION_ENTITIES: 'Récupération de la liste des agences de la CR et de la ville:',
        USER_LOGIN: 'Connexion de l\'utilisateur',
        USER_LOGOUT: 'Déconnexion de l\'utilisateur',
        GET_USER_INFORMATION: 'Récupération information sur l\'utilisateur connecté',
        GET_MANIFEST: 'Récupération du manifest de l\'application'
    },
    ERROR_MESSAGES: {
        BAD_XCONNECT_INFORMATION: 'Les informations de retour de connexion sont incorrectes',
        SERVER_NOT_REACHABLE: '404 - Le serveur ne peut être contacté.'
    },
    ENUM: {
        ACTIONS: {
            DECONNEXION: 'Deconnexion'
        }
    }
};
export default constants;
