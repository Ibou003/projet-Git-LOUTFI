import { AppInitService } from '../services/app-init.service';
import { APP_INITIALIZER } from '@angular/core';

// Provider for getting application configuration on Init
export function provideAppconfiguration(appInitService: AppInitService) {
    return () => appInitService.loadCongiruation();
}

export let appConfigurationProvider =  {
    provide: APP_INITIALIZER,
    useFactory: provideAppconfiguration,
    deps: [AppInitService],
    multi: true
};

