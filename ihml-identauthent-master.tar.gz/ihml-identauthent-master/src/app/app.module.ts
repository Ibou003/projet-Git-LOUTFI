import { NgModule  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatProgressSpinnerModule } from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { AuthService } from './services/auth.service';
import { AuthorizeComponent } from './components/authorize/authorize.component';
import {AppInitService} from './services/app-init.service';
import { SecurityService } from './services/security.services';
import { appConfigurationProvider } from './providers/app.provider';
import { ErrorComponent } from './components/error/error.component';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';

@NgModule({
  declarations: [
    AppComponent,
    AuthorizeComponent,
    LoginComponent,
    LogoutComponent,
    ErrorComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    MatProgressSpinnerModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    AppInitService,
    appConfigurationProvider,
    CookieService,
    AuthGuard,
    AuthService,
    SecurityService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
