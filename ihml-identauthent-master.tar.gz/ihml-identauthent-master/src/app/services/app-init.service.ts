import { Injectable } from '@angular/core';
import { map} from 'rxjs/operators';
import { HttpClient} from '@angular/common/http';

declare var window: any;

@Injectable()
export class AppInitService {

    constructor(private http: HttpClient) { }

  // This is the method you want to call at bootstrap
  // Important: It should return a Promise
  public loadCongiruation() {
    return this.http.get('configuration/app-config.json').pipe(
        map((config) => {
        window.appConfig = config;
        return;
    })).toPromise();
  }
}
