import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { CookieService} from 'ngx-cookie-service';
import Constants from '../../const';
import { environment } from '../../environments/environment';
import { Session, State } from '../models/security';

@Injectable()
export class SecurityService {
    constructor(private http: HttpClient,
        private cookieService: CookieService,
        private router: Router) {}

    createSession(sessionId: string, state: State) {
        const session: Session = {
            id: sessionId,
            state
        };

        return this.http.post(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/session`, session).pipe(
            catchError(
                this.handleError<any>(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/session`)
            )
        );
    }

    login(code: string, redirect_uri: string, sessionId: string) {
        const  headers =  new HttpHeaders({
            'Authorization': code,
            'RedirectUrl': redirect_uri,
            'SessionId': sessionId
        });
        return this.http.get(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/login`, {headers}).pipe(
            catchError(
                this.handleError<any>(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/login`)
            )
        );
    }

    logout() {
       return this.http.get(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/logout`).pipe(
            catchError(
                this.handleError<any>(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/logout`)
            )
        );
    }

    getUserConnected() {
       return this.http.get(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/user`).pipe(
            catchError(
                this.handleError<any>(`${environment.environment[Constants.APPLICATION.CONFIGURATION.API_BASE_PATH]}/security/user`)
            )
        );
    }


    /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
        console.warn(error.message);
        this.router.navigate(['/error']);
        throw error;
    };
  }
}
