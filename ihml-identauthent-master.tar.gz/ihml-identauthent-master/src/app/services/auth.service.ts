import { EventEmitter, Injectable } from '@angular/core';
import { Router, Params } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import * as _ from 'lodash';
import Constants from '../../const';
import { Session } from '../models/security';
import { environment } from 'src/environments/environment';
import { SecurityService } from './security.services';
import * as uuidv4 from 'uuid/v4';
import { User } from '../models/User';
import { Path } from '../models/Path';

@Injectable()
export class AuthService {
    error: any;
    loggedInEvent = new EventEmitter<boolean>();

    constructor(
        private securityService: SecurityService,
        private cookieService: CookieService,
        private router: Router
    ) {}

    get authenticated(): boolean {
        return this.cookieService.check(environment.environment[Constants.APPLICATION.CONFIGURATION.SESSION_COOKIE]);
    }

    login(redirectTo: string) {
        this.storeRedirectTo(redirectTo);
        const sessionId: string = uuidv4();
        // Redirect to X_connect
        const queryParams = {
            client_Id: environment.environment[Constants.APPLICATION.CONFIGURATION.CLIENT_ID],
            redirect_uri: environment.environment[Constants.APPLICATION.CONFIGURATION.REDIRECT_URL],
            response_type: 'code',
            scope: 'openid functional_posts',
            state: sessionId
        };

        let  queryParamsString = `client_id=${queryParams.client_Id}`;
        queryParamsString = `${queryParamsString}&redirect_uri=${queryParams.redirect_uri}`;
        queryParamsString = `${queryParamsString}&response_type=${queryParams.response_type}`;
        queryParamsString = `${queryParamsString}&scope=${queryParams.scope}`;
        queryParamsString = `${queryParamsString}&state=${queryParams.state}`;
        // tslint:disable-next-line: max-line-length
        location.assign(`${environment.environment[Constants.APPLICATION.CONFIGURATION.X_CONNECT_URL]}${Constants.ROUTES.X_CONNECT.AUTHORIZE}?${queryParamsString}`);
    }

    handleAuth() {
        const queryParamsMap = this.getPathInfos(location.search).searchParams;
        let code = null;
        let state = null;
        if (!_.isEmpty(queryParamsMap)) {
            code = queryParamsMap['code'];
            state = queryParamsMap['state'];
        }

        if (!_.isEmpty(code) && !_.isEmpty(state)) {
            // Connexion au BFF pour demande d'authentication
            this.securityService.login(code, environment.environment[Constants.APPLICATION.CONFIGURATION.REDIRECT_URL], state).subscribe((session: Session) => {
                const redirectTo = this.getRedirectTo();
                if (_.isEmpty(redirectTo)) {
                    this.router.navigate(['/login']);
                } else {
                    this.router.navigate(['/login'], {queryParams: {redirectTo}});
                }
            });
        } else {
            console.log('Authentification impossible');
            this.router.navigate(['/error']);
        }
    }

    logout() {
        this.securityService.logout().subscribe(
            () => {},
            () => {},
            () => {
            this.removeSessionCookie();

            // tslint:disable-next-line: max-line-length
            location.assign(`${environment.environment[Constants.APPLICATION.CONFIGURATION.X_CONNECT_URL]}${Constants.ROUTES.X_CONNECT.LOGOUT}`);
        });
    }

    redirect(params: Params) {
        this.securityService.getUserConnected().subscribe(() => {
            let rootRedirect = '';
            rootRedirect = `${environment.environment[Constants.APPLICATION.CONFIGURATION.APPLICATION_PATH]}`;

            let redirectTo = '/';
            if (!_.isEmpty(params) && !_.isEmpty(params.params)) {
                redirectTo = _.has(params.params, 'redirectTo') ? params.params['redirectTo'] : '';
            }

            localStorage.removeItem('redirectTo');
            location.assign(`${rootRedirect}${redirectTo}`);
        });
    }

    removeSessionCookie() {
        this.cookieService.delete(environment.environment[Constants.APPLICATION.CONFIGURATION.SESSION_COOKIE], '/', window.location.host);
        this.cookieService.delete(environment.environment[Constants.APPLICATION.CONFIGURATION.USER_INFO_COOKIE], '/', window.location.host);
    }

    private storeRedirectTo(redirectTo: string) {
        localStorage.setItem('redirectTo', redirectTo);
    }

    private getRedirectTo(): string {
        return _.isNull(localStorage.getItem('redirectTo')) ? null : localStorage.getItem('redirectTo');
    }

    getPathInfos(path: string): Path {
        const pathSplit = path.split('?');
        const queryString = pathSplit.length === 1 ? '' : pathSplit.pop();
        const queryParamsMap = {};
        if (!_.isEmpty(queryString)) {
            // Parse query string
            const params = queryString.split('&');
            params.forEach((param) => {
                const paramObject = param.split('=');
                queryParamsMap[paramObject[0]] = paramObject[1];
            });
        }

        return {
            root: pathSplit[0],
            searchParams: queryParamsMap
        };
    }
}
