import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AuthorizeComponent } from './components/authorize/authorize.component';
import { ErrorComponent } from './components/error/error.component';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './components/login/login.component';
import { LogoutComponent } from './components/logout/logout.component';

const routes: Routes = [
    { path: 'authorize', component: AuthorizeComponent },
    { path: 'error', component: ErrorComponent },
    { path: 'logout', component: LogoutComponent },
    { path: '', component: LoginComponent, canActivate: [AuthGuard] },
    { path: '**', component: LoginComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }