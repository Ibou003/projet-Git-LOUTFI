import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-authorize',
  templateUrl: './authorize.component.html',
  styleUrls: ['./authorize.component.scss']
})
export class AuthorizeComponent implements OnInit {

    loaderParams: any;
    constructor(
        private authService: AuthService
    ) {}

  ngOnInit() {
      this.authService.handleAuth();
  }
}
