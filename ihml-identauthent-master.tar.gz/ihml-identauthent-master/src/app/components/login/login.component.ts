import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

    loaderParams: any;
    constructor(
        private route: ActivatedRoute,
        private authService: AuthService
    ) {}

  ngOnInit() {
    this.route.queryParamMap.subscribe(params => {
        this.authService.redirect(params);
    });
  }
}
