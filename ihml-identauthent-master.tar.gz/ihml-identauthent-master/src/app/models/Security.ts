import { User } from './User';


export interface OAuthToken {
    expirationDate: number;
    access_token: string;
    type: string;
    id_token: string;
    refresh_token: string;
    user: User;
}

export interface Session {
    id: string;
    token?: OAuthToken;
    state?: State;
}

export interface State {
    redirectUri: string;
}
