export interface Path {
    root: string;
    searchParams: any;
}
