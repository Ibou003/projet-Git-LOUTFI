const constants = {
    APPLICATION: {
        CONFIGURATION : {
            TITLE: 'TITLE',
            API_BASE_PATH: 'API_BASE_PATH',
            X_CONNECT_URL: 'X_CONNECT_URL',
            CLIENT_ID: 'CLIENT_ID',
            REDIRECT_URL: 'REDIRECT_URL',
            ROOT_PATH: 'ROOT_PATH',
            APPLICATION_PATH: 'APPLICATION_PATH',
            SESSION_COOKIE: 'SESSION_COOKIE',
            USER_INFO_COOKIE: 'USER_INFO_COOKIE'
        }
    },
    ROUTES: {
        PATHS: {
            AUTHORIZE: '/authorize'
        },
        X_CONNECT : {
            AUTHORIZE: 'authorize',
            LOGOUT: 'logout'
        }
    },
    MENUS: {
        HOME: 'home',
        AGENCES: 'agences'
    },
    LABELS: {
        ACTIONS: {
            LOGIN: 'Connexion',
            LOGOUT: 'Déconnexion'
        }
    },
    WEEK_DAYS: [
        {
            day_of_week: '1',
            label: 'Lundi'
        },
        {
            day_of_week: '2',
            label: 'Mardi'
        },
        {
            day_of_week: '3',
            label: 'Mercredi'
        },
        {
            day_of_week: '4',
            label: 'Jeudi'
        },
        {
            day_of_week: '5',
            label: 'Vendredi'
        },
        {
            day_of_week: '6',
            label: 'Samedi'
        },
        {
            day_of_week: '7',
            label: 'Dimanche'
        }
    ]
};
export default constants;
